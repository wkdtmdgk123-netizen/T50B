--[[
    T-50B Golden Eagle
    Based on F-22A Raptor by Grinnelli Designs
    Converted to T-50B specifications - Training Aircraft (No Weapons)
    
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see https://www.gnu.org/licenses.
--]]

--T-50B Golden Eagle - Training Aircraft Version
--Converted from F-22A Raptor EFM

T_50B = 
{
      
	Name 			= 'T-50B',
	DisplayName		= _('T-50B Golden Eagle'),
    Picture 		= "F-22A.png",  -- Will need T-50B image
    Rate 			= "50",
    Shape			= "F-22A",  -- Will need T-50B model
    WorldID			=  T_50B,     
	shape_table_data 	= 
	{
		{
			file  	 	= 'F-22A';  -- Will need T-50B model
			life  	 	= 20;
			vis   	 	= 2;
			desrt    	= 'F-22A_destr';
			fire  	 	= { 300, 2};
			username	= 'T-50B';
			index       =  T_50B;
			classname   = "lLandPlane";
			positioning = "BYNORMAL";
		},
		{
			name  		= "F-22A_destr";
			file  		= "F-22A_destr";
			fire  		= { 240, 2};
		},
	},

	Countries = {"South Korea"},
	
	mapclasskey 		= "P0091000024",
	attribute  			= {wsType_Air, wsType_Airplane, wsType_Fighter, T_50B, "Fighters", "Refuelable",},
	Categories= {"{78EFB7A2-FD52-4b57-A6A6-3BF0E1D6555F}", "Interceptor",},
	
	-- T-50B Specifications
	M_empty						=	6470,	-- kg Empty weight
	M_nominal					=	8500,	-- kg Normal takeoff weight
	M_max						=	12300,	-- kg Maximum takeoff weight
	M_fuel_max					=	2500,	-- kg Internal fuel capacity
	H_max						=	14600,	-- m Maximum altitude
	average_fuel_consumption	=	0.15,
	CAS_min						=	55,		-- Minimum CAS speed (m/s) (for AI)
	V_opt						=	200,	-- Cruise speed (m/s) (for AI)
	V_take_off					=	58,		-- Take off speed in m/s (for AI)
	V_land						=	65,		-- Land speed in m/s (for AI)
	has_afteburner				=	true,
	has_speedbrake				=	true,
	radar_can_see_ground		=	true,
	
	-- Landing gear positions (T-50B specific)
	nose_gear_pos 				                = {4.5,	-1.5,	0.0},
    nose_gear_amortizer_direct_stroke   		=  0,
    nose_gear_amortizer_reversal_stroke  		= -0.28,
    nose_gear_amortizer_normal_weight_stroke 	= -0.18,
    nose_gear_wheel_diameter 	                =  0.50,
	
	main_gear_pos 						 	    = {-0.3,	-1.5,	-1.4},
    main_gear_amortizer_direct_stroke	 	    =  -0.35,
    main_gear_amortizer_reversal_stroke  	    =  -0.18,
    main_gear_amortizer_normal_weight_stroke  	=  -0.18,
    main_gear_wheel_diameter 				    =   0.70,

	
	effects_presets =   {{effect = "OVERWING_VAPOR", file = current_mod_path.."/Effects/F-22A_overwingVapor.lua"}},

	AOA_take_off				=	0.14,
	stores_number				=	1,  -- Only smoke pod
	bank_angle_max				=	60,
	Ny_min						=	-3,
	Ny_max						=	9,  -- T-50B G limit
	tand_gear_max				=	3.5,
	V_max_sea_level				=	350,	-- Max speed at sea level in m/s (for AI)
	V_max_h						=	510,	-- Max speed at max altitude in m/s (for AI) - Mach 1.5
	wing_area					=	25.3,	-- wing area in m2
	thrust_sum_max 				= 	78000, 	-- ~78 kN in kgf (single engine MIL)
	thrust_sum_ab 				= 	130000,  -- ~130 kN in kgf (single engine AB)
	Vy_max						=	250,	-- Max climb speed in m/s (for AI)
	flaps_maneuver				=	1,
	Mach_max					=	1.5,	-- Max speed in Mach (for AI)
	range						=	1850,	-- Max range in km (for AI)
	RCS							=	0.5,    -- Radar Cross Section m2 (not stealth)
	Ny_max_e					=	9,		-- Max G (for AI)
	detection_range_max			=	600,
	IR_emission_coeff			=	0.25,	-- Normal engine
	IR_emission_coeff_ab		=	0.5,	-- With afterburner
	tanker_type					=	1,
	wing_span					=	9.45,	-- wing span in m
	wing_type 					= 	0,		-- 0=FIXED_WING
	length						=	13.14,	-- length in m
	height						=	4.94,	-- height in m
	crew_size					=	1,
	engines_count				=	1,		-- Single engine
	wing_tip_pos 				= 	{-3.0,	0.35,	4.725},-- wingtip coords for visual effects
	
	EPLRS 					    = true,
	TACAN_AA					= true,
	brakeshute_name				= 0,
	is_tanker					= false,
	air_refuel_receptacle_pos 	= {6.0, 0.7, 0.8},
	sound_name	=	"aircraft/F-22A/Sounds",

	-- Single engine nozzle
	engines_nozzles = 
	{
		[1] = 
		{
			pos = 	{-5.5,	0.000,	0.0},  -- Centered
			elevation	=	0,
			diameter	=	1.0,
			exhaust_length_ab	=	10.0,
			exhaust_length_ab_K	=	0.9,
			smokiness_level     = 	0.02,
			afterburner_circles_count = 6,
			afterburner_circles_pos = {0.2, 0.8},
			afterburner_circles_scale = 1.2,
			afterburner_effect_texture = "F22_burner",
		},
	},
	
	crew_members = 
	{
		[1] = 
		{
			ejection_seat_name	=	17,
			drop_canopy_name	=	"F-22A_Canopy";
			pos = 	{5.5,	1.2,	0},
		},
	},

	fires_pos = 
	{
		[1] = 	{ 0.7,	0.7,	 0},
		[2] = 	{-0.1,	0.35, 	 2.0},
		[3] = 	{-0.1,	0.35,	-2.0},
		[4] = 	{-0.6,	0.25,	 2.2},
		[5] = 	{-0.6,	0.25,	-2.2},
		[6] = 	{-0.6,	0.24,	 3.5},
		[7] = 	{-0.6,	0.24,	-3.5},
		[8] = 	{-3.5,	0.2,	 0}, -- Single engine fire position
		[9] = 	{-0.4,	0.7,	 0.6},
		[10] = 	{-0.4,	0.7,	-0.6},
	},
	
	chaff_flare_dispenser = 
	{
		[1] = 
		{
			dir = 	{-1,	-1,	1},
			pos = 	{0.4,	-0.35,	1.2},
		}, 
		[2] = 
		{
			dir = 	{-1,	-1,	-1},
			pos = 	{0.4,	-0.35,	-1.2},
		}, 
	}, 

	passivCounterm = {
		CMDS_Edit = true,
		SingleChargeTotal = 120,
		chaff = {default = 60, increment = 1, chargeSz = 1},
		flare = {default = 60, increment = 2, chargeSz = 2}
    },
	
    CanopyGeometry 	= {
        azimuth 	= {-145.0, 145.0},
        elevation 	= {-50.0, 90.0}
    },

	Sensors 		= {
	RADAR 			= "AN/APG-63",
	RWR 			= "Abstract RWR"
	},
	Countermeasures = {
		ECM 			= "AN/ALQ-135"
	},

AddPropAircraft = {
		{id = "SMOKE_COLOR", control = 'comboList', label = _('Smoke Color'), defValue = 0, 
			player = false,
			values = {
				{id = 0, name = _('OFF')},
				{id = 1, name = _('RED')},
				{id = 2, name = _('GREEN')},
				{id = 3, name = _('BLUE')},
				{id = 4, name = _('WHITE')},
				{id = 5, name = _('YELLOW')},
				{id = 6, name = _('ORANGE')},
			},
		},
	},

Failures = {
		{ id = 'asc', 		label = _('ASC'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'autopilot', label = _('AUTOPILOT'), enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'hydro',  	label = _('HYDRO'), 	enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'engine',  	label = _('ENGINE'), 	enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'radar',  	label = _('RADAR'), 	enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'mlws',  	label = _('MLWS'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'rws',  		label = _('RWS'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'ecm',   	label = _('ECM'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'hud',  		label = _('HUD'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },
		{ id = 'mfd',  		label = _('MFD'), 		enable = false, hh = 0, mm = 0, mmint = 1, prob = 100 },		
	},
	HumanRadio = {
		frequency 		= 127.5,
		editable 		= true,
		minFrequency	= 100.000,
		maxFrequency 	= 156.000,
		modulation 		= MODULATION_AM
	},

	net_animation = {
				 603,--LEF
				 604,--Taxi Lights
				 605,--Landing Lights
				 606,--Form Light
				 607,--Nav White
				 608,--AntiCol
				 609,--AAR Light
				 610,--engine clamshell
				 612,--Nav Lights
				 613,--Nav Lights
				 614,--Canon Door (not used but keep for compatibility)
				 615,--Canon Spin (not used but keep for compatibility)
				 616,--GPU Cart Vis
				 617,--GPU Movement
				 618,--GPU Beacon
				 619,--Canopy Cycle
				 620,--Garfield Window Cling
				 621,--Visor Color
				},

	-- No guns for T-50B training version
	Guns = {},

	-- Only smoke pod pylon
	pylons_enumeration = {1},
	
	Pylons = {
		-- Center pylon for smoke only
        pylon(1, 0, 0.0, -0.2, 0.0,
            {
				use_full_connector_position = true,	
                connector = "PylonCenter"				
            },
            {
				{ CLSID = "<CLEAN>" },
				-- Smoke pods - color selectable via AddPropAircraft
				{ CLSID = "{INV-SMOKE-RED}", 	attach_point_position = {-5.0, 0.5, 0.0}},
				{ CLSID = "{INV-SMOKE-GREEN}", 	attach_point_position = {-5.0, 0.5, 0.0}},
				{ CLSID = "{INV-SMOKE-BLUE}", 	attach_point_position = {-5.0, 0.5, 0.0}},
				{ CLSID = "{INV-SMOKE-WHITE}", 	attach_point_position = {-5.0, 0.5, 0.0}},
				{ CLSID = "{INV-SMOKE-YELLOW}", attach_point_position = {-5.0, 0.5, 0.0}},
				{ CLSID = "{INV-SMOKE-ORANGE}",	attach_point_position = {-5.0, 0.5, 0.0}},
            }
        ),
	},

	Tasks = {
        aircraft_task(Reconnaissance),
        aircraft_task(Intercept),
    },	
	DefaultTask = aircraft_task(Reconnaissance),

	--SFM Table Data (backup, EFM will override)
	SFM_Data = 
		{
			aerodynamics = 
		{
			Cy0			= 0,
			Mzalfa		= 5.5,
			Mzalfadt	= 0.75,
			kjx			= 1.8,
			kjz			= 0.0011,
			Czbe		= -0.014,
			cx_gear		= 0.024,
			cx_flap		= 0.055,
			cy_flap		= 0.35,
			cx_brk		= 0.07,
			table_data = 
			{
			--    M 	  Cx0		 Cya		 B			 B4	   Omxmax   Aldop  Cymax
				{0.0,	0.020,		0.060,		0.08,		0.20,	0.70,	28.0,	1.15 	},
				{0.2,	0.020,		0.060,		0.08,		0.20,	1.90,	28.0,	1.15     },
				{0.4,	0.020,		0.060,		0.08,	   	0.20,	3.20,	28.0,	1.15     },
				{0.6,	0.020,		0.060,		0.05,		0.26,	4.50,	24.0,	1.10     },
				{0.7,	0.020,		0.060,		0.05,		0.26,	4.50,	24.0,	1.05    },
				{0.8,	0.020,		0.060,		0.05,		0.26,	4.50,	22.0,	1.0     },
				{0.9,	0.022,		0.062,		0.08,		0.18,	4.50,	20.0,	0.98    },
				{1.0,	0.030,		0.065,		0.15,		0.14,	4.50,	19.0,	0.95    },
				{1.1,	0.040,		0.065,	   	0.22,		0.08,	4.00,	17.5,	0.93    },
				{1.2,	0.043,		0.065,	   	0.27,		0.07,	3.00,	17.0,	0.90 	},		
				{1.3,	0.044,		0.062,	   	0.28,		0.09,	2.20,	16.0,	0.85 	},				
				{1.4,	0.044,		0.058,	   	0.29,		0.12,	1.90,	15.0,	0.75 	},					
				{1.5,	0.044,		0.055,	   	0.30,		0.15,	1.70,	14.0,	0.65 	},					
			},
		},
			
		engine = 
		{
			Nmg		=	68.0,
			MinRUD	=	0,
			MaxRUD	=	1,
			MaksRUD	=	0.85,
			ForsRUD	=	0.91,
			type	=	"TurboJet",
			hMaxEng	=	14.6,
			dcx_eng	=	0.0085,
			cemax	=	1.20,
			cefor	=	2.40,
			dpdh_m	=	5500,
			dpdh_f	=	12000.0,
			table_data = {
			--    M		 Pmax		 Pfor
				{0.0,	 78000,		130000},
				{0.2,	 78000,		128000},
				{0.4,	 78000,		130000},
				{0.6,	 78000,		132000},
				{0.7,	 78000,		133000},
				{0.8,	 78000,		135000},
				{0.9,	 78000,		137000},
				{1.0,	 78000,		130000},
				{1.1,	 78000,		131000},
				{1.2,	 75000,		132000},
				{1.3,	 70000,		133000},
				{1.4,	 65000,		134000},
				{1.5,	 60000,		135000},
			},
		},
	},
		
-- Damage model (simplified for T-50B)
	Damage = {
		[0]  = {critical_damage = 5, args = {146}},
		[1]  = {critical_damage = 3, args = {296}},
		[2]  = {critical_damage = 3, args = {297}},
		[3]  = {critical_damage = 8, args = {65}},
		[4]  = {critical_damage = 2, args = {298}},
		[5]  = {critical_damage = 2, args = {301}},
		[12] = {critical_damage = 1, args = {161}},
		[37] = {critical_damage = 2, args = {228}},
		[38] = {critical_damage = 2, args = {218}},
		[40] = {critical_damage = 2, args = {241}, deps_cells = {54}},
		[54] = {critical_damage = 2, args = {247}},
		[59] = {critical_damage = 3, args = {148}},
		[53] = {critical_damage = 2, args = {248}},	
		[25] = {critical_damage = 2, args = {226}},	
		[26] = {critical_damage = 2, args = {216}},	
		[19] = {critical_damage =  5, args = {232}},	
		[20] = {critical_damage =  5, args = {185}},	
		[11] = {critical_damage = 1, args = {167}},	
		[39] = {critical_damage = 2, args = {244}, deps_cells = {53}},								
		[41] = {critical_damage = 10, args = {245}, deps_cells = {39,53}},			
		[43] = {critical_damage = 2, args = {243}, deps_cells = {39, 53}},		
		[44] = {critical_damage = 2, args = {242}, deps_cells = {40, 54}},		
		[23] = {critical_damage = 5, args = {223}},				
		[29] = {critical_damage = 5, args = {224}, deps_cells = {23, 25}},	    
		[35] = {critical_damage = 6, args = {225}, deps_cells = {23, 29, 25, 37}},	
		[36] = {critical_damage = 6, args = {215}, deps_cells = {24, 30, 26, 38}},	
		[30] = {critical_damage = 5, args = {214}, deps_cells = {24, 26}},	    
		[24] = {critical_damage = 5, args = {213}},				
		[9]  = {critical_damage = 3, args = {154}}, 								
		[82] = {critical_damage = 2, args = {152}},								
		[10] = {critical_damage = 3, args = {153}},								
		[55] = {critical_damage = 10, args = {159}},								
		[56] = {critical_damage = 2, args = {158}},								
		[57] = {critical_damage = 2, args = {157}},								
		[58] = {critical_damage = 10, args = {156}},								
		[8]  = {critical_damage = 3, args = {265}},	
		[15] = {critical_damage = 2, args = {267}}, 	
		[16] = {critical_damage = 2, args = {266}},	
		[83] = {critical_damage = 2, args = {134}},						
		[84] = {critical_damage = 2, args = {136}},						
		[85] = {critical_damage = 2, args = {135}},						
	},

	DamageParts = 
	{  
		[1] = "F-22A-oblomok-wing-r",
		[2] = "F-22A-oblomok-wing-l",
		[3] = "F-22A-oblomok-noise",
		[4] = "F-22A-oblomok-tail-r",
		[5] = "F-22A-oblomok-tail-l",
	},

	lights_data = {
		typename = "collection",
		lights = {	
			[1] = { typename = "collection", lights = {}},
			[2] = { typename = "collection", lights = {}},
			[3]	= {	typename = "collection", lights = {}},
			[4] = { typename = "collection", lights = {}},
		}
	},
	
	-- EFM Configuration (External Flight Model)
	EFM = {
		file = "T50_EFM.dll",
		path = current_mod_path.."/EFM/bin/Release/",
	},
}

add_aircraft(T_50B)

