--[[
    T-50B Golden Eagle Entry Point
    DCS World Mod Entry File
--]]

-- Load T-50B aircraft definition
dofile(current_mod_path .. "/T-50B.lua")

-- Create view settings
make_view_settings('T-50B', ViewSettings, SnapViews)


