# Windows로 복사할 파일 목록

## 📦 Windows PC로 복사해야 할 파일들

### ✅ 필수 파일 (반드시 복사)

#### 1. EFM 소스 파일들
```
EFM/
├── CMakeLists.txt                    ✅ 필수
├── build_windows_simple.bat          ✅ 필수 (빌드 스크립트)
├── build_windows.bat                 ✅ 선택 (상세 빌드 스크립트)
├── build_debug.bat                   ✅ 선택 (디버그 빌드)
│
└── source/
    ├── T50.cpp                       ✅ 필수
    ├── T50.h                         ✅ 필수
    ├── FBW.cpp                       ✅ 필수 (FBW 시스템)
    ├── FBW.h                         ✅ 필수 (FBW 시스템)
    ├── Utility.h                     ✅ 필수
    ├── Inputs.h                      ✅ 필수
    ├── DebugLog.h                    ✅ 선택 (디버깅용)
    │
    ├── FM/
    │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h  ✅ 필수
    │
    └── Cockpit/
        └── CockpitAPI_Declare.h      ✅ 필수
```

#### 2. DCS 모드 파일들
```
T-50B/
├── entry.lua                         ✅ 필수
└── T-50B.lua                         ✅ 필수
```

---

## 📋 복사 체크리스트

### 필수 파일 (빌드에 반드시 필요)

**EFM 폴더:**
- [ ] `EFM/CMakeLists.txt`
- [ ] `EFM/source/T50.cpp`
- [ ] `EFM/source/T50.h`
- [ ] `EFM/source/FBW.cpp`
- [ ] `EFM/source/FBW.h`
- [ ] `EFM/source/Utility.h`
- [ ] `EFM/source/Inputs.h`
- [ ] `EFM/source/FM/wHumanCustomPhysicsAPI_ImplementationDeclare.h`
- [ ] `EFM/source/Cockpit/CockpitAPI_Declare.h`

**빌드 스크립트:**
- [ ] `EFM/build_windows_simple.bat` (또는 build_windows.bat)

**DCS 모드 파일:**
- [ ] `entry.lua`
- [ ] `T-50B.lua`

### 선택 파일 (편의용)

- [ ] `EFM/build_windows.bat` (상세 빌드 스크립트)
- [ ] `EFM/build_debug.bat` (디버그 빌드)
- [ ] `EFM/source/DebugLog.h` (디버깅용)
- [ ] 문서 파일들 (가이드 참고용)

---

## 🚀 Windows에서 빌드 방법

### Step 1: 파일 복사

Windows PC의 임시 폴더에 복사:
```
C:\Temp\T-50B\  (또는 원하는 위치)
```

**복사할 폴더 구조:**
```
T-50B/
├── entry.lua
├── T-50B.lua
└── EFM/
    ├── CMakeLists.txt
    ├── build_windows_simple.bat
    └── source/
        ├── T50.cpp
        ├── T50.h
        ├── FBW.cpp
        ├── FBW.h
        ├── Utility.h
        ├── Inputs.h
        ├── FM/
        │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h
        └── Cockpit/
            └── CockpitAPI_Declare.h
```

### Step 2: 빌드 실행

1. **`EFM` 폴더로 이동**
   ```cmd
   cd C:\Temp\T-50B\EFM
   ```

2. **빌드 스크립트 실행**
   ```cmd
   build_windows_simple.bat
   ```

3. **DLL 확인**
   ```
   build\bin\Release\T50_EFM.dll
   ```

### Step 3: DLL 복사

빌드된 DLL을 DCS 모드 폴더로 복사:
```
build\bin\Release\T50_EFM.dll
→
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll
```

---

## 📁 최소 복사 파일 목록 (간단 버전)

빌드만 하려면 이것만 복사:

```
EFM/
├── CMakeLists.txt
├── build_windows_simple.bat
└── source/
    ├── T50.cpp
    ├── T50.h
    ├── FBW.cpp
    ├── FBW.h
    ├── Utility.h
    ├── Inputs.h
    ├── FM/
    │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h
    └── Cockpit/
        └── CockpitAPI_Declare.h
```

---

## ⚠️ 중요 사항

### 1. 폴더 구조 유지
- `source/FM/` 폴더 구조 유지 필수
- `source/Cockpit/` 폴더 구조 유지 필수
- 파일 경로가 중요함

### 2. 파일명 정확히
- 대소문자 구분 (Windows는 보통 무시하지만)
- 확장자 정확히 (.cpp, .h 등)

### 3. 빌드 전 확인
- Visual Studio 설치 확인
- CMake 설치 확인
- DCS SDK 경로 확인 (build_windows_simple.bat에서 수정)

---

## 💡 빠른 복사 방법

### 방법 1: 전체 폴더 복사
```
T-50B/ 폴더 전체를 Windows로 복사
```

### 방법 2: 필수 파일만 선택 복사
위의 체크리스트대로 선택 복사

---

## ✅ 복사 후 확인

Windows에서 복사 후 확인:
```cmd
cd C:\Temp\T-50B\EFM
dir /s *.cpp *.h CMakeLists.txt build_windows*.bat
```

모든 파일이 보이면 준비 완료!

