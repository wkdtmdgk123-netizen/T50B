# 디버깅 결과 - 발견된 문제점

## 🔍 발견된 주요 버그

### 1. ❌ 중복 엔진 처리 코드 (심각)
**위치**: `T50.cpp` 616-834줄
**문제**: 단발 엔진인데도 엔진 처리 코드가 두 번 반복됨
- 첫 번째: 616-720줄 (left 엔진 코드)
- 두 번째: 729-834줄 (right 엔진 코드)
**영향**: 엔진 상태가 두 번 처리되어 잘못된 동작 가능

### 2. ❌ 중복 변수 할당
**위치**: `ed_fm_cold_start()`, `ed_fm_hot_start()` 등
**문제**: 같은 변수를 두 번 할당
```cpp
T50::engine_switch = false;
T50::engine_switch = false;  // 중복
T50::engine_state = T50::OFF;
T50::engine_state = T50::OFF;  // 중복
```

### 3. ❌ 중복 체크 로직
**위치**: `T50.cpp` 836-852줄
**문제**: 연료 부족과 엔진 무결성 체크가 각각 두 번 반복
```cpp
if (T50::internal_fuel <= 25 && ...) { ... }
if (T50::internal_fuel <= 25 && ...) { ... }  // 중복
```

### 4. ❌ 중복 곱셈
**위치**: `T50.cpp` 854-855줄
**문제**: engine_power_readout을 두 번 곱함
```cpp
T50::engine_power_readout *= T50::engine_integrity;
T50::engine_power_readout *= T50::engine_integrity;  // 중복
```

### 5. ⚠️ 변수명 혼란
**위치**: `T50.cpp` 645, 758줄
**문제**: 단발 엔진인데 left_target_throttle, right_target_throttle 사용
**영향**: 코드 가독성 저하

### 6. ⚠️ 불필요한 변수
**위치**: `T50.cpp` 708, 822줄
**문제**: left_rps, right_rps 계산하지만 단발 엔진
**영향**: 혼란스러운 코드

---

## 🔧 수정 필요 사항

1. ✅ 중복 엔진 코드 제거 (단발 엔진으로 통합)
2. ✅ 중복 변수 할당 제거
3. ✅ 중복 체크 로직 제거
4. ✅ 중복 곱셈 제거
5. ✅ 변수명 수정 (left/right → 단일)
6. ✅ 디버깅 코드 추가


