# T-50B FBW (Fly-By-Wire) 시스템

## ✅ FBW 시스템 구현 완료!

T-50B Golden Eagle을 위한 고급 Fly-By-Wire 제어 시스템을 구현했습니다.

---

## 🎯 구현된 기능

### 1. ✅ 명령 필터링 (Command Filtering)
- **피치 명령 필터**: 0.1초 시정수
- **롤 명령 필터**: 0.08초 시정수
- **요 명령 필터**: 0.12초 시정수
- **효과**: 조종 입력의 급격한 변화 완화, 부드러운 제어

### 2. ✅ 각속도 제한 (Rate Limiting)
- **최대 피치 각속도**: 40 deg/s
- **최대 롤 각속도**: 120 deg/s
- **최대 요 각속도**: 30 deg/s
- **효과**: 항공기 구조 보호, 안정성 향상

### 3. ✅ 공격각 보호 (Alpha Protection)
- **정상 비행 최대 AoA**: 25도
- **비상 최대 AoA**: 35도
- **보호 게인**: 2.0
- **효과**: 실속 방지, 안전한 비행

### 4. ✅ 스톨 보호 (Stall Protection)
- **스톨 경고 AoA**: 20도
- **보호 게인**: 3.0
- **효과**: 스톨 진입 방지, 자동 복구

### 5. ✅ 스핀 방지 (Spin Prevention)
- **스핀 조건 감지**: 고공격각 + 고사이드슬립 + 고롤 각속도
- **보호 게인**: 1.5
- **사이드슬립 제한**: ±15도
- **효과**: 스핀 진입 방지

### 6. ✅ G 제한 (G Limiting)
- **최대 양의 G**: +9.0G
- **최대 음의 G**: -3.0G
- **효과**: 조종사 및 항공기 구조 보호

### 7. ✅ FBW 모드 관리
- **NORMAL**: 정상 FBW 작동
- **DIRECT**: 직접 제어 (FBW 우회)
- **DEGRADED**: 성능 저하 모드
- **FAILED**: FBW 고장

---

## 📁 파일 구조

```
EFM/source/
├── FBW.h          ✅ FBW 시스템 헤더
├── FBW.cpp        ✅ FBW 시스템 구현
└── T50.cpp        ✅ FBW 통합 완료
```

---

## 🔧 FBW 시스템 작동 방식

### 입력 처리 흐름

```
조종 입력 (Joystick)
    ↓
명령 필터링 (Command Filtering)
    ↓
보호 시스템 적용
    ├─ 공격각 보호
    ├─ 스톨 보호
    ├─ 스핀 방지
    └─ G 제한
    ↓
각속도 제한 (Rate Limiting)
    ↓
제어면 명령 출력
```

### 보호 시스템 우선순위

1. **G 제한** - 최우선 (조종사 보호)
2. **공격각 보호** - 실속 방지
3. **스톨 보호** - 스톨 진입 방지
4. **스핀 방지** - 스핀 방지

---

## ⚙️ FBW 설정 (FBWConfig)

### 기본 설정값

```cpp
// 각속도 제한
max_pitch_rate = 40.0 deg/s
max_roll_rate = 120.0 deg/s
max_yaw_rate = 30.0 deg/s

// 공격각 제한
alpha_max_normal = 25.0 deg
alpha_max_emergency = 35.0 deg
alpha_stall_warning = 20.0 deg

// 사이드슬립 제한
beta_max = 15.0 deg

// G 제한
g_max_positive = 9.0G
g_max_negative = -3.0G

// 필터 시정수
pitch_filter_tau = 0.1 sec
roll_filter_tau = 0.08 sec
yaw_filter_tau = 0.12 sec
```

### 설정 변경 방법

`FBW.cpp`의 `g_fbw_config` 구조체에서 값 수정:

```cpp
namespace FBW {
    FBWConfig g_fbw_config;
    
    // 예: 공격각 제한 변경
    g_fbw_config.alpha_max_normal = 30.0;  // 25도 → 30도
}
```

---

## 🎮 FBW 모드 전환

### 프로그래밍 방식

```cpp
// FBW 비활성화 (직접 제어)
FBW::set_mode(FBWMode::DIRECT);

// FBW 활성화
FBW::set_mode(FBWMode::NORMAL);

// FBW 상태 확인
if (FBW::is_enabled()) {
    // FBW 작동 중
}
```

---

## 📊 보호 시스템 상태 확인

### 프로그래밍 방식

```cpp
// 공격각 제한 활성화 여부
if (FBW::is_alpha_limiting_active()) {
    // 공격각 제한 작동 중
}

// 스톨 보호 활성화 여부
if (FBW::is_stall_protection_active()) {
    // 스톨 보호 작동 중
}

// 스핀 방지 활성화 여부
if (FBW::is_spin_prevention_active()) {
    // 스핀 방지 작동 중
}

// G 제한 활성화 여부
if (FBW::is_g_limiting_active()) {
    // G 제한 작동 중
}
```

---

## 🔍 디버깅

### FBW 상태 로깅

```cpp
// T50.cpp에서
if (g_debug_enabled) {
    if (FBW::is_alpha_limiting_active()) {
        DEBUG_LOG("Alpha limiting active");
    }
    if (FBW::is_stall_protection_active()) {
        DEBUG_LOG("Stall protection active");
    }
}
```

---

## 📈 성능 특성

### 반응 속도
- **명령 필터링**: 부드러운 입력 처리
- **각속도 제한**: 빠른 반응 + 안정성
- **보호 시스템**: 실시간 작동

### 안정성
- **공격각 보호**: 실속 방지
- **스톨 보호**: 자동 복구
- **스핀 방지**: 비정상 자세 방지
- **G 제한**: 구조 보호

---

## 🎯 T-50B 특화 기능

### 훈련기 특성 반영
- **안전 우선**: 보호 시스템 강화
- **학습 친화적**: 예측 가능한 반응
- **복구 용이**: 자동 보호 기능

### 현대적 FBW
- **디지털 제어**: 정밀한 제어 법칙
- **다중 보호**: 여러 보호 시스템 동시 작동
- **적응형**: 비행 조건에 따른 자동 조정

---

## ⚠️ 주의사항

### FBW 비활성화
- FBW를 비활성화하면 보호 시스템도 비활성화됨
- 직접 제어 모드에서는 조종사가 모든 제어 담당
- 훈련 목적이 아닌 경우 권장하지 않음

### 설정 조정
- 보호 시스템 게인을 너무 높이면 반응이 둔해질 수 있음
- 각속도 제한을 너무 낮추면 기동성이 저하됨
- 실제 T-50B 데이터로 튜닝 권장

---

## 🔄 기존 시스템과의 통합

### 기존 제어 시스템
- ✅ 자동 트림 (Autotrim) - 유지
- ✅ 감쇠 계수 (Kd) - 유지
- ✅ 마하수별 감도 조정 - 유지

### FBW 추가 기능
- ✅ 명령 필터링 - 추가
- ✅ 각속도 제한 - 추가
- ✅ 고급 보호 시스템 - 추가

---

## 📝 요약

### 구현 완료
- ✅ 명령 필터링
- ✅ 각속도 제한
- ✅ 공격각 보호
- ✅ 스톨 보호
- ✅ 스핀 방지
- ✅ G 제한
- ✅ 모드 관리

### 통합 완료
- ✅ T50.cpp에 통합
- ✅ CMakeLists.txt 업데이트
- ✅ 컴파일 성공

### 준비 완료
- ✅ Windows 빌드 준비
- ✅ 디버깅 가능
- ✅ 설정 가능

---

## 🚀 다음 단계

1. ✅ FBW 시스템 구현 완료
2. ⏳ Windows에서 빌드
3. ⏳ DCS에서 테스트
4. ⏳ FBW 파라미터 튜닝
5. ⏳ 실제 비행 데이터와 비교

---

## 💡 팁

### FBW 튜닝
- 공격각 제한: 실제 T-50B 사양 확인
- 각속도 제한: 조종사 피드백에 따라 조정
- 보호 게인: 너무 강하면 반응 둔화

### 디버깅
- 보호 시스템 활성화 시 로그 확인
- 각속도 제한 도달 시 로그 확인
- FBW 모드 변경 추적

---

**FBW 시스템 구현 완료!** 🎉

T-50B는 이제 현대적인 Fly-By-Wire 제어 시스템을 갖추었습니다!


