# T-50B FBW 시스템 기능 상세

## 🎯 구현된 FBW 기능 목록

### ✅ 핵심 기능

1. **명령 필터링 (Command Filtering)**
   - 피치, 롤, 요 명령 각각 독립 필터
   - 시정수 조정 가능
   - 급격한 입력 변화 완화

2. **각속도 제한 (Rate Limiting)**
   - 피치: 40 deg/s
   - 롤: 120 deg/s
   - 요: 30 deg/s
   - 구조 보호 및 안정성 향상

3. **공격각 보호 (Alpha Protection)**
   - 정상: 25도 제한
   - 비상: 35도 허용
   - 자동 피치 다운

4. **스톨 보호 (Stall Protection)**
   - 20도부터 경고
   - 자동 복구 명령
   - 스톨 진입 방지

5. **스핀 방지 (Spin Prevention)**
   - 스핀 조건 감지
   - 자동 요 보정
   - 사이드슬립 제한 (±15도)

6. **G 제한 (G Limiting)**
   - +9.0G / -3.0G 제한
   - 자동 피치 제한
   - 조종사 보호

7. **FBW 모드 관리**
   - NORMAL: 정상 작동
   - DIRECT: 직접 제어
   - DEGRADED: 성능 저하
   - FAILED: 고장

---

## 🔧 기술적 세부사항

### 명령 필터링 알고리즘

```cpp
// 1차 저역 통과 필터
filtered = filtered + alpha * (input - filtered)
alpha = dt / (tau + dt)
```

**효과**:
- 급격한 조종 입력 완화
- 부드러운 제어면 움직임
- 진동 감소

### 각속도 제한 알고리즘

```cpp
max_change = max_rate * dt
if (|rate_error| > max_change) {
    rate = current_rate ± max_change
}
```

**효과**:
- 구조적 한계 보호
- 예측 가능한 반응
- 안정성 향상

### 공격각 보호 알고리즘

```cpp
if (alpha > alpha_max && pitch_cmd > 0) {
    protection_cmd = -alpha_excess * gain
    pitch_cmd += protection_cmd
}
```

**효과**:
- 실속 방지
- 안전한 기동
- 자동 복구

---

## 📊 보호 시스템 작동 조건

### 공격각 보호
- **활성화**: AoA > 25도 (정상) 또는 > 35도 (비상)
- **조건**: 피치 업 명령 입력 시
- **동작**: 자동 피치 다운

### 스톨 보호
- **활성화**: AoA > 20도
- **조건**: 스톨 방향 명령 입력 시
- **동작**: 명령 감소

### 스핀 방지
- **활성화**: 
  - AoA > 30도 AND
  - Beta > 20도 AND
  - Roll Rate > 60 deg/s
- **동작**: 반대 방향 요 보정

### G 제한
- **활성화**: G > +9.0G 또는 G < -3.0G
- **조건**: 제한 초과 방향 명령 입력 시
- **동작**: 명령 제한

---

## 🎮 사용 예시

### 기본 사용 (자동)
FBW는 자동으로 작동합니다. 별도 설정 불필요.

### FBW 비활성화
```cpp
FBW::set_mode(FBWMode::DIRECT);
```

### 보호 시스템 개별 비활성화
```cpp
// FBW.cpp에서
g_fbw_config.alpha_protection_enabled = false;
g_fbw_config.stall_protection_enabled = false;
g_fbw_config.spin_prevention_enabled = false;
```

### 설정 조정
```cpp
// 더 민감한 제어
g_fbw_config.max_pitch_rate = 50.0;  // 40 → 50 deg/s

// 더 강한 보호
g_fbw_config.alpha_protection_gain = 3.0;  // 2.0 → 3.0
```

---

## 🔍 디버깅 정보

### 보호 시스템 상태
- `FBW::is_alpha_limiting_active()` - 공격각 제한 작동 중
- `FBW::is_stall_protection_active()` - 스톨 보호 작동 중
- `FBW::is_spin_prevention_active()` - 스핀 방지 작동 중
- `FBW::is_g_limiting_active()` - G 제한 작동 중

### FBW 모드
- `FBW::get_mode()` - 현재 FBW 모드
- `FBW::is_enabled()` - FBW 활성화 여부

---

## ✅ 구현 완료 체크리스트

- [x] 명령 필터링
- [x] 각속도 제한
- [x] 공격각 보호
- [x] 스톨 보호
- [x] 스핀 방지
- [x] G 제한
- [x] 모드 관리
- [x] T50.cpp 통합
- [x] 컴파일 성공
- [x] 문서화

---

## 🎉 결론

**완전한 FBW 시스템 구현 완료!**

T-50B는 이제 현대적인 Fly-By-Wire 제어 시스템을 갖추었으며, 다양한 보호 기능으로 안전하고 예측 가능한 비행이 가능합니다!


