# Windows로 파일 복사 가이드

## 📋 복사할 파일 목록

### ✅ 필수 파일 (반드시 복사)

#### EFM 폴더 구조
```
EFM/
├── CMakeLists.txt                    ← 빌드 설정
├── build_windows_simple.bat          ← 빌드 스크립트
│
└── source/
    ├── T50.cpp                       ← 메인 EFM 코드
    ├── T50.h                         ← EFM 헤더
    ├── FBW.cpp                       ← FBW 시스템
    ├── FBW.h                         ← FBW 헤더
    ├── Utility.h                     ← 유틸리티 함수
    ├── Inputs.h                      ← 입력 정의
    │
    ├── FM/
    │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h  ← DCS SDK 스텁
    │
    └── Cockpit/
        └── CockpitAPI_Declare.h      ← 조종석 API 스텁
```

#### DCS 모드 파일
```
T-50B/
├── entry.lua                         ← DCS 진입점
└── T-50B.lua                         ← 항공기 정의
```

---

## 🚀 복사 방법

### 방법 1: 전체 폴더 복사 (권장)

1. **전체 `T-50B` 폴더를 Windows로 복사**
   - USB, 네트워크 드라이브, 클라우드 등 사용

2. **Windows에서 확인**
   ```cmd
   cd C:\Temp\T-50B\EFM
   COPY_FILES.bat
   ```

### 방법 2: 필수 파일만 선택 복사

위 목록의 파일만 선택하여 복사

---

## ✅ 복사 후 확인

Windows에서:
```cmd
cd C:\Temp\T-50B\EFM
COPY_FILES.bat
```

모든 파일이 [OK]로 표시되면 준비 완료!

---

## 🔧 빌드 실행

파일 복사 후:
```cmd
cd C:\Temp\T-50B\EFM
build_windows_simple.bat
```

---

## 📍 DLL 위치

빌드 성공 시:
```
EFM\build\bin\Release\T50_EFM.dll
```

이 파일을 DCS 모드 폴더로 복사:
```
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll
```

