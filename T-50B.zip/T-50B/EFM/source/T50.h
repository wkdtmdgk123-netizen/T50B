/*    T-50B Golden Eagle
    Based on F-22A Raptor EFM by Branden Hooper
    Converted to T-50B specifications

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see https://www.gnu.org/licenses.
    */

    // T50.h : External Flight Model for T-50B Golden Eagle

#pragma once

#include <unordered_map>
#include <string>
#include <cstddef> 
#include <array>
#include <map>

    // ----- Aerodynamics, etc. -----

namespace FM_DATA
{
    static inline std::array<double, 13> mach_table = {
        0.0, 0.2, 0.4, 0.6, 0.8, 1.0, 1.2, 1.4, 1.5, 1.5, 1.5, 1.5, 1.5
    };

    double Cy0 = 0.006;

    double Czbe = -0.025;

    double cx_gear = 0.12;
    double cx_brk = 0.055;
    double cx_flap = 0.038;
    double cy_flap = 0.042;

    // T-50B aerodynamic coefficients (adjusted for smaller, lighter aircraft)
    double cx0[] = { 0.012, 0.0125, 0.013, 0.018, 0.030, 0.042, 0.040, 0.038, 0.036, 0.035, 0.034, 0.033, 0.032 };
    double Cya[] = { 0.018, 0.060, 0.075, 0.070, 0.065, 0.060, 0.055, 0.050, 0.045, 0.040, 0.038, 0.036, 0.034 };
    double OmxMax[] = { 1.8, 2.6, 3.4, 4.8, 4.2, 3.5, 2.8, 2.4, 2.1, 1.9, 1.8, 1.7, 1.6 };
    double Aldop[] = { 55, 52.5, 50, 45, 40, 35, 32, 30, 28, 28, 28, 28, 28 };
    double CyMax[] = { 1.6, 1.65, 1.7, 1.65, 1.55, 1.4, 1.3, 1.2, 1.1, 1.05, 1.0, 0.95, 0.9 };


    double AoA_table[] = { 0.0, 10.0, 20.0, 30.0, 40.0, 50.0, 60.0, 70.0, 80.0, 90.0 };
    double AoA_drag_factor[] = { 0.0, 0.004, 0.018, 0.075, 0.15, 0.25, 0.38, 0.55, 0.65, 0.75 };

    double beta_table[] = { 0.0, 5.0, 10.0, 20.0, 30.0 };
    double Cy_beta[] = { 0.0, 0.04, 0.08, 0.16, 0.24 };

    // T-50B F404-GE-102 engine thrust (single engine, ~78kN MIL, ~130kN AB)
    static inline std::array<double, 13> idle_thrust = {
        3000, 4000, 5000, 5500, 6000, 6500, 7000, 7000, 7000, 7000, 7000, 7000, 7000
    };

    static inline std::array<double, 13> max_thrust = {
        58000, 58500, 59000, 62000, 70000, 78000, 85000, 90000, 95000, 98000, 100000, 100000, 100000
    };

    static inline std::array<double, 13> ab_thrust = {
        98000, 105000, 112000, 120000, 125000, 130000, 132000, 133000, 134000, 135000, 135000, 135000, 135000
    };

    double elevator_rate_table[] = { 1.5, 1.5, 1.4, 1.1, 1.0, 0.95, 0.95, 1.0, 1.1, 1.1, 1.1, 1.1, 1.1 };
    double max_elevator_deflection[] = { 25.0, 24.0, 20.0, 15.0, 12.0, 11.0, 10.0, 10.0, 11.0, 11.0, 11.0, 11.0, 11.0 };
    const double max_aileron_rate = 16.0;
    // Thrust Vectoring removed for T-50B
    double Kd_pitch[] = { 0.7, 0.69, 0.68, 0.85, 1.3, 2.0, 2.3, 2.6, 2.9, 2.9, 2.9, 2.9, 2.9 };
    double Kd_roll[] = { 0.55, 0.38, 0.35, 0.31, 0.35, 0.39, 0.44, 0.54, 0.64, 0.76, 0.87, 0.90, 0.83 };
    double Kd_yaw[] = { 2.1, 2.1, 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1 };
}

    // ----- EFM Data -----

namespace T50 {
    Vec3 common_force, common_moment, center_of_mass, wind, velocity_world, airspeed;
    double const pi = 3.1415926535897932384626433832795;
    double const rad_to_deg = 180.0 / pi;
    inline double rad(double deg) { return deg * pi / 180.0; }

    // T-50B specifications
    double const S = 25.3;  // Wing area in m²
    double const wingspan = 9.45, length = 13.14, height = 4.94;
    double idle_rpm = 0.68;
    double const empty_mass = 6470;  // Empty weight in kg

    Vec3 left_wing_pos(center_of_mass.x - 0.6, center_of_mass.y + 0.4, -wingspan / 2);
    Vec3 right_wing_pos(center_of_mass.x - 0.6, center_of_mass.y + 0.4, wingspan / 2);
    Vec3 tail_pos(center_of_mass.x - 0.7, center_of_mass.y, 0);
    Vec3 elevator_pos(-length / 2, center_of_mass.y, 0);
    Vec3 left_aileron_pos(center_of_mass.x, center_of_mass.y, -wingspan * 0.5);
    Vec3 right_aileron_pos(center_of_mass.x, center_of_mass.y, wingspan * 0.5);
    Vec3 rudder_pos(-length / 2, height / 2, 0);
    Vec3 engine_pos(-length / 2 + 1.0, 0, 0);  // Single engine, centered

    double pitch_input = 0, pitch_discrete = 0, pitch_trim = 0;
    double elevator_command = 0;
    double elevator_angle = 0.0;
    bool pitch_analog = true;
    double roll_input = 0, roll_discrete = 0, roll_trim = 0, aileron_command = 0;
    double left_aileron_angle = 0.0;
    double right_aileron_angle = 0.0;
    bool roll_analog = true;
    double yaw_input = 0, yaw_discrete = 0, yaw_trim = 0, rudder_command = 0;
    bool yaw_analog = true;
    static double beta_integral = 0.0;

    // Single engine system
    bool engine_switch = false;
    double throttle_input = 0, throttle_output = 0, engine_power_readout = 0, thrust_force = 0;
    double ab_timer = 0;

    bool airbrake_switch = false, flaps_switch = false;
    double airbrake_pos = 0, flaps_pos = 0, slats_pos = 0;
    bool gear_switch = false;
    double gear_pos = 0;
    double wheel_brake = 0;
    double landing_brake_assist = 0;

    // T-50B fuel capacity
    const double max_internal_fuel = 2500.0;  // kg
    const double max_external_fuel = 0.0;  // No external tanks for T-50B
    const double ground_refuel_rate = 30.0;
    const double min_usable_fuel = 20.0;
    double internal_fuel = 0, external_fuel = 0, total_fuel = internal_fuel + external_fuel;
    double fuel_consumption_since_last_time = 0;
    const double fuel_rate_idle = 0.06;
    const double fuel_rate_mil = 1.2;
    const double fuel_rate_ab = 3.5;
    double fuel_rate = 0.0;
    double fuel_rate_kg_s;
    bool external_tanks_equipped = false;
    std::map<int, double> external_fuel_stations;

    double atmosphere_density = 1.225, altitude_ASL = 0, altitude_AGL = 0, V_scalar = 0;
    double speed_of_sound = 320, mach = 0;
    double engine_alt_effect = 1, atmosphere_temperature = 273;
    double aoa = 0, alpha = 0, aos = 0, beta = 0, g = 0;
    bool on_ground = false;
    double pitch = 0, pitch_rate = 0, roll = 0, roll_rate = 0, heading = 0, yaw_rate = 0;

    double element_integrity[111];
    double left_wing_integrity = 1.0, right_wing_integrity = 1.0, tail_integrity = 1.0, elevator_integrity = 1.0;
    double engine_integrity = 1.0;
    double total_damage = 1 - (left_wing_integrity + right_wing_integrity + tail_integrity +
        engine_integrity + elevator_integrity) / 5;
    bool is_destroyed = false;

    bool invincible = true, infinite_fuel = false, easy_flight = false;
    double shake_amplitude = 0, fm_clock = 0;
    bool sim_initialised = false;

    double ref_roll = 0, ref_heading = 0;
    double roll_error_i = 0, yaw_error_i = 0;
    double last_aileron_cmd = 0, last_elevator_cmd = 0, last_rudder_cmd = 0;
    bool autotrim_active = false;
    double last_g = 0.0;
    double autotrim_elevator_cmd = 0.0;
    bool manual_trim_applied = false;
    double takeoff_trim_cmd = 0.0;

    double g_assist_pos = 0;
    double g_limit_positive = 9.0;  // T-50B G limit
    double g_limit_negative = -3.0;

    double last_yaw_input = 0.0;
    double last_pitch_input = 0.0;
    double ground_speed_knots = 0.0;

    enum EngineState { OFF, STARTING, RUNNING, SHUTDOWN };
    EngineState engine_state = OFF;
    double engine_start_timer = 0.0;

    const double engine_start_time = 40.0;
    const double starter_phase_duration = 10.0;
    const double ignition_phase_duration = 16.0;
    const double spool_up_phase_duration = 14.0;
    const double starter_rpm = 0.2;
    const double ignition_rpm = 0.4;
    const double starter_rate = starter_rpm / starter_phase_duration;
    const double ignition_rate = (ignition_rpm - starter_rpm) / ignition_phase_duration;
    const double spool_up_rate = (idle_rpm - ignition_rpm) / spool_up_phase_duration;
    double engine_phase = 0.0;

    bool taxi_lights = false;
    bool landing_lights = false;
    bool form_light = false;
    bool nav_white = false;
    bool anti_collision = false;
    bool aar_light = false;
    bool nav_lights = false;
    double anti_collision_timer = 0.0;
    bool anti_collision_blink = false;
    double nav_white_timer = 0.0;
    bool nav_white_blink = false;
    double nav_lights_timer = 0.0;
    bool nav_lights_blink = false;
    const double blink_on_time = 0.10;
    const double blink_off_time = 1.50;
    const double blink_period = blink_on_time + blink_off_time;
    static double aileron_animation_command;

    static double smoothed_pitch_discrete;
    static double smoothed_roll_discrete;
    static double smoothed_yaw_discrete;

    // Smoke system - color selection
    int smoke_color_mode = 0;  // 0=off, 1=red, 2=green, 3=blue, 4=white, 5=yellow, 6=orange
    bool smoke_active = false;

}

    // ----- Damage Elements -----

enum class DamageElement : size_t {
    NoseCenter = 0,
    NoseLeft = 1,
    NoseRight = 2,
    Cockpit = 3,
    CabinLeft = 4,
    CabinRight = 5,
    CabinBottom = 6,
    Gun = 7,
    FrontGear = 8,
    FuselageLeft = 9,
    FuselageRight = 10,
    EngineIn = 11,
    NacelleBottom = 13,
    GearLeft = 15,
    GearRight = 16,
    Nacelle = 17,
    AirbrakeLeft = 19,
    AirbrakeRight = 20,
    SlatOutLeft = 21,
    SlatOutRight = 22,
    WingOutLeft = 23,
    WingOutRight = 24,
    AileronLeft = 25,
    AileronRight = 26,
    SlatCentreLeft = 27,
    SlatCentreRight = 28,
    WingCentreLeft = 29,
    WingCentreRight = 30,
    FlapOutLeft = 31,
    FlapOutRight = 32,
    SlatInLeft = 33,
    SlatInRight = 34,
    WingInLeft = 35,
    WingInRight = 36,
    FlapInLeft = 37,
    FlapInRight = 38,
    FinTopLeft = 39,
    FinTopRight = 40,
    FinCentreLeft = 41,
    FinCentreRight = 42,
    FinBottomLeft = 43,
    FinBottomRight = 44,
    StabilizerOutLeft = 45,
    StabilizerOutRight = 46,
    StabilizerInLeft = 47,
    StabilizerInRight = 48,
    ElevatorOutLeft = 49,
    ElevatorOutRight = 50,
    ElevatorInLeft = 51,
    ElevatorInRight = 52,
    RudderLeft = 53,
    RudderRight = 54,
    Tail = 55,
    TailLeft = 56,
    TailRight = 57,
    TailBottom = 58,
    NoseBottom = 59,
    Pitot = 60,
    FuelTankFront = 61,
    FuelTankBack = 62,
    Rotor = 63,
    Blade1In = 64,
    Blade1Centre = 65,
    Blade1Out = 66,
    Blade2In = 67,
    Blade2Centre = 68,
    Blade2Out = 69,
    Blade3In = 70,
    Blade3Centre = 71,
    Blade3Out = 72,
    Blade4In = 73,
    Blade4Centre = 74,
    Blade4Out = 75,
    Blade5In = 76,
    Blade5Centre = 77,
    Blade5Out = 78,
    Blade6In = 79,
    Blade6Centre = 80,
    Blade6Out = 81,
    FuselageBottom = 82,
    WheelNose = 83,
    WheelLeft = 84,
    WheelRight = 85,
    Payload1 = 86,
    Payload2 = 87,
    Payload3 = 88,
    Payload4 = 89,
    Crew1 = 90,
    Crew2 = 91,
    Crew3 = 92,
    Crew4 = 93,
    ArmorNoseLeft = 94,
    ArmorNoseRight = 95,
    ArmorLeft = 96,
    ArmorRight = 97,
    Hook = 98,
    TailTop = 100,
    FlapCentreLeft = 101,
    FlapCentreRight = 102,
    Engine1 = 103,
    Engine2 = 104,
    Engine3 = 105,
    Engine4 = 106,
    Engine5 = 107,
    Engine6 = 108,
    Engine7 = 109,
    Engine8 = 110,
    WingL00 = 111,
    WingL01 = 112,
    WingL02 = 113,
    WingL03 = 114,
    WingL04 = 115,
    WingL05 = 116,
    WingL06 = 117,
    WingL07 = 118,
    WingL08 = 119,
    WingL09 = 120,
    WingL10 = 121,
    WingL11 = 122,
    WingR00 = 123,
    WingR01 = 124,
    WingR02 = 125,
    WingR03 = 126,
    WingR04 = 127,
    WingR05 = 128,
    WingR06 = 129,
    WingR07 = 130,
    WingR08 = 131,
    WingR09 = 132,
    WingR10 = 133,
    WingR11 = 134,
    LaunchBar = 135,
    TailRotor = 136
};

    // ----- Cockpit Logic -----

class CockpitManager {
public:
    CockpitManager();
    ~CockpitManager() = default;

    void initialize();

    void update(double dt);

    void updateDrawArgs(float* drawargs, size_t size);

private:
    EDPARAM param_api_;
    std::unordered_map<std::string, void*> param_handles_;
    std::unordered_map<int, float> draw_args_;

    void updateGearLights(double dt);
    void updateTaxiLandingLights(double dt);
    void updateAARLight(double dt);
    void updateFormationLights(double dt);
    void updateNavAntiCollisionLights(double dt);

    double getParameter(const std::string& name, double fallback_value = 0.0);
};

