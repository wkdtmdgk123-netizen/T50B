/*    Utility.h
    Utility functions and structures for T-50B EFM
*/

#pragma once

#include <cmath>
#include <algorithm>

// Vec3 structure for 3D vectors
struct Vec3 {
    double x, y, z;
    
    Vec3() : x(0), y(0), z(0) {}
    Vec3(double x_, double y_, double z_) : x(x_), y(y_), z(z_) {}
    
    Vec3 operator+(const Vec3& other) const {
        return Vec3(x + other.x, y + other.y, z + other.z);
    }
    
    Vec3 operator-(const Vec3& other) const {
        return Vec3(x - other.x, y - other.y, z - other.z);
    }
    
    Vec3 operator*(double scalar) const {
        return Vec3(x * scalar, y * scalar, z * scalar);
    }
    
    Vec3& operator+=(const Vec3& other) {
        x += other.x;
        y += other.y;
        z += other.z;
        return *this;
    }
};

// Cross product of two vectors
inline Vec3 cross(const Vec3& a, const Vec3& b) {
    return Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}

// Limit value between min and max
template<typename T, typename U, typename V>
inline T limit(T value, U min_val, V max_val) {
    if (value < static_cast<T>(min_val)) return static_cast<T>(min_val);
    if (value > static_cast<T>(max_val)) return static_cast<T>(max_val);
    return value;
}

// Linear interpolation
template<typename T>
inline double lerp(const T* table, const double* values, size_t size, double x) {
    if (size == 0) return 0.0;
    if (size == 1) return values[0];
    
    if (x <= table[0]) return values[0];
    if (x >= table[size - 1]) return values[size - 1];
    
    for (size_t i = 0; i < size - 1; ++i) {
        if (x >= table[i] && x <= table[i + 1]) {
            double t = (x - table[i]) / (table[i + 1] - table[i]);
            return values[i] + t * (values[i + 1] - values[i]);
        }
    }
    
    return values[size - 1];
}

// Actuator function - moves current value towards target at specified rate
inline double actuator(double current, double target, double rate_down, double rate_up) {
    double delta = target - current;
    double rate = (delta > 0) ? rate_up : rate_down;
    double change = limit(delta, -std::abs(rate), std::abs(rate));
    return current + change;
}

// Slew rate limiter
inline double slew_rate_limit(double current, double target, double rate, double dt) {
    double max_change = rate * dt;
    double delta = target - current;
    if (std::abs(delta) <= max_change) {
        return target;
    }
    return current + (delta > 0 ? max_change : -max_change);
}

