/*    Inputs.h
    Input command definitions for T-50B EFM
*/

#pragma once

// Joystick input commands
enum {
    JoystickPitch = 2001,
    JoystickRoll = 2002,
    PedalYaw = 2003,
    
    PitchUp = 2004,
    PitchUpStop = 2005,
    PitchDown = 2006,
    PitchDownStop = 2007,
    
    RollLeft = 2008,
    RollLeftStop = 2009,
    RollRight = 2010,
    RollRightStop = 2011,
    
    rudderleft = 2012,
    rudderleftstop = 2013,
    rudderright = 2014,
    rudderrightstop = 2015,
    
    trimUp = 2016,
    trimDown = 2017,
    trimLeft = 2018,
    trimRight = 2019,
    resetTrim = 2020,
    
    ruddertrimLeft = 2021,
    ruddertrimRight = 2022,
    
    EnginesOn = 2023,
    EnginesOff = 2024,
    LeftEngineOn = 2025,
    LeftEngineOff = 2026,
    RightEngineOn = 2027,
    RightEngineOff = 2028,
    
    ThrottleAxis = 2029,
    ThrottleAxisLeft = 2030,
    ThrottleAxisRight = 2031,
    ThrottleIncrease = 2032,
    ThrottleDecrease = 2033,
    ThrottleLeftUp = 2034,
    ThrottleLeftDown = 2035,
    ThrottleRightUp = 2036,
    ThrottleRightDown = 2037,
    
    AirBrakes = 2038,
    AirBrakesOn = 2039,
    AirBrakesOff = 2040,
    
    flapsToggle = 2041,
    flapsDown = 2042,
    flapsUp = 2043,
    
    gearToggle = 2044,
    gearDown = 2045,
    gearUp = 2046,
    
    WheelBrakeOn = 2047,
    WheelBrakeOff = 2048
};

