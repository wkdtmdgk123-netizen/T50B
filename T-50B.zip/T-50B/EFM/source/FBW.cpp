/*    FBW.cpp
    Fly-By-Wire Control System Implementation for T-50B Golden Eagle
*/

#include "FBW.h"
#include "Utility.h"
#include <cmath>
#include <algorithm>

namespace FBW {
    // Global FBW state
    FBWState g_fbw_state;
    FBWConfig g_fbw_config;
    
    void initialize() {
        g_fbw_state.mode = FBWMode::NORMAL;
        g_fbw_state.enabled = true;
        g_fbw_state.pitch_cmd_filtered = 0.0;
        g_fbw_state.roll_cmd_filtered = 0.0;
        g_fbw_state.yaw_cmd_filtered = 0.0;
        g_fbw_state.pitch_rate_limited = 0.0;
        g_fbw_state.roll_rate_limited = 0.0;
        g_fbw_state.yaw_rate_limited = 0.0;
        g_fbw_state.alpha_limiting_active = false;
        g_fbw_state.stall_protection_active = false;
        g_fbw_state.spin_prevention_active = false;
        g_fbw_state.g_limiting_active = false;
    }
    
    void update(double dt) {
        if (!g_fbw_state.enabled || g_fbw_state.mode == FBWMode::FAILED) {
            return;
        }
        
        // Reset protection states
        g_fbw_state.alpha_limiting_active = false;
        g_fbw_state.stall_protection_active = false;
        g_fbw_state.spin_prevention_active = false;
        g_fbw_state.g_limiting_active = false;
    }
    
    double filter_command(double input, double& filtered, double tau, double dt) {
        if (tau <= 0.0) {
            filtered = input;
            return input;
        }
        
        double alpha = dt / (tau + dt);
        filtered = filtered + alpha * (input - filtered);
        return filtered;
    }
    
    double apply_rate_limiting(double cmd, double current_rate, double max_rate, double dt) {
        if (max_rate <= 0.0) return cmd;
        
        double max_change = max_rate * dt;
        double rate_error = cmd - current_rate;
        
        if (std::abs(rate_error) > max_change) {
            return current_rate + (rate_error > 0 ? max_change : -max_change);
        }
        
        return cmd;
    }
    
    double apply_alpha_protection(double pitch_cmd, double dt) {
        if (!g_fbw_config.alpha_protection_enabled) {
            return pitch_cmd;
        }
        
        double alpha_deg = T50::alpha;
        double alpha_max = g_fbw_config.alpha_max_normal;
        
        // Emergency mode: allow higher alpha
        if (T50::g > 6.0 || T50::mach < 0.3) {
            alpha_max = g_fbw_config.alpha_max_emergency;
        }
        
        if (alpha_deg > alpha_max && pitch_cmd > 0.0) {
            g_fbw_state.alpha_limiting_active = true;
            double alpha_excess = alpha_deg - alpha_max;
            double protection_cmd = -alpha_excess * g_fbw_config.alpha_protection_gain * 0.01;
            protection_cmd = limit(protection_cmd, -1.0, 0.0);
            g_fbw_state.alpha_protection_cmd = protection_cmd;
            return limit(pitch_cmd + protection_cmd, -1.0, 1.0);
        }
        else if (alpha_deg < -alpha_max && pitch_cmd < 0.0) {
            g_fbw_state.alpha_limiting_active = true;
            double alpha_excess = -alpha_deg - alpha_max;
            double protection_cmd = alpha_excess * g_fbw_config.alpha_protection_gain * 0.01;
            protection_cmd = limit(protection_cmd, 0.0, 1.0);
            g_fbw_state.alpha_protection_cmd = protection_cmd;
            return limit(pitch_cmd + protection_cmd, -1.0, 1.0);
        }
        
        g_fbw_state.alpha_protection_cmd = 0.0;
        return pitch_cmd;
    }
    
    double apply_stall_protection(double pitch_cmd, double dt) {
        if (!g_fbw_config.stall_protection_enabled) {
            return pitch_cmd;
        }
        
        double alpha_deg = T50::alpha;
        double alpha_warning = g_fbw_config.alpha_stall_warning;
        
        // Stall warning zone
        if (std::abs(alpha_deg) > alpha_warning) {
            double alpha_excess = std::abs(alpha_deg) - alpha_warning;
            double stall_factor = alpha_excess / (g_fbw_config.alpha_max_normal - alpha_warning);
            stall_factor = limit(stall_factor, 0.0, 1.0);
            
            // Reduce pitch command to prevent stall
            if (alpha_deg > 0 && pitch_cmd > 0) {
                g_fbw_state.stall_protection_active = true;
                double protection_cmd = -pitch_cmd * stall_factor * g_fbw_config.stall_protection_gain * 0.1;
                g_fbw_state.stall_protection_cmd = protection_cmd;
                return limit(pitch_cmd + protection_cmd, -1.0, 1.0);
            }
            else if (alpha_deg < 0 && pitch_cmd < 0) {
                g_fbw_state.stall_protection_active = true;
                double protection_cmd = -pitch_cmd * stall_factor * g_fbw_config.stall_protection_gain * 0.1;
                g_fbw_state.stall_protection_cmd = protection_cmd;
                return limit(pitch_cmd + protection_cmd, -1.0, 1.0);
            }
        }
        
        g_fbw_state.stall_protection_cmd = 0.0;
        return pitch_cmd;
    }
    
    double apply_spin_prevention(double yaw_cmd, double roll_cmd, double dt) {
        if (!g_fbw_config.spin_prevention_enabled) {
            return yaw_cmd;
        }
        
        double alpha_deg = T50::alpha;
        double beta_deg = T50::beta;
        double roll_deg = T50::roll * T50::rad_to_deg;
        
        // Spin conditions: high alpha + high beta + high roll rate
        bool spin_condition = (std::abs(alpha_deg) > 30.0) && 
                              (std::abs(beta_deg) > 20.0) && 
                              (std::abs(T50::roll_rate * T50::rad_to_deg) > 60.0);
        
        if (spin_condition) {
            g_fbw_state.spin_prevention_active = true;
            
            // Apply opposite yaw to prevent spin
            double spin_prevention_cmd = -beta_deg * g_fbw_config.spin_prevention_gain * 0.01;
            spin_prevention_cmd = limit(spin_prevention_cmd, -0.5, 0.5);
            g_fbw_state.spin_prevention_cmd = spin_prevention_cmd;
            return limit(yaw_cmd + spin_prevention_cmd, -1.0, 1.0);
        }
        
        // Beta limiting
        if (std::abs(beta_deg) > g_fbw_config.beta_max) {
            double beta_excess = std::abs(beta_deg) - g_fbw_config.beta_max;
            double beta_correction = (beta_deg > 0 ? -1.0 : 1.0) * beta_excess * 0.02;
            g_fbw_state.spin_prevention_cmd = beta_correction;
            return limit(yaw_cmd + beta_correction, -1.0, 1.0);
        }
        
        g_fbw_state.spin_prevention_cmd = 0.0;
        return yaw_cmd;
    }
    
    double apply_g_limiting(double pitch_cmd, double dt) {
        double g_current = T50::g;
        double g_max_pos = g_fbw_config.g_max_positive;
        double g_max_neg = g_fbw_config.g_max_negative;
        
        if (g_current > g_max_pos && pitch_cmd > 0.0) {
            g_fbw_state.g_limiting_active = true;
            double g_excess = g_current - g_max_pos;
            double limiting_cmd = -g_excess * 0.1;
            limiting_cmd = limit(limiting_cmd, -1.0, 0.0);
            g_fbw_state.g_limiting_cmd = limiting_cmd;
            return limit(pitch_cmd + limiting_cmd, -1.0, 1.0);
        }
        else if (g_current < g_max_neg && pitch_cmd < 0.0) {
            g_fbw_state.g_limiting_active = true;
            double g_excess = g_max_neg - g_current;
            double limiting_cmd = g_excess * 0.1;
            limiting_cmd = limit(limiting_cmd, 0.0, 1.0);
            g_fbw_state.g_limiting_cmd = limiting_cmd;
            return limit(pitch_cmd + limiting_cmd, -1.0, 1.0);
        }
        
        g_fbw_state.g_limiting_cmd = 0.0;
        return pitch_cmd;
    }
    
    double process_pitch_command(double pitch_input, double dt) {
        if (!g_fbw_state.enabled || g_fbw_state.mode == FBWMode::FAILED) {
            return pitch_input;
        }
        
        // Command filtering
        double pitch_cmd = filter_command(pitch_input, g_fbw_state.pitch_cmd_filtered, 
                                         g_fbw_config.pitch_filter_tau, dt);
        
        // Apply protections
        pitch_cmd = apply_alpha_protection(pitch_cmd, dt);
        pitch_cmd = apply_stall_protection(pitch_cmd, dt);
        pitch_cmd = apply_g_limiting(pitch_cmd, dt);
        
        // Rate limiting
        double pitch_rate_deg_s = T50::pitch_rate * T50::rad_to_deg;
        double max_pitch_rate = g_fbw_config.max_pitch_rate;
        pitch_cmd = apply_rate_limiting(pitch_cmd, pitch_rate_deg_s, max_pitch_rate, dt);
        
        return limit(pitch_cmd, -1.0, 1.0);
    }
    
    double process_roll_command(double roll_input, double dt) {
        if (!g_fbw_state.enabled || g_fbw_state.mode == FBWMode::FAILED) {
            return roll_input;
        }
        
        // Command filtering
        double roll_cmd = filter_command(roll_input, g_fbw_state.roll_cmd_filtered,
                                        g_fbw_config.roll_filter_tau, dt);
        
        // Rate limiting
        double roll_rate_deg_s = T50::roll_rate * T50::rad_to_deg;
        double max_roll_rate = g_fbw_config.max_roll_rate;
        roll_cmd = apply_rate_limiting(roll_cmd, roll_rate_deg_s, max_roll_rate, dt);
        
        return limit(roll_cmd, -1.0, 1.0);
    }
    
    double process_yaw_command(double yaw_input, double dt) {
        if (!g_fbw_state.enabled || g_fbw_state.mode == FBWMode::FAILED) {
            return yaw_input;
        }
        
        // Command filtering
        double yaw_cmd = filter_command(yaw_input, g_fbw_state.yaw_cmd_filtered,
                                       g_fbw_config.yaw_filter_tau, dt);
        
        // Spin prevention (needs roll command too)
        double roll_cmd = g_fbw_state.roll_cmd_filtered;
        yaw_cmd = apply_spin_prevention(yaw_cmd, roll_cmd, dt);
        
        // Rate limiting
        double yaw_rate_deg_s = T50::yaw_rate * T50::rad_to_deg;
        double max_yaw_rate = g_fbw_config.max_yaw_rate;
        yaw_cmd = apply_rate_limiting(yaw_cmd, yaw_rate_deg_s, max_yaw_rate, dt);
        
        return limit(yaw_cmd, -1.0, 1.0);
    }
    
    void set_mode(FBWMode mode) {
        g_fbw_state.mode = mode;
        if (mode == FBWMode::FAILED) {
            g_fbw_state.enabled = false;
        }
    }
    
    FBWMode get_mode() {
        return g_fbw_state.mode;
    }
    
    bool is_enabled() {
        return g_fbw_state.enabled && g_fbw_state.mode != FBWMode::FAILED;
    }
    
    bool is_alpha_limiting_active() {
        return g_fbw_state.alpha_limiting_active;
    }
    
    bool is_stall_protection_active() {
        return g_fbw_state.stall_protection_active;
    }
    
    bool is_spin_prevention_active() {
        return g_fbw_state.spin_prevention_active;
    }
    
    bool is_g_limiting_active() {
        return g_fbw_state.g_limiting_active;
    }
}


