/*    DCS SDK Cockpit API Stub Header
    This is a minimal stub for compilation testing
    For actual DLL building, you need the real DCS SDK headers
*/

#pragma once

#include <string>
#include <unordered_map>

// EDPARAM class stub
class EDPARAM {
public:
    void* getParamHandle(const std::string& name) {
        // Stub implementation
        static void* dummy = nullptr;
        return dummy;
    }
    
    void setParamNumber(void* handle, double value) {
        // Stub implementation
    }
    
    double getParamNumber(void* handle) {
        // Stub implementation
        return 0.0;
    }
};

