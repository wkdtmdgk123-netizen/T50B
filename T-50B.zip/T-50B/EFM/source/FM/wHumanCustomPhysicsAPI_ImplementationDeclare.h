/*    DCS SDK Stub Header
    This is a minimal stub for compilation testing
    For actual DLL building, you need the real DCS SDK headers
*/

#pragma once

#ifdef _WIN32
    #define __declspec(dllexport) __attribute__((dllexport))
#endif

// Simulation event types
enum {
    ED_FM_EVENT_INVALID = 0,
    ED_FM_EVENT_STRUCTURE_DAMAGE = 1,
    ED_FM_EVENT_FIRE = 2
};

// Parameter indices
enum {
    ED_FM_SUSPENSION_0_WHEEL_YAW = 0,
    ED_FM_SUSPENSION_0_RELATIVE_BRAKE_MOMENT = 1,
    ED_FM_SUSPENSION_1_RELATIVE_BRAKE_MOMENT = 2,
    ED_FM_SUSPENSION_2_RELATIVE_BRAKE_MOMENT = 3,
    ED_FM_ANTI_SKID_ENABLE = 4,
    ED_FM_FC3_STICK_PITCH = 5,
    ED_FM_FC3_STICK_ROLL = 6,
    ED_FM_FC3_RUDDER_PEDALS = 7,
    ED_FM_FC3_THROTTLE_LEFT = 8,
    ED_FM_FC3_THROTTLE_RIGHT = 9,
    ED_FM_FUEL_INTERNAL_FUEL = 10,
    ED_FM_FUEL_TOTAL_FUEL = 11,
    ED_FM_OXYGEN_SUPPLY = 12,
    ED_FM_FLOW_VELOCITY = 13,
    ED_FM_SUSPENSION_0_GEAR_POST_STATE = 14,
    ED_FM_SUSPENSION_1_GEAR_POST_STATE = 15,
    ED_FM_SUSPENSION_2_GEAR_POST_STATE = 16,
    ED_FM_ENGINE_0_RPM = 17,
    ED_FM_ENGINE_0_RELATED_RPM = 18,
    ED_FM_ENGINE_0_THRUST = 19,
    ED_FM_ENGINE_0_RELATED_THRUST = 20,
    ED_FM_ENGINE_1_CORE_RPM = 21,
    ED_FM_ENGINE_1_RPM = 22,
    ED_FM_ENGINE_1_COMBUSTION = 23,
    ED_FM_ENGINE_1_RELATED_THRUST = 24,
    ED_FM_ENGINE_1_CORE_RELATED_THRUST = 25,
    ED_FM_ENGINE_1_RELATED_RPM = 26,
    ED_FM_ENGINE_1_CORE_RELATED_RPM = 27,
    ED_FM_ENGINE_1_CORE_THRUST = 28,
    ED_FM_ENGINE_1_THRUST = 29,
    ED_FM_ENGINE_1_TEMPERATURE = 30,
    ED_FM_ENGINE_1_FUEL_FLOW = 31,
    ED_FM_ENGINE_2_CORE_RPM = 32,
    ED_FM_ENGINE_2_RPM = 33,
    ED_FM_ENGINE_2_COMBUSTION = 34,
    ED_FM_ENGINE_2_RELATED_THRUST = 35,
    ED_FM_ENGINE_2_CORE_RELATED_THRUST = 36,
    ED_FM_ENGINE_2_RELATED_RPM = 37,
    ED_FM_ENGINE_2_CORE_RELATED_RPM = 38,
    ED_FM_ENGINE_2_CORE_THRUST = 39,
    ED_FM_ENGINE_2_THRUST = 40,
    ED_FM_ENGINE_2_TEMPERATURE = 41,
    ED_FM_ENGINE_2_FUEL_FLOW = 42,
    ED_FM_STICK_FORCE_CENTRAL_PITCH = 43,
    ED_FM_STICK_FORCE_FACTOR_PITCH = 44,
    ED_FM_STICK_FORCE_CENTRAL_ROLL = 45,
    ED_FM_STICK_FORCE_FACTOR_ROLL = 46,
    ED_FM_CAN_ACCEPT_FUEL_FROM_TANKER = 47
};

// Simulation event structure
struct ed_fm_simulation_event {
    int event_type;
    double event_params[8];
    char event_message[256];
};

// LERX vortex structures
struct LERX_vortex_spline_point {
    float pos[3];
    float vel[3];
    float radius;
    float opacity;
};

struct LERX_vortex {
    float opacity;
    float explosion_start;
    LERX_vortex_spline_point* spline;
    unsigned spline_points_count;
    unsigned spline_point_size_in_bytes;
    unsigned version;
};

