﻿/*    T-50B Golden Eagle
    Based on F-22A Raptor EFM by Branden Hooper
    Converted to T-50B specifications

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see https://www.gnu.org/licenses.
*/

// T50.cpp : External flight model for T-50B Golden Eagle
#include <math.h>
#include <cmath>
#include <stdio.h>
#include <string>
#include <algorithm>
#include <iostream>
#include <stack>
#include <queue>
#include <vector>
#include <sstream>

#define EXPORT_ED_FM_PHYSICS_IMP extern "C" __declspec(dllexport)
#include <FM/wHumanCustomPhysicsAPI_ImplementationDeclare.h>
#include <Cockpit/CockpitAPI_Declare.h>

#include "Utility.h"
#include "Inputs.h"
#include "T50.h"
#include "DebugLog.h"
#include "FBW.h"

#define EXPORT __declspec(dllexport)

// Debug mode flag (set to true to enable debug logging)
static bool g_debug_enabled = false;

static CockpitManager cockpit_manager;

struct MassChange
{
    double delta_kg;
    Vec3 pos;
    Vec3 moi;
};

struct DamageEvent {
    int element_number;
    double integrity_factor;
};

std::stack<MassChange> g_mass_changes;
std::queue<DamageEvent> g_damage_events;

void add_local_force(const Vec3& Force, const Vec3& Force_pos) {
    T50::common_force.x += Force.x;
    T50::common_force.y += Force.y;
    T50::common_force.z += Force.z;
    Vec3 delta_pos(Force_pos.x - T50::center_of_mass.x, Force_pos.y - T50::center_of_mass.y, Force_pos.z - T50::center_of_mass.z);
    Vec3 delta_moment = cross(delta_pos, Force);
    T50::common_moment.x += delta_moment.x;
    T50::common_moment.y += delta_moment.y;
    T50::common_moment.z += delta_moment.z;
}

void add_local_moment(const Vec3& Moment) {
    T50::common_moment.x += Moment.x;
    T50::common_moment.y += Moment.y;
    T50::common_moment.z += Moment.z;
}

void ed_fm_add_local_force(double& x, double& y, double& z, double& pos_x, double& pos_y, double& pos_z) {
    x = T50::common_force.x;
    y = T50::common_force.y;
    z = T50::common_force.z;
    pos_x = T50::center_of_mass.x;
    pos_y = T50::center_of_mass.y;
    pos_z = T50::center_of_mass.z;
}

void ed_fm_add_local_moment(double& x, double& y, double& z) {
    x = T50::common_moment.x;
    y = T50::common_moment.y;
    z = T50::common_moment.z;
}

void simulate_fuel_consumption(double dt)
{
    T50::fuel_rate = 0.0;
    double fuel_rate_kg_s = 0.0;

    double fuel_alt_factor = T50::atmosphere_density / 1.225;
    double mach_factor = 1.0 + 0.5 * T50::mach;

    if (T50::engine_state == T50::RUNNING) {
        if (T50::throttle_output <= 1.025) {
            double throttle_factor = (T50::throttle_output - 0.67) / (1.025 - 0.67);
            T50::fuel_rate = (0.126 + (1.5 - 0.126) * throttle_factor) * fuel_alt_factor * mach_factor;
        }
        else {
            double ab_factor = (T50::throttle_output - 1.025) / (1.1 - 1.025);
            T50::fuel_rate = (1.5 + (6.5 - 1.5) * ab_factor) * fuel_alt_factor * mach_factor;
        }
        fuel_rate_kg_s = T50::fuel_rate;
    }

    T50::fuel_consumption_since_last_time = T50::fuel_rate * dt;

    if (T50::fuel_consumption_since_last_time > 0) {
        double fuel_to_consume = T50::fuel_consumption_since_last_time;

        if (T50::external_fuel > 0) {
            double external_consumed = std::min(fuel_to_consume, T50::external_fuel);
            T50::external_fuel = std::max(0.0, T50::external_fuel - external_consumed);
            fuel_to_consume -= external_consumed;
        }

        if (fuel_to_consume > 0) {
            T50::internal_fuel = std::max(0.0, T50::internal_fuel - fuel_to_consume);
            double fuel_fraction = std::min(1.0, std::max(0.0, T50::internal_fuel / T50::max_internal_fuel));
            g_mass_changes.push({
                fuel_to_consume,
                {-0.32 * (1.0 - fuel_fraction), 0.0, 0.0},
                {0.0, 0.0, 0.0}
                });
        }

        T50::total_fuel = T50::internal_fuel + T50::external_fuel;
    }

    T50::fuel_rate_kg_s = fuel_rate_kg_s;
}

void reset_fm_state() {
    T50::pitch_input = T50::roll_input = T50::yaw_input = 0.0;
    T50::pitch_discrete = T50::roll_discrete = T50::yaw_discrete = 0.0;
    T50::pitch_analog = T50::roll_analog = T50::yaw_analog = true;
    T50::elevator_command = 0.0;
    T50::elevator_angle = 0.0;
    T50::last_elevator_cmd = T50::last_aileron_cmd = T50::last_rudder_cmd = 0.0;
    T50::pitch_trim = T50::roll_trim = T50::yaw_trim = 0.0;
    T50::beta_integral = 0.0;
    T50::aileron_animation_command = 0.0;

    T50::engine_state = T50::OFF;
    T50::engine_switch = false;
    T50::throttle_input = 0.0;
    T50::throttle_output = T50::idle_rpm;
    T50::engine_power_readout = 0.0;
    T50::thrust_force = 0.0;
    T50::ab_timer = 0.0;
    T50::engine_phase = 0.0;

    T50::ref_roll = T50::ref_heading = 0.0;
    T50::roll_error_i = T50::yaw_error_i = 0.0;

    T50::velocity_world = Vec3(0, 0, 0);
    T50::airspeed = Vec3(0, 0, 0);
    T50::pitch_rate = T50::roll_rate = T50::yaw_rate = 0.0;
    T50::aoa = T50::aos = T50::alpha = T50::beta = 0.0;
    T50::pitch = T50::roll = T50::heading = 0.0;
    T50::g = 0.0;
    T50::V_scalar = 0.0;
    T50::mach = 0.0;

    T50::left_wing_integrity = T50::right_wing_integrity = T50::tail_integrity = T50::elevator_integrity = 1.0;
    T50::engine_integrity = 1.0;
    T50::fuel_consumption_since_last_time = 0.0;

    T50::fm_clock = 0.0;
    T50::sim_initialised = false;
    T50::shake_amplitude = 0.0;
    T50::on_ground = false;

    T50::last_yaw_input = 0.0;
    T50::last_pitch_input = 0.0;
    T50::smoothed_pitch_discrete = 0.0;
    T50::smoothed_roll_discrete = 0.0;

    T50::autotrim_elevator_cmd = 0.0;
    T50::is_destroyed = false;
    T50::smoke_color_mode = 0;
    T50::smoke_active = false;
}

void ed_fm_simulate(double dt) {
    // Debug: Log simulation start (only first few frames)
    if (g_debug_enabled && T50::fm_clock < 1.0) {
        DEBUG_LOG("ed_fm_simulate called");
        DEBUG_LOG_VALUE("dt", dt);
        DEBUG_LOG_VALUE("mach", T50::mach);
        DEBUG_LOG_VALUE("throttle", T50::throttle_output);
    }
    
    T50::fm_clock += dt;
    T50::common_force = Vec3();
    T50::common_moment = Vec3();

    const double input_slew_rate = 1.33;
    T50::smoothed_pitch_discrete = slew_rate_limit(T50::smoothed_pitch_discrete, T50::pitch_discrete, input_slew_rate, dt);
    T50::smoothed_roll_discrete = slew_rate_limit(T50::smoothed_roll_discrete, T50::roll_discrete, input_slew_rate, dt);
    T50::smoothed_yaw_discrete = slew_rate_limit(T50::smoothed_yaw_discrete, T50::yaw_discrete, input_slew_rate, dt);

    const double ENGINE_INTEGRITY_SHUTDOWN_THRESHOLD = 0.30;
    if (T50::engine_integrity <= ENGINE_INTEGRITY_SHUTDOWN_THRESHOLD &&
        (T50::engine_state == T50::RUNNING || T50::engine_state == T50::STARTING)) {
        T50::engine_state = T50::SHUTDOWN;
        T50::engine_switch = false;
    }

    if (T50::is_destroyed) {
        static bool destruction_events_pushed = false;
        if (!destruction_events_pushed) {
            g_damage_events.push({ static_cast<int>(DamageElement::WingOutLeft), T50::element_integrity[static_cast<size_t>(DamageElement::WingOutLeft)] });
            g_damage_events.push({ static_cast<int>(DamageElement::WingOutRight), T50::element_integrity[static_cast<size_t>(DamageElement::WingOutRight)] });
            g_damage_events.push({ static_cast<int>(DamageElement::Tail), T50::element_integrity[static_cast<size_t>(DamageElement::Tail)] });
            g_damage_events.push({ static_cast<int>(DamageElement::Engine1), T50::element_integrity[static_cast<size_t>(DamageElement::Engine1)] });
            g_damage_events.push({ static_cast<int>(DamageElement::WingInLeft), T50::element_integrity[static_cast<size_t>(DamageElement::WingInLeft)] });
            g_damage_events.push({ static_cast<int>(DamageElement::WingInRight), T50::element_integrity[static_cast<size_t>(DamageElement::WingInRight)] });
            destruction_events_pushed = true;
        }
        T50::common_force = Vec3(0.0, 0.0, 0.0);
        T50::common_moment = Vec3(0.0, 0.0, 0.0);
        T50::engine_power_readout = 0.0;
        T50::engine_integrity = 0.0;
        T50::thrust_force = 0.0;
        T50::throttle_input = 0.0;
        T50::engine_state = T50::SHUTDOWN;
        T50::engine_switch = false;
        T50::pitch_input = T50::roll_input = T50::yaw_input = 0.0;
        T50::elevator_command = 0.0;
        T50::aileron_command = T50::rudder_command = 0.0;
        T50::ab_timer = 0.0;
        T50::V_scalar = 0.0;
        T50::pitch_rate = T50::roll_rate = T50::yaw_rate = 0.0;
    }

    cockpit_manager.update(dt);

    T50::gear_pos = limit(actuator(T50::gear_pos, T50::gear_switch, -0.0015, 0.0015), 0, 1);
    T50::airbrake_pos = limit(actuator(T50::airbrake_pos, T50::airbrake_switch, -0.004, 0.004), 0, 1);
    double slat_target = (T50::mach < 0.8) ? (T50::alpha - 10.0) / 10.0 : 0.0;
    T50::slats_pos = limit(actuator(T50::slats_pos, slat_target, -0.003, 0.003), 0, 1);

    T50::airspeed.x = T50::velocity_world.x - T50::wind.x;
    T50::airspeed.y = T50::velocity_world.y - T50::wind.y;
    T50::airspeed.z = T50::velocity_world.z - T50::wind.z;
    T50::V_scalar = sqrt(T50::airspeed.x * T50::airspeed.x + T50::airspeed.y * T50::airspeed.y + T50::airspeed.z * T50::airspeed.z);
    T50::mach = T50::V_scalar / T50::speed_of_sound;

    double aoa = T50::alpha;
    double x_offset;

    double x_offset_normal;
    if (aoa <= 3.5) {
        x_offset_normal = -0.8;
    }
    else if (aoa >= 20.0) {
        x_offset_normal = -0.5;
    }
    else {
        double t = (aoa - 3.5) / (20.0 - 3.5);
        x_offset_normal = -0.8 + t * (-0.5 - (-0.8));
    }

    x_offset = x_offset_normal;

    T50::left_wing_pos = Vec3(T50::center_of_mass.x + x_offset, T50::center_of_mass.y + 0.5, -T50::wingspan / 2);
    T50::right_wing_pos = Vec3(T50::center_of_mass.x + x_offset, T50::center_of_mass.y + 0.5, T50::wingspan / 2);

    double ias_ms = T50::V_scalar * sqrt(T50::atmosphere_density / 1.225);
    double ias_knots = ias_ms * 1.94384;

    if (T50::on_ground) {
        if (T50::ground_speed_knots < 45.0) {
            T50::flaps_pos = limit(actuator(T50::flaps_pos, 0.0, -0.006, 0.005), 0, 1);
        }
        else {
            T50::flaps_pos = limit(actuator(T50::flaps_pos, 1.0, -0.006, 0.005), 0, 1);
        }
    }
    else {
        if (T50::gear_pos > 0.5 && ias_knots < 250.0) {
            T50::flaps_pos = limit(actuator(T50::flaps_pos, 1.0, -0.006, 0.005), 0, 1);
        }
        else {
            T50::flaps_pos = limit(actuator(T50::flaps_pos, 0.0, -0.006, 0.005), 0, 1);
        }
    }

    if (T50::g >= 6) {
        T50::g_assist_pos = limit(actuator(T50::g_assist_pos, 1.0, -0.008, 0.007), 0.0, 1.0);
    }
    else {
        T50::g_assist_pos = limit(actuator(T50::g_assist_pos, 0.0, -0.007, 0.006), 0.0, 1.0);
    }

    double drag_direction = (fabs(T50::alpha) < 100.0) ? 1.0 : -1.0;
    double CyAlpha_ = lerp(FM_DATA::mach_table.data(), FM_DATA::Cya, FM_DATA::mach_table.size(), T50::mach);
    double CyMax_ = lerp(FM_DATA::mach_table.data(), FM_DATA::CyMax, FM_DATA::mach_table.size(), T50::mach);

    if (fabs(T50::alpha) >= 15.0) {
        double vortex_boost = 0.72 * exp(-pow((fabs(T50::alpha) - 35.0), 2) / (2 * 600.0));
        if (fabs(T50::alpha) > 65.0) vortex_boost = 0;
        CyMax_ += vortex_boost;
    }

    CyMax_ += (FM_DATA::cy_flap * T50::slats_pos);
    double Cy = CyAlpha_ * T50::alpha;
    if (Cy > CyMax_) Cy = CyMax_;
    if (Cy < -CyMax_) Cy = -CyMax_;

    if (fabs(T50::alpha) >= 90.0) {
        double aoa_excess = fabs(T50::alpha) - 90.0;
        double lift_reduction = 1.0 - (aoa_excess / 60.0) * 0.9;
        lift_reduction = limit(lift_reduction, 0.1, 1.0);
        Cy *= lift_reduction;
    }

    double CyBeta_ = lerp(FM_DATA::beta_table, FM_DATA::Cy_beta, sizeof(FM_DATA::beta_table) / sizeof(double), fabs(T50::beta));
    if (T50::alpha > 30.0) CyBeta_ *= 1.5;
    double Cy_tail = (0.5 * CyAlpha_ + FM_DATA::Czbe) * T50::beta + (T50::beta < 0 ? -CyBeta_ : CyBeta_);

    double Cx0_ = lerp(FM_DATA::mach_table.data(), FM_DATA::cx0, FM_DATA::mach_table.size(), T50::mach);
    double wave_drag_factor = 1.0 + 0.85 * std::max(0.0, (T50::mach - 0.9) / 0.3) * (1.0 - std::min(1.0, (T50::mach - 1.2) / 1.0)) * std::max(0.0, 1.0 - T50::altitude_ASL / 9144.0);
    double Drag = Cx0_ * wave_drag_factor + (FM_DATA::cx_brk * 1.2 * T50::airbrake_pos) + (FM_DATA::cx_flap * T50::flaps_pos) + (FM_DATA::cx_gear * T50::gear_pos);

    double AoA_drag = lerp(FM_DATA::AoA_table, FM_DATA::AoA_drag_factor, sizeof(FM_DATA::AoA_table) / sizeof(double), fabs(T50::alpha));
    Drag += AoA_drag;

    double gear_drag_penalty = 0.0;
    if (T50::gear_pos > 0.0) {
        double ias_ms = ias_knots * 0.514444;
        double base_gear_drag_coeff = 0.005;
        double speed_factor = (ias_ms / 100.0) * (ias_ms / 100.0);
        gear_drag_penalty = base_gear_drag_coeff * speed_factor * T50::gear_pos;
        Drag += gear_drag_penalty;
    }

    double q = 0.5 * T50::atmosphere_density * T50::V_scalar * T50::V_scalar;
    double Lift = Cy + FM_DATA::Cy0 + (FM_DATA::cy_flap * T50::flaps_pos);
    double aos_effect = (fabs(T50::aos) < 0.05) ? 0 : sin(T50::aos / 2);

    if (T50::on_ground && T50::ground_speed_knots > 30.0 && T50::wheel_brake > 0.7) {
        T50::landing_brake_assist = limit(actuator(T50::landing_brake_assist, 1.0, -0.008, 0.007), 0.0, 1.0);
        Drag += 0.60;
    }
    else {
        T50::landing_brake_assist = limit(actuator(T50::landing_brake_assist, 0.0, -0.008, 0.007), 0.0, 1.0);
    }

    Vec3 left_wing_forces(-Drag * drag_direction * (-aos_effect + 1) * q * (T50::S / 2) * T50::left_wing_integrity,
        Lift * (-aos_effect / 2 + 1) * q * (T50::S / 2) * T50::left_wing_integrity,
        Cy_tail * q * (T50::S / 2) * T50::left_wing_integrity);
    Vec3 right_wing_forces(-Drag * drag_direction * (aos_effect + 1) * q * (T50::S / 2) * T50::right_wing_integrity,
        Lift * (aos_effect / 2 + 1) * q * (T50::S / 2) * T50::right_wing_integrity,
        -Cy_tail * q * (T50::S / 2) * T50::right_wing_integrity);

    add_local_force(left_wing_forces, T50::left_wing_pos);
    add_local_force(right_wing_forces, T50::right_wing_pos);

    Vec3 tail_force(-Cy_tail * sin(T50::aoa) * (T50::S / 2) * q * T50::tail_integrity,
        0, -Cy_tail * cos(T50::aoa) * q * (T50::S / 2) * T50::tail_integrity);
    add_local_force(tail_force, T50::tail_pos);

    // FBW System Update
    FBW::update(dt);
    
    const double fbw_scale = 1.0;
    const double max_rate = 40.0;
    double beta_gain = (T50::mach > 0.9) ? std::clamp(0.1 * (T50::mach - 0.9) / 0.3, 0.0, 0.1) : 0.0;
    
    // Get raw input commands
    double pitch_input_raw = T50::pitch_analog ? T50::pitch_input : T50::smoothed_pitch_discrete;
    double roll_input_raw = T50::roll_analog ? T50::roll_input : T50::smoothed_roll_discrete;
    double yaw_input_raw = T50::yaw_analog ? T50::yaw_input : T50::smoothed_yaw_discrete;
    
    // Process through FBW system
    double pitch_cmd_source = FBW::process_pitch_command(pitch_input_raw, dt);
    double roll_cmd_source = FBW::process_roll_command(roll_input_raw, dt);
    double yaw_cmd_source = FBW::process_yaw_command(yaw_input_raw, dt);

    double aileron_scale = 1.0;
    if (T50::mach > 0.75) {
        if (T50::mach < 1.25) {
            aileron_scale = 1.0 - ((T50::mach - 0.75) / (1.25 - 0.75)) * (1.0 - 0.3);
        }
        else {
            aileron_scale = 0.3;
        }
    }
    T50::aileron_animation_command = limit(roll_cmd_source * fabs(roll_cmd_source) * aileron_scale, -1.0, 1.0);

    if (T50::fm_clock < 0.1) {
        T50::elevator_command = T50::elevator_command = 0.0;
        T50::aileron_command = T50::rudder_command = 0.0;
    }
    else {
        double Kd_pitch = lerp(FM_DATA::mach_table.data(), FM_DATA::Kd_pitch, FM_DATA::mach_table.size(), T50::mach);
        double Kd_roll = lerp(FM_DATA::mach_table.data(), FM_DATA::Kd_roll, FM_DATA::mach_table.size(), T50::mach);
        double Kd_yaw = lerp(FM_DATA::mach_table.data(), FM_DATA::Kd_yaw, FM_DATA::mach_table.size(), T50::mach);

        double pitch_sensitivity = 1.0;
        double max_deflection_rate = 2.27;

        if (T50::mach >= 0.67) {
            double mach_diff = T50::mach - 0.67;
            pitch_sensitivity = 1.0 - 0.229 * mach_diff * mach_diff;
            pitch_sensitivity = limit(pitch_sensitivity, 0.3, 1.0);
        }

        double elevator_rate = lerp(FM_DATA::mach_table.data(), FM_DATA::elevator_rate_table, FM_DATA::mach_table.size(), T50::mach);

        double max_elevator_deflection = lerp(FM_DATA::mach_table.data(), FM_DATA::max_elevator_deflection, FM_DATA::mach_table.size(), T50::mach);

        const double takeoff_trim_value = 0.25;
        const double takeoff_trim_rate = 0.05;

        double ias_ms = T50::V_scalar * sqrt(T50::atmosphere_density / 1.225);
        double ias_knots = ias_ms * 1.94384;

        double pitch_cmd_source = T50::pitch_analog ? T50::pitch_input : T50::smoothed_pitch_discrete;
        bool takeoff_trim_enabled = T50::on_ground &&
            ias_knots < 170.0 &&
            T50::pitch_trim == 0.0 &&
            fabs(pitch_cmd_source) < 0.05;

        double target_takeoff_trim = takeoff_trim_enabled ? takeoff_trim_value : 0.0;

        double trim_error = target_takeoff_trim - T50::takeoff_trim_cmd;
        T50::takeoff_trim_cmd += limit(trim_error, -takeoff_trim_rate * dt, takeoff_trim_rate * dt);

        const double autotrim_gain = 0.06;
        const double autotrim_max_cmd = 0.28;
        const double autotrim_rate_limit = 0.06;
        const double autotrim_fade_rate = 0.1;
        const double ref_q = 0.5 * 1.225 * 200.0 * 200.0;
        const double input_deadzone = 0.025;

        bool autotrim_disabled = T50::on_ground ||
            fabs(T50::roll) > 1.2217 ||
            T50::manual_trim_applied ||
            T50::alpha >= 9.0 ||
            ias_knots < 160.0;

        if (!autotrim_disabled) {
            T50::autotrim_active = true;
            double pitch_rate_deg_s = T50::pitch_rate * T50::rad_to_deg;
            double q = 0.5 * T50::atmosphere_density * T50::V_scalar * T50::V_scalar;
            double q_scale = (q > 100.0) ? ref_q / q : 1.0;
            double pitch_cmd_source = T50::pitch_analog ? T50::pitch_input : T50::smoothed_pitch_discrete;

            double pitch_rate_error = 0.0;
            if (pitch_cmd_source < -input_deadzone) {
                if (pitch_rate_deg_s >= 0.0) {
                    pitch_rate_error = 0.0 - pitch_rate_deg_s;
                }
            }
            else if (pitch_cmd_source > input_deadzone) {
                if (pitch_rate_deg_s <= 0.0) {
                    pitch_rate_error = 0.0 - pitch_rate_deg_s;
                }
            }
            else {
                pitch_rate_error = 0.0 - pitch_rate_deg_s;
            }

            double delta_cmd = pitch_rate_error * autotrim_gain * q_scale;
            delta_cmd = limit(delta_cmd, -autotrim_rate_limit * dt, autotrim_rate_limit * dt);
            T50::autotrim_elevator_cmd = limit(T50::autotrim_elevator_cmd + delta_cmd, -autotrim_max_cmd, autotrim_max_cmd);
        }
        else {
            T50::autotrim_active = false;
            if (T50::autotrim_elevator_cmd > 0) {
                T50::autotrim_elevator_cmd = std::max(T50::autotrim_elevator_cmd - autotrim_fade_rate * dt, 0.0);
            }
            else if (T50::autotrim_elevator_cmd < 0) {
                T50::autotrim_elevator_cmd = std::min(T50::autotrim_elevator_cmd + autotrim_fade_rate * dt, 0.0);
            }
        }

        if (fabs(roll_cmd_source) < 0.05) {
            Kd_roll = 0.75;
        }

        // FBW processed pitch command (already includes protections)
        double elevator_cmd = (pitch_cmd_source * fabs(pitch_cmd_source) * 1.1) * pitch_sensitivity;
        elevator_cmd += -T50::pitch_rate * Kd_pitch;
        elevator_cmd += T50::pitch_trim;
        elevator_cmd += T50::autotrim_elevator_cmd;
        elevator_cmd += T50::takeoff_trim_cmd;
        elevator_cmd = limit(elevator_cmd, -1.0, 1.0);
        
        // Note: G limiting is now handled by FBW system, but keep legacy code as backup
        const double g_reduction_factor = 0.1;
        if (T50::g > T50::g_limit_positive && elevator_cmd > 0.0) {
            double g_excess = T50::g - T50::g_limit_positive;
            elevator_cmd -= g_excess * g_reduction_factor;
            elevator_cmd = std::max(elevator_cmd, 0.0);
        }
        else if (T50::g < T50::g_limit_negative && elevator_cmd < 0.0) {
            double g_excess = T50::g_limit_negative - T50::g;
            elevator_cmd += g_excess * g_reduction_factor;
            elevator_cmd = std::min(elevator_cmd, 0.0);
        }

        elevator_cmd = limit(T50::last_elevator_cmd + limit(elevator_cmd - T50::last_elevator_cmd, -max_rate * dt, max_rate * dt), -1.0, 1.0);
        T50::last_elevator_cmd = elevator_cmd;

        double roll_cmd = roll_cmd_source * fabs(roll_cmd_source);
        double roll_damping = -T50::roll_rate * Kd_roll;
        roll_cmd += roll_damping;
        T50::aileron_command = limit(T50::last_aileron_cmd + limit(roll_cmd - T50::last_aileron_cmd, -FM_DATA::max_aileron_rate * dt, FM_DATA::max_aileron_rate * dt), -1.0, 1.0);
        T50::last_aileron_cmd = T50::aileron_command;

        T50::elevator_command = limit(elevator_cmd - T50::aileron_command, -1.0, 1.0);
        T50::elevator_command = limit(elevator_cmd + T50::aileron_command, -1.0, 1.0);
        T50::last_elevator_cmd = elevator_cmd;

        double target_elevator_angle = -T50::elevator_command * T50::rad(max_elevator_deflection);
        double elevon_step = elevator_rate * dt;

        if (T50::elevator_angle < target_elevator_angle) {
            T50::elevator_angle = std::min<double>(T50::elevator_angle + elevon_step, target_elevator_angle);
        }
        else if (T50::elevator_angle > target_elevator_angle) {
            T50::elevator_angle = std::max<double>(T50::elevator_angle - elevon_step, target_elevator_angle);
        }

        // Yaw command processing (FBW already processed yaw_cmd_source)
        double yaw_cmd;
        const double beta_integral_gain = 0.06;
        const double beta_integral_limit = 0.01;
        const double beta_integral_decay = 0.07;

        double adverse_yaw_cmd = 0.0;
        if (fabs(yaw_cmd_source) < 0.01) {
            double adverse_yaw_gain = 0.3 * (1.0 - std::min(T50::mach, 1.0));
            adverse_yaw_cmd = T50::aileron_command * adverse_yaw_gain * (q / (q + 10000.0));
            adverse_yaw_cmd = limit(adverse_yaw_cmd, -0.3, 0.3);
        }
        
        if (fabs(yaw_cmd_source) < 0.01) {
            yaw_cmd = -T50::yaw_rate * Kd_yaw - std::clamp(T50::beta, -3.0, 3.0) * std::clamp(T50::last_yaw_input, 0.0, 0.3);
            yaw_cmd -= beta_gain * T50::beta;
            yaw_cmd += adverse_yaw_cmd;

            if (fabs(T50::beta) < 3.0 && !T50::on_ground && fabs(T50::rudder_command) < 0.9) {
                T50::beta_integral += T50::beta * beta_integral_gain * dt;
                T50::beta_integral = limit(T50::beta_integral, -beta_integral_limit, beta_integral_limit);
            }
            else {
                T50::beta_integral *= std::exp(-beta_integral_decay * dt);
            }
            yaw_cmd -= T50::beta_integral;

            if (T50::alpha > 10.0) {
                double pitch_yaw_coupling = -T50::pitch_rate * 0.11 * (T50::alpha / lerp(FM_DATA::mach_table.data(), FM_DATA::Aldop, FM_DATA::mach_table.size(), T50::mach));
                yaw_cmd += limit(pitch_yaw_coupling, -0.5, 0.5);
            }
            T50::last_yaw_input -= dt / 0.5;
            if (T50::last_yaw_input < 0.0) T50::last_yaw_input = 0.0;
        }
        else {
            // Use FBW processed command
            yaw_cmd = 0.5 * yaw_cmd_source * sqrt(fabs(yaw_cmd_source)) - T50::yaw_rate * Kd_yaw;
            yaw_cmd -= beta_gain * T50::beta * 0.5;
            yaw_cmd += adverse_yaw_cmd * 0.5;
            T50::beta_integral *= std::exp(-beta_integral_decay * dt);
            T50::last_yaw_input = 0.5 * fabs(yaw_cmd_source);
        }

        T50::rudder_command = limit(T50::last_rudder_cmd + limit(yaw_cmd - T50::last_rudder_cmd, -max_rate * dt, max_rate * dt), -1.0, 1.0);
        T50::last_rudder_cmd = T50::rudder_command;

        double elevator_force_magnitude = q * T50::S * 0.20;
        
        double aoa_abs = fabs(T50::alpha);
        double elevator_aoa_scale = 1.0;
        if (aoa_abs > 30.0) {
            elevator_aoa_scale = 1.0 - (0.9 * (aoa_abs - 30.0) / (60.0 - 30.0));
            elevator_aoa_scale = limit(elevator_aoa_scale, 0.1, 1.0);
        }

        add_local_force(Vec3(0, T50::elevator_angle * elevator_force_magnitude * elevator_aoa_scale * T50::elevator_integrity, 0), T50::elevator_pos);

        double aileron_deflection = T50::aileron_command * T50::rad(30);
        add_local_force(Vec3(0, aileron_deflection * q * T50::S * 0.25, 0), T50::left_aileron_pos);
        add_local_force(Vec3(0, -aileron_deflection * q * T50::S * 0.25, 0), T50::right_aileron_pos);
        double rudder_deflection = T50::rudder_command * T50::rad(25 + (T50::mach < 0.5 ? 5.0 : 0.0));
        if (T50::is_destroyed == true) { rudder_deflection = 0.0; }
        add_local_force(Vec3(0, 0, rudder_deflection * q * T50::S * 0.3), T50::rudder_pos);

        // Single engine thrust (no thrust vectoring)
        add_local_force(Vec3(T50::thrust_force, 0, 0), T50::engine_pos);
    }

    double idle_thrust = lerp(FM_DATA::mach_table.data(), FM_DATA::idle_thrust.data(), FM_DATA::mach_table.size(), T50::mach);
    double max_dry_thrust_base = lerp(FM_DATA::mach_table.data(), FM_DATA::max_thrust.data(), FM_DATA::mach_table.size(), T50::mach);
    double max_ab_thrust_base = lerp(FM_DATA::mach_table.data(), FM_DATA::ab_thrust.data(), FM_DATA::mach_table.size(), T50::mach);

    const double static_max_dry_thrust = 112654.0;
    const double static_max_ab_thrust = 155688.0;

    double max_dry_thrust = T50::on_ground ? static_max_dry_thrust : max_dry_thrust_base;
    double max_ab_thrust = T50::on_ground ? static_max_ab_thrust : max_ab_thrust_base;

    double dry_range = max_dry_thrust - idle_thrust;
    double ab_range = max_ab_thrust - max_dry_thrust;

    const double ab_spool_time_air = 1.1;
    const double spool_up_rate_air = 0.1285;
    const double spool_down_rate_air = 0.122;
    const double ab_spool_time_ground = 1.65;
    const double spool_up_rate_ground = 0.079;
    const double spool_down_rate_ground = 0.0813;
    const double shutoff_spool_down = 0.041;

    double ab_spool_time = T50::on_ground ? ab_spool_time_ground : ab_spool_time_air;
    double spool_up_rate = T50::on_ground ? spool_up_rate_ground : spool_up_rate_air;
    double spool_down_rate = T50::on_ground ? spool_down_rate_ground : spool_down_rate_air;

    T50::throttle_input = limit(T50::throttle_input, 0, 1);

    double thrust_alt_factor = T50::atmosphere_density / 1.225;
    const double idle_rps = 50.0;
    const double max_rps = 150.0;

    if (T50::engine_state == T50::OFF) {
        T50::throttle_output = 0.0;
        T50::engine_power_readout = 0.0;
        T50::thrust_force = 0.0;
        T50::ab_timer = 0.0;
        T50::engine_start_timer = 0.0;
    }
    
    // Debug: Log engine state changes
    static T50::EngineState last_engine_state = T50::OFF;
    if (g_debug_enabled && last_engine_state != T50::engine_state) {
        std::ostringstream oss;
        oss << "Engine state changed: " << last_engine_state << " -> " << T50::engine_state;
        DEBUG_LOG(oss.str());
        last_engine_state = T50::engine_state;
    }
    else if (T50::engine_state == T50::STARTING) {
        T50::engine_start_timer += dt;
        if (T50::engine_start_timer <= T50::starter_phase_duration) {
            T50::throttle_output = T50::starter_rate * T50::engine_start_timer;
        }
        else if (T50::engine_start_timer <= T50::starter_phase_duration + T50::ignition_phase_duration) {
            double phase_time = T50::engine_start_timer - T50::starter_phase_duration;
            T50::throttle_output = T50::starter_rpm + T50::ignition_rate * phase_time;
        }
        else if (T50::engine_start_timer <= T50::engine_start_time) {
            double phase_time = T50::engine_start_timer - (T50::starter_phase_duration + T50::ignition_phase_duration);
            T50::throttle_output = T50::ignition_rpm + T50::spool_up_rate * phase_time;
        }
        else {
            T50::throttle_output = T50::idle_rpm;
            T50::engine_state = T50::RUNNING;
        }
        T50::throttle_output = limit(T50::throttle_output, 0.0, T50::idle_rpm);
        T50::engine_power_readout = T50::throttle_output;
        if (T50::engine_start_timer > T50::starter_phase_duration) {
            double norm_throttle = T50::throttle_output / T50::idle_rpm;
            T50::thrust_force = idle_thrust * norm_throttle * thrust_alt_factor * T50::engine_integrity;
        }
        else {
            T50::thrust_force = 0.0;
        }
        T50::ab_timer = 0.0;
    }
    else if (T50::engine_state == T50::RUNNING) {
        // Single engine throttle control (T-50B)
        double target_throttle = 0.67 + (T50::throttle_input * 0.43);
        double delta = target_throttle - T50::throttle_output;
        double rate = (delta > 0) ? spool_up_rate : -spool_down_rate;
        T50::throttle_output += limit(delta, -spool_down_rate * dt, spool_up_rate * dt);
        T50::throttle_output = limit(T50::throttle_output, 0.67, 1.1);
        T50::engine_power_readout = T50::throttle_output;
        if (T50::throttle_output >= 1.035 && target_throttle > 1.035) {
            T50::ab_timer += dt / ab_spool_time;
        }
        else {
            T50::ab_timer -= dt / ab_spool_time;
        }
        T50::ab_timer = limit(T50::ab_timer, 0, 1);

        if (T50::throttle_output <= 1.025) {
            double norm_throttle = (T50::throttle_output - 0.67) / 0.355;
            double thrust_factor = norm_throttle * norm_throttle;
            T50::thrust_force = (idle_thrust + dry_range * thrust_factor) * thrust_alt_factor * T50::engine_integrity;
        }
        else {
            double norm_throttle = (T50::throttle_output - 1.025) / 0.075;
            double thrust_factor;
            if (norm_throttle <= 0.0667) {
                thrust_factor = 0.0;
            }
            else {
                double adjusted_throttle = (norm_throttle - 0.0667) / (1.0 - 0.0667);
                thrust_factor = adjusted_throttle * adjusted_throttle;
            }
            T50::thrust_force = (max_dry_thrust + ab_range * thrust_factor * T50::ab_timer) * thrust_alt_factor * T50::engine_integrity;
        }
    }
    else if (T50::engine_state == T50::SHUTDOWN) {
        T50::throttle_output -= shutoff_spool_down * dt;
        if (T50::throttle_output <= 0.0) {
            T50::throttle_output = 0.0;
            T50::engine_state = T50::OFF;
            T50::engine_switch = false;
        }
        T50::engine_power_readout = T50::throttle_output;
        T50::ab_timer = limit(T50::ab_timer - dt / ab_spool_time, 0, 1);

        if (T50::throttle_output <= 1.025) {
            double norm_throttle = (T50::throttle_output > 0.67 ? (T50::throttle_output - 0.67) / 0.355 : 0.0);
            double thrust_factor = norm_throttle * norm_throttle;
            T50::thrust_force = (idle_thrust + dry_range * thrust_factor) * thrust_alt_factor * T50::engine_integrity;
        }
        else {
            double norm_throttle = (T50::throttle_output - 1.025) / 0.075;
            double thrust_factor;
            if (norm_throttle <= 0.0667) {
                thrust_factor = 0.0;
            }
            else {
                double adjusted_throttle = (norm_throttle - 0.0667) / (1.0 - 0.0667);
                thrust_factor = adjusted_throttle * adjusted_throttle;
            }
            T50::thrust_force = (max_dry_thrust + ab_range * thrust_factor * T50::ab_timer) * thrust_alt_factor * T50::engine_integrity;
        }
        if (T50::throttle_output <= 0.0) {
            T50::thrust_force = 0.0;
        }
    }
    // Single engine RPS calculation (T-50B has only one engine)
    double engine_rps = 0.0;
    if (T50::engine_state == T50::RUNNING || T50::engine_state == T50::STARTING) {
        double norm_throttle = (T50::engine_power_readout - 0.67) / (1.1 - 0.67);
        norm_throttle = limit(norm_throttle, 0.0, 1.0);
        engine_rps = idle_rps + (max_rps - idle_rps) * norm_throttle;
    }
    else if (T50::engine_state == T50::SHUTDOWN) {
        double norm_throttle = (T50::engine_power_readout > 0.67 ? (T50::engine_power_readout - 0.67) / (1.1 - 0.67) : 0.0);
        norm_throttle = limit(norm_throttle, 0.0, 1.0);
        engine_rps = idle_rps + (max_rps - idle_rps) * norm_throttle;
    }
    T50::engine_phase += engine_rps * dt;
    T50::engine_phase -= floor(T50::engine_phase);

    // Check for fuel exhaustion (single check)
    if (T50::internal_fuel <= 25 && (T50::engine_state == T50::RUNNING || T50::engine_state == T50::STARTING)) {
        T50::engine_state = T50::SHUTDOWN;
        T50::engine_switch = false;
    }

    // Check for engine damage (single check)
    if (T50::engine_integrity <= 0.25 && (T50::engine_state == T50::RUNNING || T50::engine_state == T50::STARTING)) {
        T50::engine_state = T50::SHUTDOWN;
        T50::engine_switch = false;
    }

    // Apply engine integrity to power readout (single multiplication)
    T50::engine_power_readout *= T50::engine_integrity;

    if (!T50::infinite_fuel) simulate_fuel_consumption(dt);

    double roll_yaw_moment = -(T50::roll_rate / 2) * (q + 1e5 * 0.5);
    add_local_moment(Vec3(0, roll_yaw_moment, 0));
    double OmxMax_ = lerp(FM_DATA::mach_table.data(), FM_DATA::OmxMax, FM_DATA::mach_table.size(), T50::mach);
    double roll_rate_ratio = std::fabs(T50::roll_rate) / (OmxMax_ + 0.1);
    double clamped_ratio = std::clamp(roll_rate_ratio, 0.0001, 2.0);
    double amplified_ratio = std::pow(clamped_ratio, 6);
    double dynamic_pressure_term = 2.0 * q + 50000.0;
    double scaling_factor = amplified_ratio * dynamic_pressure_term;
    double clamped_scaling = std::clamp(scaling_factor, -1e7, 1e7);
    double roll_rate_limiter = -T50::roll_rate * clamped_scaling;

    add_local_moment(Vec3(roll_rate_limiter, 0, 0));
    double yaw_rate_limiter = -(T50::yaw_rate + T50::aos) * (q + 1e5 * 0.5);
    add_local_moment(Vec3(0, yaw_rate_limiter, 0));

    T50::on_ground = (T50::gear_pos > 0.5 && T50::altitude_AGL < 50.0 && T50::mach < 0.3);

    double ground_vel_x = T50::velocity_world.x - T50::wind.x;
    double ground_vel_z = T50::velocity_world.z - T50::wind.z;
    T50::ground_speed_knots = sqrt(ground_vel_x * ground_vel_x + ground_vel_z * ground_vel_z) * 1.94384;

    T50::shake_amplitude = 0;
    T50::shake_amplitude += limit((FM_DATA::cx_brk + 1) * T50::airbrake_pos * T50::mach, 0, 2) / 6;
    if (!T50::on_ground) {
        if (fabs(T50::alpha) > 90) T50::shake_amplitude += (fabs(T50::alpha) - 90) / 100;
        if (fabs(T50::beta) > 10) T50::shake_amplitude += (fabs(T50::beta) - 10) / 100;
        if (fabs(T50::g) > 9.5) T50::shake_amplitude += (fabs(T50::g) - 9.5) / 100;
        if (T50::mach > 2.31) T50::shake_amplitude += (T50::mach - 2.31) / 2;
    }

    T50::sim_initialised = true;
}

void ed_fm_set_atmosphere(double h, double t, double a, double ro, double p, double wind_vx, double wind_vy, double wind_vz) {
    T50::wind = Vec3(wind_vx, wind_vy, wind_vz);
    T50::atmosphere_density = ro;
    T50::speed_of_sound = a;
    T50::altitude_ASL = h;
    T50::engine_alt_effect = T50::atmosphere_density / 1.225;
    T50::atmosphere_temperature = t;
}

void ed_fm_set_surface(double h, double h_obj, unsigned surface_type, double normal_x, double normal_y, double normal_z) {
    T50::altitude_AGL = T50::altitude_ASL - (h + h_obj * 0.5);
}

void ed_fm_set_current_mass_state(double mass, double center_of_mass_x, double center_of_mass_y, double center_of_mass_z, double moment_of_inertia_x, double moment_of_inertia_y, double moment_of_inertia_z)
{
    T50::center_of_mass.x = center_of_mass_x;
    T50::center_of_mass.y = center_of_mass_y;
    T50::center_of_mass.z = center_of_mass_z;

}

void ed_fm_set_current_state(double ax, double ay, double az, double vx, double vy, double vz, double px, double py, double pz,
    double omegadotx, double omegadoty, double omegadotz, double omegax, double omegay, double omegaz,
    double quaternion_x, double quaternion_y, double quaternion_z, double quaternion_w) {
    T50::velocity_world = Vec3(vx, vy, vz);
}

void ed_fm_set_current_state_body_axis(double ax, double ay, double az, double vx, double vy, double vz, double wind_vx, double wind_vy, double wind_vz,
    double omegadotx, double omegadoty, double omegadotz, double omegax, double omegay, double omegaz,
    double yaw, double pitch, double roll, double common_angle_of_attack, double common_angle_of_slide) {
    T50::aoa = common_angle_of_attack;
    T50::alpha = T50::aoa * T50::rad_to_deg;
    T50::aos = common_angle_of_slide;
    T50::beta = T50::aos * T50::rad_to_deg;
    T50::g = (ay / 9.81) + 1;
    T50::pitch = pitch;
    T50::roll = roll;
    T50::heading = yaw;
    T50::roll_rate = omegax;
    T50::yaw_rate = omegay;
    T50::pitch_rate = omegaz;
}

void ed_fm_set_command(int command, float value) {
    double ias_ms = T50::V_scalar * sqrt(T50::atmosphere_density / 1.225);
    double ias_knots_local = ias_ms * 1.94384;
    switch (command) {
    case JoystickPitch:
        T50::pitch_input = limit(value, -1, 1);
        T50::pitch_analog = true;
        T50::pitch_discrete = 0;
        break;
    case PitchUp: T50::pitch_discrete = 1; T50::pitch_analog = false; break;
    case PitchUpStop: T50::pitch_discrete = 0; T50::pitch_analog = false; break;
    case PitchDown: T50::pitch_discrete = -1; T50::pitch_analog = false; break;
    case PitchDownStop: T50::pitch_discrete = 0; T50::pitch_analog = false; break;
    case trimUp:
        if (!T50::manual_trim_applied) {
            T50::pitch_trim += T50::autotrim_elevator_cmd;
            T50::autotrim_elevator_cmd = 0.0;
            T50::manual_trim_applied = true;
        }
        T50::pitch_trim = limit(T50::pitch_trim + 0.01, -1.0, 1.0);
        break;
    case trimDown:
        if (!T50::manual_trim_applied) {
            T50::pitch_trim += T50::autotrim_elevator_cmd;
            T50::autotrim_elevator_cmd = 0.0;
            T50::manual_trim_applied = true;
        }
        T50::pitch_trim = limit(T50::pitch_trim - 0.01, -1.0, 1.0);
        break;
    case resetTrim:
        T50::autotrim_elevator_cmd = limit(T50::pitch_trim, -0.2, 0.2);
        T50::pitch_trim = T50::roll_trim = T50::yaw_trim = 0;
        T50::manual_trim_applied = false;
        break;

    case JoystickRoll:
        T50::roll_input = limit(value, -1, 1);
        T50::roll_analog = true;
        T50::roll_discrete = 0;
        break;
    case RollLeft: T50::roll_discrete = -1; T50::roll_analog = false; break;
    case RollLeftStop: T50::roll_discrete = 0; T50::roll_analog = false; break;
    case RollRight: T50::roll_discrete = 1; T50::roll_analog = false; break;
    case RollRightStop: T50::roll_discrete = 0; T50::roll_analog = false; break;
    case trimLeft: T50::roll_trim -= 0.001; break;
    case trimRight: T50::roll_trim += 0.001; break;
    case PedalYaw: T50::yaw_input = limit(-value, -1, 1); T50::yaw_discrete = 0; T50::yaw_analog = true; break;
    case rudderleft: T50::yaw_discrete = 1; T50::yaw_analog = false; break;
    case rudderleftstop: T50::yaw_discrete = 0; T50::yaw_analog = false; break;
    case rudderright: T50::yaw_discrete = -1; T50::yaw_analog = false; break;
    case rudderrightstop: T50::yaw_discrete = 0; T50::yaw_analog = false; break;
    case ruddertrimLeft: T50::yaw_trim += 0.001; break;
    case ruddertrimRight: T50::yaw_trim -= 0.001; break;
    case EnginesOn:
    case LeftEngineOn:
    case RightEngineOn:
        if (T50::internal_fuel > 25) {
            if (T50::engine_state == T50::OFF || T50::engine_state == T50::SHUTDOWN) {
                T50::engine_switch = true;
                T50::engine_state = T50::STARTING;
                T50::throttle_output = std::max(T50::throttle_output, 0.0);
                double time = 0.0;
                if (T50::throttle_output <= T50::starter_rpm) {
                    time = T50::throttle_output / T50::starter_rate;
                }
                else if (T50::throttle_output <= T50::ignition_rpm) {
                    time = (T50::throttle_output - T50::starter_rpm) / T50::ignition_rate + T50::starter_phase_duration;
                }
                else {
                    time = (T50::throttle_output - T50::ignition_rpm) / T50::spool_up_rate + (T50::starter_phase_duration + T50::ignition_phase_duration);
                }
                T50::engine_start_timer = std::min(time, T50::engine_start_time);
            }
        }
        break;
    case EnginesOff:
    case LeftEngineOff:
    case RightEngineOff:
        if (T50::engine_state == T50::RUNNING || T50::engine_state == T50::STARTING) {
            T50::engine_state = T50::SHUTDOWN;
        }
        T50::engine_switch = false;
        break;

    case ThrottleAxis:
    case ThrottleAxisLeft:
    case ThrottleAxisRight:
        T50::throttle_input = limit(-value + 1, 0, 2) / 2;
        break;
    case ThrottleIncrease:
    case ThrottleLeftUp:
    case ThrottleRightUp:
        T50::throttle_input += 0.0075;
        break;
    case ThrottleDecrease:
    case ThrottleLeftDown:
    case ThrottleRightDown:
        T50::throttle_input -= 0.0075;
        break;
    case AirBrakes: T50::airbrake_switch = !T50::airbrake_switch; break;
    case AirBrakesOff: T50::airbrake_switch = false; break;
    case AirBrakesOn: T50::airbrake_switch = true; break;
    case flapsToggle: T50::flaps_switch = !T50::flaps_switch; break;
    case flapsDown: T50::flaps_switch = false; break;
    case flapsUp: T50::flaps_switch = true; break;
    case gearToggle:
        if (ias_knots_local >= 100.0) {
            if (T50::gear_switch) {
                T50::gear_switch = false;
            }
            else if (ias_knots_local <= 275.0) {

                T50::gear_switch = true;
            }
        }
        break;
    case gearDown:
        if (ias_knots_local <= 275.0) {
            T50::gear_switch = true;
        }
        break;
    case gearUp:
        if (ias_knots_local >= 100.0) {
            T50::gear_switch = false;
        }
        break;
    case WheelBrakeOn:  T50::wheel_brake = 1; break;
    case WheelBrakeOff: T50::wheel_brake = 0; break;

    }
}

bool ed_fm_change_mass(double& delta_mass, double& delta_mass_pos_x, double& delta_mass_pos_y, double& delta_mass_pos_z,
    double& delta_mass_moment_of_inertia_x, double& delta_mass_moment_of_inertia_y, double& delta_mass_moment_of_inertia_z)
{
    if (!g_mass_changes.empty()) {
        MassChange const& change = g_mass_changes.top();
        delta_mass = change.delta_kg;
        delta_mass_pos_x = change.pos.x;
        delta_mass_pos_y = change.pos.y;
        delta_mass_pos_z = change.pos.z;
        delta_mass_moment_of_inertia_x = change.moi.x;
        delta_mass_moment_of_inertia_y = change.moi.y;
        delta_mass_moment_of_inertia_z = change.moi.z;
        g_mass_changes.pop();
        return true;
    }
    return false;
}

void ed_fm_set_internal_fuel(double fuel) {
    T50::internal_fuel = fuel;
}

double ed_fm_get_internal_fuel() {
    return T50::internal_fuel;
}

void ed_fm_set_external_fuel(int station, double fuel, double x, double y, double z) {
    if (fuel > 0 && T50::external_fuel_stations.find(station) == T50::external_fuel_stations.end()) {
        T50::external_fuel_stations[station] = 1850.0;
        T50::external_tanks_equipped = true;
    }
    else if (fuel <= 0) {
        T50::external_fuel_stations.erase(station);
        T50::external_tanks_equipped = !T50::external_fuel_stations.empty();
    }
    else {
        T50::external_fuel_stations[station] = fuel;
        T50::external_tanks_equipped = true;
    }

    T50::external_fuel = 0.0;
    for (const auto& [s, fuel_qty] : T50::external_fuel_stations) {
        T50::external_fuel += fuel_qty;
    }

    T50::total_fuel = T50::internal_fuel + T50::external_fuel;
}

double ed_fm_get_external_fuel() {
    return T50::external_fuel;
}

void ed_fm_set_fc3_cockpit_draw_args_v2(float* data, size_t size) {
    cockpit_manager.updateDrawArgs(data, size);
}

void ed_fm_set_draw_args_v2(float* data, size_t size) {
    data[0] = (float)limit(T50::gear_pos, 0, 1);
    data[3] = (float)limit(T50::gear_pos, 0, 1);
    data[5] = (float)limit(T50::gear_pos, 0, 1);
    data[15] = (float)limit(T50::elevator_angle / -T50::rad(18.0), -1.0, 1.0);
    data[16] = (float)limit(T50::elevator_angle / -T50::rad(18.0), -1.0, 1.0);
    // No thrust vectoring for T-50B
        data[622] = 0.0f;
        data[623] = 0.0f;
    data[17] = (float)limit(T50::rudder_command, -1, 1);
    data[18] = (float)limit(T50::rudder_command, -1, 1);
    data[21] = (float)limit(T50::airbrake_pos, 0, 1);
    if (T50::landing_brake_assist >= 1.0f) {
        data[182] = 0.0f;
    }
    else {
        data[182] = (float)limit(T50::airbrake_pos, 0, 1);
    }
    data[184] = (float)limit(T50::airbrake_pos, 0, 1);

    static float current_left_flap = (float)T50::flaps_pos;
    static float current_right_flap = (float)T50::flaps_pos;
    static float current_left_aileron = (float)T50::aileron_command;
    static float current_right_aileron = (float)-T50::aileron_command;
    static float current_left_rudder = (float)T50::rudder_command;
    static float current_right_rudder = (float)T50::rudder_command;

    auto rate_limit = [](float current, float target, float rate_per_second, float dt) -> float {
        float delta = target - current;
        float max_change = rate_per_second * dt;
        return current + std::clamp(delta, -max_change, max_change);
        };

    const float flap_actuator_rate = 0.4f;
    const float control_surface_rate = 2.0f;
    const float rate = 0.0189f;

    if (T50::landing_brake_assist >= 1.0f && T50::on_ground) {
        current_left_flap = (float)limit(rate_limit(current_left_flap, -1.0f, flap_actuator_rate, rate), -1.0f, 1.0f);
        current_right_flap = (float)limit(rate_limit(current_right_flap, -1.0f, flap_actuator_rate, rate), -1.0f, 1.0f);
        data[9] = current_left_flap;
        data[10] = current_right_flap;
        current_left_aileron = (float)limit(rate_limit(current_left_aileron, 1.0f, control_surface_rate, rate), -1.0f, 1.0f);
        current_right_aileron = (float)limit(rate_limit(current_right_aileron, 1.0f, control_surface_rate, rate), -1.0f, 1.0f);
        data[11] = current_left_aileron;
        data[12] = current_right_aileron;
        current_left_rudder = (float)limit(rate_limit(current_left_rudder, 1.0f, control_surface_rate, rate), -1.0f, 1.0f);
        current_right_rudder = (float)limit(rate_limit(current_right_rudder, -1.0f, control_surface_rate, rate), -1.0f, 1.0f);
        data[17] = current_left_rudder;
        data[18] = current_right_rudder;
    }
    else {
        float target_left_aileron = (T50::g_assist_pos > 0.0f) ? T50::g_assist_pos : (float)limit(T50::aileron_animation_command, -1, 1);
        float target_right_aileron = (T50::g_assist_pos > 0.0f) ? T50::g_assist_pos : (float)limit(-T50::aileron_animation_command, -1, 1);
        current_left_aileron = (float)limit(rate_limit(current_left_aileron, target_left_aileron, control_surface_rate, rate), -1.0f, 1.0f);
        current_right_aileron = (float)limit(rate_limit(current_right_aileron, target_right_aileron, control_surface_rate, rate), -1.0f, 1.0f);
        data[11] = current_left_aileron;
        data[12] = current_right_aileron;

        current_left_rudder = (float)limit(rate_limit(current_left_rudder, (float)T50::rudder_command, control_surface_rate, rate), -1.0f, 1.0f);
        current_right_rudder = (float)limit(rate_limit(current_right_rudder, (float)T50::rudder_command, control_surface_rate, rate), -1.0f, 1.0f);
        data[17] = current_left_rudder;
        data[18] = current_right_rudder;

        if (T50::flaps_pos > 0.0f) {
            current_left_flap = (float)limit(rate_limit(current_left_flap, (float)T50::flaps_pos, control_surface_rate, rate), -1.0f, 1.0f);
            current_right_flap = (float)limit(rate_limit(current_right_flap, (float)T50::flaps_pos, control_surface_rate, rate), -1.0f, 1.0f);
            data[9] = current_left_flap;
            data[10] = current_right_flap;
        }
        else {
            float flap_target_left = (float)limit(-T50::aileron_animation_command, -1, 1);
            float flap_target_right = (float)limit(T50::aileron_animation_command, -1, 1);
            current_left_flap = (float)limit(rate_limit(current_left_flap, flap_target_left, control_surface_rate, rate), -1.0f, 1.0f);
            current_right_flap = (float)limit(rate_limit(current_right_flap, flap_target_right, control_surface_rate, rate), -1.0f, 1.0f);
            data[9] = current_left_flap;
            data[10] = current_right_flap;
        }
    }

    float lef_flap = (float)limit((T50::flaps_pos + T50::slats_pos) / 2.0, 0.0, 1.0);
    data[603] = lef_flap;

    if (T50::engine_state == T50::OFF) {
        data[29] = 0.0f;
    }
    else if (T50::engine_state == T50::RUNNING && T50::ab_timer > 0.95) {
        data[29] = 1.0f;
    }
    else {
        data[29] = 0.0f;
    }

    if (T50::engine_state == T50::OFF) {
        data[28] = 0.0f;
    }
    else if (T50::engine_state == T50::RUNNING && T50::ab_timer > 0.95) {
        data[28] = 1.0f;
    }
    else {
        data[28] = 0.0f;
    }

    if (T50::engine_state == T50::OFF) {
        data[611] = 1.0f;
    }
    else {
        float rpm = static_cast<float>(T50::engine_power_readout);
        if (rpm >= 0.67f) {
            data[611] = 0.0f;
        }
        else {
            data[611] = (0.67f - rpm) / (0.67f - 0.0f);
        }
    }
    data[611] = static_cast<float>(limit(data[611], 0.0f, 1.0f));

    float rpml = static_cast<float>(T50::engine_power_readout);
    if (rpml <= 0.70f) {
        data[90] = 1.0f;
    }
    else if (rpml <= 0.90f) {
        data[90] = (0.90f - rpml) / (0.90f - 0.70f);
    }
    else if (rpml <= 1.035f) {
        data[90] = 0.0f;
    }
    else {
        float rpm_factor = (rpml - 1.035f) / (1.1f - 1.035f);
        data[90] = limit(rpm_factor, 0.0f, 1.0f);
    }
    data[90] = static_cast<float>(limit(data[90], 0.0f, 1.0f));

    if (T50::engine_state == T50::OFF) {
        data[610] = 1.0f;
    }
    else {
        float rpm = static_cast<float>(T50::engine_power_readout);
        if (rpm >= 0.67f) {
            data[610] = 0.0f;
        }
        else {
            data[610] = (0.67f - rpm) / (0.67f - 0.0f);
        }
    }
    data[610] = static_cast<float>(limit(data[610], 0.0f, 1.0f));

    float rpmr = static_cast<float>(T50::engine_power_readout);
    if (rpmr <= 0.70f) {
        data[89] = 1.0f;
    }
    else if (rpmr <= 0.90f) {
        data[89] = (0.90f - rpmr) / (0.90f - 0.70f);
    }
    else if (rpmr <= 1.035f) {
        data[89] = 0.0f;
    }
    else {
        float rpm_factor = (rpmr - 1.035f) / (1.1f - 1.035f);
        data[89] = limit(rpm_factor, 0.0f, 1.0f);
    }
    data[89] = static_cast<float>(limit(data[89], 0.0f, 1.0f));

    if (size > 325) {
        if (T50::engine_state == T50::OFF) {
            data[324] = 0.0;
        }
        else {
            data[324] = static_cast<float>(T50::engine_phase);
        }

        if (T50::engine_state == T50::OFF) {
            data[325] = 0.0;
        }
        else {
            data[325] = static_cast<float>(T50::engine_phase);
        }
    }

    data[604] = T50::taxi_lights ? 1.0f : 0.0f;
    data[605] = T50::landing_lights ? 1.0f : 0.0f;
    data[606] = T50::form_light ? 1.0f : 0.0f;
    data[607] = T50::nav_white ? (T50::nav_white_blink ? (T50::nav_white_timer < 0.1f ? 1.0f : 0.0f) : 1.0f) : 0.0f;
    data[608] = T50::anti_collision ? (T50::anti_collision_blink ? (T50::anti_collision_timer < 0.1f ? 1.0f : 0.0f) : 1.0f) : 0.0f;
    data[609] = T50::aar_light ? 1.0f : 0.0f;
    data[612] = T50::nav_lights ? 1.0f : 0.0f;
    data[613] = T50::nav_lights ? 1.0f : 0.0f;

    if (T50::is_destroyed == true) {
        data[114] = 1.0f;
    }
}

void ed_fm_configure(const char* cfg_path) {
    if (!T50::sim_initialised) {
        cockpit_manager.initialize();
        FBW::initialize();  // Initialize FBW system
        T50::left_wing_pos = Vec3(T50::center_of_mass.x - 0.8, T50::center_of_mass.y + 0.5, -T50::wingspan / 2);
        T50::right_wing_pos = Vec3(T50::center_of_mass.x - 0.8, T50::center_of_mass.y + 0.5, T50::wingspan / 2);
        T50::tail_pos = Vec3(T50::center_of_mass.x - 0.7, T50::center_of_mass.y, 0);
        T50::elevator_pos = Vec3(-T50::length / 2, T50::center_of_mass.y, 0);
        T50::left_aileron_pos = Vec3(T50::center_of_mass.x, T50::center_of_mass.y, -T50::wingspan * 0.5);
        T50::right_aileron_pos = Vec3(T50::center_of_mass.x, T50::center_of_mass.y, T50::wingspan * 0.5);
        T50::rudder_pos = Vec3(-T50::length / 2, T50::height / 2, 0);
        T50::engine_pos = Vec3(-T50::length / 2 + 1.0, 0.0, 0.0);  // Single engine, centered
        T50::elevator_command = 0.0;
        T50::elevator_angle = 0.0;
        T50::aileron_command = T50::last_aileron_cmd = 0.0;
        T50::rudder_command = T50::last_rudder_cmd = 0.0;
        T50::roll_error_i = T50::yaw_error_i = 0.0;
        T50::last_yaw_input = 0.0;
        T50::last_pitch_input = 0.0;
        T50::idle_rpm = 0.675;
    }
}

double ed_fm_get_param(unsigned index) {
    switch (index) {
    case ED_FM_SUSPENSION_0_WHEEL_YAW:
    {
        double yaw_source = T50::yaw_analog ? T50::yaw_input : T50::yaw_discrete;
        double ground_speed_knots = T50::ground_speed_knots;
        double max_steering_rad = 0.0;

        if (T50::on_ground) {
            if (ground_speed_knots <= 8.0) {
                max_steering_rad = T50::rad(60.0);
            }
            else if (ground_speed_knots <= 30.0) {
                double slope = (T50::rad(25.0) - T50::rad(60.0)) / (30.0 - 8.0);
                max_steering_rad = T50::rad(60.0) + slope * (ground_speed_knots - 8.0);
            }
            else if (ground_speed_knots <= 60.0) {
                max_steering_rad = T50::rad(25.0);
            }
        }
        return limit(yaw_source, -1.0, 1.0) * max_steering_rad;
    }
    case ED_FM_SUSPENSION_0_RELATIVE_BRAKE_MOMENT: return T50::wheel_brake;
    case ED_FM_SUSPENSION_1_RELATIVE_BRAKE_MOMENT: return T50::wheel_brake;
    case ED_FM_SUSPENSION_2_RELATIVE_BRAKE_MOMENT: return T50::wheel_brake;
    case ED_FM_ANTI_SKID_ENABLE: return true;
    case ED_FM_FC3_STICK_PITCH: return limit(T50::pitch_input / 2, -1.0, 1.0);
    case ED_FM_FC3_STICK_ROLL: return limit(T50::roll_input, -1.0, 1.0);
    case ED_FM_FC3_RUDDER_PEDALS: return limit(-T50::yaw_input, -1.0, 1.0);
    case ED_FM_FC3_THROTTLE_LEFT: return T50::throttle_output;
    case ED_FM_FC3_THROTTLE_RIGHT: return T50::throttle_output;
    case ED_FM_FUEL_INTERNAL_FUEL: return T50::internal_fuel;
    case ED_FM_FUEL_TOTAL_FUEL: return T50::total_fuel;
    case ED_FM_OXYGEN_SUPPLY: return 101000.0;
    case ED_FM_FLOW_VELOCITY: return 10.0;

    case ED_FM_SUSPENSION_0_GEAR_POST_STATE:
    case ED_FM_SUSPENSION_1_GEAR_POST_STATE:
    case ED_FM_SUSPENSION_2_GEAR_POST_STATE: return T50::gear_pos;

    case ED_FM_ENGINE_0_RPM: return 0;
    case ED_FM_ENGINE_0_RELATED_RPM: return 0;
    case ED_FM_ENGINE_0_THRUST: return 0;
    case ED_FM_ENGINE_0_RELATED_THRUST: return 0;

    case ED_FM_ENGINE_1_CORE_RPM: return T50::throttle_input;
    case ED_FM_ENGINE_1_RPM: return T50::engine_power_readout;
    case ED_FM_ENGINE_1_COMBUSTION: return T50::engine_integrity;
    case ED_FM_ENGINE_1_RELATED_THRUST: return limit(T50::engine_power_readout * 0.35, 0.0, 0.9);
    case ED_FM_ENGINE_1_CORE_RELATED_THRUST: {
        double max_dry_thrust = lerp(FM_DATA::mach_table.data(), FM_DATA::max_thrust.data(), FM_DATA::mach_table.size(), T50::mach);
        double max_dry_core_thrust = max_dry_thrust * 0.7;
        double core_thrust = T50::thrust_force * (T50::throttle_output > 1.025 ? 0.6 : 0.7);
        return max_dry_core_thrust > 0 ? limit(core_thrust / max_dry_core_thrust, 0.0, 2.0) : 0.0;
    }
    case ED_FM_ENGINE_1_RELATED_RPM: return limit(T50::engine_power_readout * 0.35, 0.0, 0.9);
    case ED_FM_ENGINE_1_CORE_RELATED_RPM: return T50::engine_power_readout;
    case ED_FM_ENGINE_1_CORE_THRUST: return T50::thrust_force * (T50::throttle_output > 1.025 ? 0.6 : 0.7);
    case ED_FM_ENGINE_1_THRUST: return T50::thrust_force;
    case ED_FM_ENGINE_1_TEMPERATURE: return (pow(T50::engine_power_readout, 3) * 375) + T50::atmosphere_temperature;
    case ED_FM_ENGINE_1_FUEL_FLOW: return (T50::fuel_rate_kg_s);

    // Single engine - ENGINE_2 returns same as ENGINE_1
    case ED_FM_ENGINE_2_CORE_RPM: return T50::throttle_input;
    case ED_FM_ENGINE_2_RPM: return T50::engine_power_readout;
    case ED_FM_ENGINE_2_COMBUSTION: return T50::engine_integrity;
    case ED_FM_ENGINE_2_RELATED_THRUST: return limit(T50::engine_power_readout * 0.35, 0.0, 0.9);
    case ED_FM_ENGINE_2_CORE_RELATED_THRUST: {
        double max_dry_thrust = lerp(FM_DATA::mach_table.data(), FM_DATA::max_thrust.data(), FM_DATA::mach_table.size(), T50::mach);
        double max_dry_core_thrust = max_dry_thrust * 0.7;
        double core_thrust = T50::thrust_force * (T50::throttle_output > 1.025 ? 0.6 : 0.7);
        return max_dry_core_thrust > 0 ? limit(core_thrust / max_dry_core_thrust, 0.0, 2.0) : 0.0;
    }
    case ED_FM_ENGINE_2_RELATED_RPM: return limit(T50::engine_power_readout * 0.35, 0.0, 0.9);
    case ED_FM_ENGINE_2_CORE_RELATED_RPM: return T50::engine_power_readout;
    case ED_FM_ENGINE_2_CORE_THRUST: return T50::thrust_force * (T50::throttle_output > 1.025 ? 0.6 : 0.7);
    case ED_FM_ENGINE_2_THRUST: return T50::thrust_force;
    case ED_FM_ENGINE_2_TEMPERATURE: return (pow(T50::engine_power_readout, 3) * 375) + T50::atmosphere_temperature;
    case ED_FM_ENGINE_2_FUEL_FLOW: return (T50::fuel_rate_kg_s);

    case ED_FM_STICK_FORCE_CENTRAL_PITCH: return 0.0;
    case ED_FM_STICK_FORCE_FACTOR_PITCH: return 1.0;
    case ED_FM_STICK_FORCE_CENTRAL_ROLL: return 0.0;
    case ED_FM_STICK_FORCE_FACTOR_ROLL: return 1.0;
    case ED_FM_CAN_ACCEPT_FUEL_FROM_TANKER: return 1.0;
    }
    return 0;
}

void ed_fm_refueling_add_fuel(double fuel)
{
    if (fuel > 0) {
        double dt = 0.006;
        double fuel_to_add = std::min(fuel, 100.0 * dt);

        double internal_space = T50::max_internal_fuel - T50::internal_fuel;
        double internal_added = std::min(fuel_to_add, internal_space);
        if (internal_added > 0) {
            T50::internal_fuel += internal_added * 10;
            double fuel_fraction = std::min(1.0, std::max(0.0, T50::internal_fuel / T50::max_internal_fuel));
            g_mass_changes.push({
                -internal_added,
                {-0.32 * (1.0 - fuel_fraction), 0.0, 0.0},
                {0.0, 0.0, 0.0}
                });
        }

        double remaining_fuel = fuel_to_add - internal_added;
        if (remaining_fuel > 0 && !T50::external_fuel_stations.empty()) {
            size_t num_refuelable_stations = 0;
            for (const auto& [station, fuel_qty] : T50::external_fuel_stations) {
                if ((station == 2 || station == 10) && fuel_qty > 0 && fuel_qty < 1850.0) {
                    num_refuelable_stations++;
                }
            }
            if (num_refuelable_stations > 0) {
                double fuel_per_station = remaining_fuel / num_refuelable_stations;
                for (auto& [station, fuel_qty] : T50::external_fuel_stations) {
                    if ((station == 2 || station == 10) && fuel_qty > 0 && fuel_qty < 1850.0) {
                        double space = 1850.0 - fuel_qty;
                        double added = std::min(fuel_per_station, space);
                        fuel_qty += added;
                    }
                }
                T50::external_fuel = 0.0;
                for (const auto& [station, fuel_qty] : T50::external_fuel_stations) {
                    if (station == 2 || station == 10) {
                        T50::external_fuel += fuel_qty;
                    }
                }
            }
        }

        T50::total_fuel = T50::internal_fuel + T50::external_fuel;
    }
}


void ed_fm_unlimited_fuel(bool value) { T50::infinite_fuel = value; }
void ed_fm_set_easy_flight(bool value) { T50::easy_flight = value; }
void ed_fm_set_immortal(bool value) { T50::invincible = value; }

void ed_fm_on_damage(int Element, double element_integrity_factor) {
    if (Element >= 0 && Element < 111) {
        T50::element_integrity[Element] = element_integrity_factor;
    }
    g_damage_events.push({ Element, element_integrity_factor });
    if (!T50::invincible) {
        T50::left_wing_integrity = T50::element_integrity[static_cast<size_t>(DamageElement::WingOutLeft)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::WingCentreLeft)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::WingInLeft)];
        T50::right_wing_integrity = T50::element_integrity[static_cast<size_t>(DamageElement::WingOutRight)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::WingCentreRight)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::WingInRight)];
        T50::tail_integrity = T50::element_integrity[static_cast<size_t>(DamageElement::RudderLeft)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::RudderRight)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::Tail)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::TailLeft)] *
            T50::element_integrity[static_cast<size_t>(DamageElement::TailRight)];
        T50::engine_integrity = T50::element_integrity[static_cast<size_t>(DamageElement::Engine1)];

        if (T50::engine_integrity <= 0.2 &&
            (T50::left_wing_integrity <= 0.2 || T50::right_wing_integrity <= 0.2) &&
            T50::tail_integrity <= 0.2) {
            T50::is_destroyed = true;
        }

    }
}

void ed_fm_repair() {
    for (int i = 0; i < 111; i++) T50::element_integrity[i] = 1;
    while (!g_damage_events.empty()) g_damage_events.pop();
}

bool ed_fm_pop_simulation_event(ed_fm_simulation_event& out) {

    if (!g_damage_events.empty()) {
        DamageEvent event = g_damage_events.front();
        g_damage_events.pop();
        out.event_type = ED_FM_EVENT_STRUCTURE_DAMAGE;
        out.event_params[0] = static_cast<double>(event.element_number);
        out.event_params[1] = event.integrity_factor;
        out.event_message[0] = '\0';

        return true;
    }
    out.event_type = ED_FM_EVENT_INVALID;
    return false;
}

bool ed_fm_push_simulation_event(const ed_fm_simulation_event& in) {

    return false;
}

void ed_fm_cold_start() {
    reset_fm_state();
    T50::sim_initialised = false;
    T50::gear_switch = true;
    T50::gear_pos = 1;
    T50::airbrake_switch = false;
    T50::engine_switch = false;
    T50::engine_state = T50::OFF;
    T50::throttle_input = 0.0;
    T50::throttle_output = 0.0;
    T50::engine_power_readout = 0.0;
    T50::ab_timer = 0.0;
    T50::engine_start_timer = 0.0;
    T50::engine_phase = 0.0;
    T50::total_fuel = T50::internal_fuel + T50::external_fuel;
    T50::pitch_input = T50::roll_input = T50::yaw_input = 0.0;
    T50::elevator_command = 0.0;
    T50::aileron_command = 0.0;
    T50::rudder_command = 0.0;
    T50::engine_integrity = 1.0;
    T50::manual_trim_applied = false;
    ed_fm_repair();
    while (!g_damage_events.empty()) g_damage_events.pop();
    cockpit_manager.initialize();
}

void ed_fm_hot_start() {
    reset_fm_state();
    T50::gear_switch = true;
    T50::gear_pos = 1;
    T50::flaps_pos = 0;
    T50::airbrake_switch = false;
    T50::engine_switch = true;
    T50::engine_state = T50::RUNNING;
    T50::throttle_input = 0.0;
    T50::throttle_output = 0.67;
    T50::engine_power_readout = 0.67;
    T50::engine_phase = 0.0;
    T50::ab_timer = 0.0;
    T50::engine_start_timer = 0.0;
    T50::total_fuel = T50::internal_fuel + T50::external_fuel;
    T50::engine_integrity = 1.0;
    T50::velocity_world = Vec3(0, 0, 0);
    T50::pitch_rate = T50::roll_rate = T50::yaw_rate = 0.0;
    T50::pitch = T50::roll = T50::heading = 0.0;
    T50::manual_trim_applied = false;
    ed_fm_repair();
    while (!g_damage_events.empty()) g_damage_events.pop();
    cockpit_manager.initialize();
}

void ed_fm_hot_start_in_air() {
    reset_fm_state();
    T50::gear_switch = false;
    T50::gear_pos = 0;
    T50::flaps_pos = 0;
    T50::airbrake_switch = false;
    T50::engine_switch = true;
    T50::engine_state = T50::RUNNING;
    T50::throttle_input = 0.70;
    T50::throttle_output = 0.70;
    T50::engine_power_readout = 0.70;
    T50::ab_timer = 0.0;
    T50::engine_start_timer = 0.0;
    T50::engine_phase = 0.0;
    T50::total_fuel = T50::internal_fuel + T50::external_fuel;
    T50::engine_integrity = 1.0;
    T50::velocity_world = Vec3(0, 0, 0);
    T50::pitch_rate = T50::roll_rate = T50::yaw_rate = 0.0;
    T50::pitch = T50::roll = T50::heading = 0.0;
    T50::autotrim_active = true;
    T50::manual_trim_applied = false;
    ed_fm_repair();
    while (!g_damage_events.empty()) g_damage_events.pop();
    cockpit_manager.initialize();
}

void ed_fm_release() {
    T50::fm_clock = 0;
    T50::sim_initialised = false;
    ed_fm_repair();
}

double ed_fm_get_shake_amplitude() {
    return T50::shake_amplitude;
}

bool ed_fm_add_local_force_component(double& x, double& y, double& z, double& pos_x, double& pos_y, double& pos_z) { return false; }
bool ed_fm_add_global_force_component(double& x, double& y, double& z, double& pos_x, double& pos_y, double& pos_z) { return false; }
bool ed_fm_add_local_moment_component(double& x, double& y, double& z) { return false; }
bool ed_fm_add_global_moment_component(double& x, double& y, double& z) { return false; }
bool ed_fm_enable_debug_info() { return false; }

bool ed_fm_LERX_vortex_update(unsigned idx, LERX_vortex& out) {
    if (idx > 1) {
        return false; 
    }

    float vortex_strength = 0.0f;
    if (fabs(T50::alpha) >= 8.0f && T50::mach < 1.65f) { 
        vortex_strength = 0.72f * exp(-pow(T50::alpha - 35.0f, 2) / (2 * 600.0f));
        if (T50::alpha > 70.0f) {
            vortex_strength = 0.0f;
        }
        float aoa_factor = (fabs(T50::alpha) - 8.0f) / (15.0f - 8.0f);
        aoa_factor = std::max(0.0f, std::min(aoa_factor, 0.85f));
        vortex_strength *= aoa_factor;
        float humidity_factor = T50::atmosphere_density / 1.225f;
        vortex_strength *= (1.0f + humidity_factor * 0.5f);
        vortex_strength *= std::min(static_cast<float>(T50::V_scalar / 100.0), 1.0f);
        vortex_strength *= 0.70f;
    }

    if (vortex_strength <= 0.01f) {
        out.spline = nullptr;
        out.spline_points_count = 0;
        return true;
    }

    const unsigned num_points = 10;
    static std::vector<LERX_vortex_spline_point> spline_points(num_points);

    float start_x = T50::left_wing_pos.x + 6.0f;
    float start_z = (idx == 0) ? -1.2f : 1.2f;
    float start_y = T50::left_wing_pos.y + 0.025f;

    for (unsigned i = 0; i < num_points; ++i) {
        auto& point = spline_points[i];
        float t = static_cast<float>(i) / (num_points - 1);

        point.pos[0] = start_x - t * 8.0f;
        point.pos[1] = start_y + t * (idx == 0 ? 0.75f : 0.75f);
        point.pos[2] = start_z + t * 0.0f; 

        point.vel[0] = -T50::V_scalar * (1.0f - t);
        point.vel[1] = 0.0f;
        point.vel[2] = 0.0f;

        point.radius = 0.22f + 0.42f * sinf(t * 3.14159f);

        point.opacity = vortex_strength * (1.0f - t);
    }

    out.opacity = vortex_strength;
    out.explosion_start = 9.0f; 
    out.spline = spline_points.data();
    out.spline_points_count = num_points;
    out.spline_point_size_in_bytes = sizeof(LERX_vortex_spline_point);
    out.version = 1; 

    return true; 
}

//########################################################################################################
//########################################################################################################
//########################################################################################################

    // ----- Cockpit Logic -----

inline float limit(float value, float min_val, float max_val) {
    if (value < min_val) return min_val;
    if (value > max_val) return max_val;
    return value;
}

CockpitManager::CockpitManager() {
    draw_args_[709] = 0.0f;
    draw_args_[712] = 0.0f;
    draw_args_[713] = 0.0f;
    draw_args_[714] = 0.0f;
    draw_args_[715] = 0.0f;
}

void CockpitManager::initialize() {
    param_handles_["APU_POWER"] = param_api_.getParamHandle("APU_POWER");
    param_handles_["BATTERY_POWER"] = param_api_.getParamHandle("BATTERY_POWER");
    param_handles_["MAIN_POWER"] = param_api_.getParamHandle("MAIN_POWER");
    param_handles_["WoW"] = param_api_.getParamHandle("WoW");
    param_handles_["AAR"] = param_api_.getParamHandle("AAR");
    param_handles_["N_GEAR_LIGHT"] = param_api_.getParamHandle("N_GEAR_LIGHT");
    param_handles_["R_GEAR_LIGHT"] = param_api_.getParamHandle("R_GEAR_LIGHT");
    param_handles_["L_GEAR_LIGHT"] = param_api_.getParamHandle("L_GEAR_LIGHT");
    param_handles_["TAXI_SWITCH"] = param_api_.getParamHandle("TAXI_SWITCH");
    param_handles_["NAV_LIGHT_SWITCH"] = param_api_.getParamHandle("NAV_LIGHT_SWITCH");
    param_handles_["FORM_KNOB"] = param_api_.getParamHandle("FORM_KNOB");
    param_handles_["AAR_KNOB"] = param_api_.getParamHandle("AAR_KNOB");
    param_handles_["AAR_READY"] = param_api_.getParamHandle("AAR_READY");


    draw_args_[709] = static_cast<float>(getParameter("TAXI_SWITCH", 0.0));
    draw_args_[712] = static_cast<float>(getParameter("AAR", 0.0));
    draw_args_[713] = static_cast<float>(getParameter("AAR_KNOB", 0.0));
    draw_args_[714] = static_cast<float>(getParameter("FORM_KNOB", 0.0));
    draw_args_[715] = static_cast<float>(getParameter("NAV_LIGHT_SWITCH", 0.0));


    param_api_.setParamNumber(param_handles_["MAIN_POWER"], (T50::engine_state == T50::RUNNING || T50::engine_state == T50::RUNNING) ? 1.0 : 0.0);
    param_api_.setParamNumber(param_handles_["BATTERY_POWER"], (T50::engine_switch || T50::engine_switch) ? 1.0 : 0.0);
}

void CockpitManager::update(double dt) {
    updateGearLights(dt);
    updateTaxiLandingLights(dt);
    updateAARLight(dt);
    updateFormationLights(dt);
    updateNavAntiCollisionLights(dt);
}

void CockpitManager::updateDrawArgs(float* data, size_t size) {
    auto setArg = [&](int index, float value) {
        if (index >= 0 && static_cast<size_t>(index) < size) {
            data[index] = value;
        }
        };

    setArg(709, static_cast<float>(getParameter("TAXI_SWITCH", 0.0)));
    setArg(712, static_cast<float>(getParameter("AAR", 0.0)));
    setArg(713, static_cast<float>(getParameter("AAR_KNOB", 0.0)));
    setArg(714, static_cast<float>(getParameter("FORM_KNOB", 0.0)));
    setArg(715, static_cast<float>(getParameter("NAV_LIGHT_SWITCH", 0.0)));
}

double CockpitManager::getParameter(const std::string& name, double fallback_value) {
    if (!T50::sim_initialised) {
        bool engines_on = (T50::engine_state == T50::RUNNING || T50::engine_state == T50::RUNNING);
        if (name == "NAV_LIGHT_SWITCH") {
            if (engines_on) {
                if (name == "NAV_LIGHT_SWITCH") return 0.3;
            }
            return 0.0;
        }
        if (name == "TAXI_SWITCH") {
            if (engines_on && T50::gear_pos == 1.0) {
                if (name == "NAV_LIGHT_SWITCH") return 0.3;
                if (name == "TAXI_SWITCH") return T50::gear_pos == 1.0 ? -1.0 : 0.0;
            }
            return 0.0;
        }
    }
    auto it = param_handles_.find(name);
    if (it == param_handles_.end()) {
        return fallback_value;
    }

    double result = param_api_.getParamNumber(it->second);
    if (result != result) {
        if (name == "WoW") {
            return T50::on_ground ? 1.0 : 0.0;
        }
        else if (name == "MAIN_POWER") {
            return (T50::engine_state == T50::RUNNING || T50::engine_state == T50::RUNNING) ? 1.0 : 0.0;
        }
        else if (name == "BATTERY_POWER") {
            return (T50::engine_switch || T50::engine_switch) ? 1.0 : 0.0;
        }
        return fallback_value;
    }
    return result;
}

void CockpitManager::updateGearLights(double dt) {
    double battery_power = getParameter("BATTERY_POWER");
    double nose_gear = T50::gear_pos;
    double right_gear = T50::gear_pos;
    double left_gear = T50::gear_pos;

    double nose_gear_light = (nose_gear >= 1.0 && battery_power >= 1.0) ? 1.0 : 0.0;
    double right_gear_light = (right_gear >= 1.0 && battery_power >= 1.0) ? 1.0 : 0.0;
    double left_gear_light = (left_gear >= 1.0 && battery_power >= 1.0) ? 1.0 : 0.0;

    param_api_.setParamNumber(param_handles_["N_GEAR_LIGHT"], nose_gear_light);
    param_api_.setParamNumber(param_handles_["R_GEAR_LIGHT"], right_gear_light);
    param_api_.setParamNumber(param_handles_["L_GEAR_LIGHT"], left_gear_light);
}

void CockpitManager::updateTaxiLandingLights(double dt) {
    double taxi_switch = getParameter("TAXI_SWITCH");
    double main_power = getParameter("MAIN_POWER");
    double nose_gear = T50::gear_pos;

    T50::taxi_lights = false;
    T50::landing_lights = false;

    if (taxi_switch == -1.0 && main_power >= 1.0 && nose_gear >= 1.0) {
        T50::taxi_lights = true;
    }
    else if (taxi_switch == 1.0 && main_power >= 1.0 && nose_gear >= 1.0) {
        T50::landing_lights = true;
    }
}

void CockpitManager::updateAARLight(double dt) {
    double aar = getParameter("AAR");
    double aar_knob = getParameter("AAR_KNOB");
    double main_power = getParameter("MAIN_POWER");
    double aar_ready = getParameter("AAR_READY");

    T50::aar_light = (aar >= 1.0 && aar_ready >= 1.0 && main_power >= 1.0 && aar_knob > 0.0);
}

void CockpitManager::updateFormationLights(double dt) {
    double form_knob = getParameter("FORM_KNOB");
    double main_power = getParameter("MAIN_POWER");

    T50::form_light = (main_power >= 1.0 && form_knob > 0.0);
}

void CockpitManager::updateNavAntiCollisionLights(double dt) {
    double light_switch = getParameter("NAV_LIGHT_SWITCH");
    double main_power = getParameter("MAIN_POWER");

    static double flash_timer = 0.0;
    flash_timer += dt;
    if (flash_timer >= 1.50) {
        flash_timer = 0.0;
    }
    T50::nav_white_timer = flash_timer;
    T50::anti_collision_timer = flash_timer;
    float flash_on = (flash_timer > 0.25) ? 1.0f : 0.0f;

    T50::nav_white = false;
    T50::anti_collision = false;
    T50::nav_lights = false;
    T50::nav_white_blink = false;
    T50::anti_collision_blink = false;

    if (main_power < 1.0 || light_switch <= 0.0) {
        flash_timer = 0.0;
        T50::nav_white_timer = 0.0;
        T50::anti_collision_timer = 0.0;
        return;
    }

    if (light_switch < 0.15) {
        T50::nav_white = true;
        T50::anti_collision = true;
        T50::nav_white_blink = true;
        T50::anti_collision_blink = true;
    }
    else if (light_switch < 0.25) {
        T50::nav_white = true;
        T50::anti_collision = true;
        T50::nav_lights = true;
        T50::anti_collision_blink = true;
    }
    else if (light_switch < 0.35) {
        T50::nav_white = true;
        T50::nav_lights = true;
        T50::nav_white_blink = true;
    }
    else {
        T50::nav_white = true;
        T50::nav_lights = true;
    }
}