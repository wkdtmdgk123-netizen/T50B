/*    DebugLog.h
    Simple debug logging utility for T-50B EFM
    Use this for debugging when Visual Studio debugger is not available
*/

#pragma once

#include <fstream>
#include <string>
#include <sstream>
#include <iomanip>
#include <ctime>

namespace DebugLog {
    // Log file path (adjust to your DCS Saved Games folder)
    static const char* LOG_FILE = "C:/Users/[USERNAME]/Saved Games/DCS/Logs/T50_EFM_debug.log";
    
    inline std::string getTimestamp() {
        auto now = std::time(nullptr);
        auto tm = *std::localtime(&now);
        std::ostringstream oss;
        oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
        return oss.str();
    }
    
    inline void log(const std::string& message) {
        std::ofstream log(LOG_FILE, std::ios::app);
        if (log.is_open()) {
            log << "[" << getTimestamp() << "] " << message << std::endl;
            log.close();
        }
    }
    
    template<typename T>
    inline void logValue(const std::string& name, const T& value) {
        std::ostringstream oss;
        oss << name << " = " << value;
        log(oss.str());
    }
    
    // Macro for easy logging
    #define DEBUG_LOG(msg) DebugLog::log(msg)
    #define DEBUG_LOG_VALUE(name, value) DebugLog::logValue(name, value)
    
    // Clear log file
    inline void clear() {
        std::ofstream log(LOG_FILE, std::ios::trunc);
        log.close();
    }
}


