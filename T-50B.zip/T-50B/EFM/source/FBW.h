/*    FBW.h
    Fly-By-Wire Control System for T-50B Golden Eagle
    Advanced flight control laws and protections
*/

#pragma once

#include "T50.h"

namespace FBW {
    // FBW System States
    enum class FBWMode {
        NORMAL,      // Normal FBW operation
        DIRECT,      // Direct control (FBW bypass)
        DEGRADED,    // Degraded mode (limited functionality)
        FAILED       // FBW failure
    };
    
    // FBW Configuration
    struct FBWConfig {
        // Rate limits (deg/s)
        double max_pitch_rate = 40.0;
        double max_roll_rate = 120.0;
        double max_yaw_rate = 30.0;
        
        // Alpha (AoA) limits
        double alpha_max_normal = 25.0;   // Normal flight max AoA (deg)
        double alpha_max_emergency = 35.0; // Emergency max AoA (deg)
        double alpha_stall_warning = 20.0; // Stall warning AoA (deg)
        
        // Beta (sideslip) limits
        double beta_max = 15.0;           // Max sideslip angle (deg)
        
        // G limits
        double g_max_positive = 9.0;      // Max positive G
        double g_max_negative = -3.0;     // Max negative G
        
        // Command filtering
        double pitch_filter_tau = 0.1;    // Pitch command filter time constant
        double roll_filter_tau = 0.08;    // Roll command filter time constant
        double yaw_filter_tau = 0.12;     // Yaw command filter time constant
        
        // Control gains
        double pitch_rate_gain = 1.0;
        double roll_rate_gain = 1.0;
        double yaw_rate_gain = 0.8;
        
        // Alpha protection
        bool alpha_protection_enabled = true;
        double alpha_protection_gain = 2.0;
        
        // Stall protection
        bool stall_protection_enabled = true;
        double stall_protection_gain = 3.0;
        
        // Spin prevention
        bool spin_prevention_enabled = true;
        double spin_prevention_gain = 1.5;
    };
    
    // FBW State
    struct FBWState {
        FBWMode mode = FBWMode::NORMAL;
        bool enabled = true;
        
        // Filtered commands
        double pitch_cmd_filtered = 0.0;
        double roll_cmd_filtered = 0.0;
        double yaw_cmd_filtered = 0.0;
        
        // Rate limiting
        double pitch_rate_limited = 0.0;
        double roll_rate_limited = 0.0;
        double yaw_rate_limited = 0.0;
        
        // Protection states
        bool alpha_limiting_active = false;
        bool stall_protection_active = false;
        bool spin_prevention_active = false;
        bool g_limiting_active = false;
        
        // Protection commands
        double alpha_protection_cmd = 0.0;
        double stall_protection_cmd = 0.0;
        double spin_prevention_cmd = 0.0;
        double g_limiting_cmd = 0.0;
    };
    
    // Global FBW state
    extern FBWState g_fbw_state;
    extern FBWConfig g_fbw_config;
    
    // FBW Functions
    void initialize();
    void update(double dt);
    
    // Command processing
    double process_pitch_command(double pitch_input, double dt);
    double process_roll_command(double roll_input, double dt);
    double process_yaw_command(double yaw_input, double dt);
    
    // Protections
    double apply_alpha_protection(double pitch_cmd, double dt);
    double apply_stall_protection(double pitch_cmd, double dt);
    double apply_spin_prevention(double yaw_cmd, double roll_cmd, double dt);
    double apply_g_limiting(double pitch_cmd, double dt);
    double apply_rate_limiting(double cmd, double current_rate, double max_rate, double dt);
    
    // Command filtering
    double filter_command(double input, double& filtered, double tau, double dt);
    
    // Mode management
    void set_mode(FBWMode mode);
    FBWMode get_mode();
    bool is_enabled();
    
    // Status
    bool is_alpha_limiting_active();
    bool is_stall_protection_active();
    bool is_spin_prevention_active();
    bool is_g_limiting_active();
}


