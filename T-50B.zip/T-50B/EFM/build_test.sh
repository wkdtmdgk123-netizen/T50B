#!/bin/bash
# T-50B EFM 컴파일 테스트 스크립트
# macOS에서 기본적인 컴파일 오류를 확인합니다

set -e

echo "=== T-50B EFM 컴파일 테스트 ==="
echo ""

# 디렉토리 설정
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/source"
BUILD_DIR="$SCRIPT_DIR/build_test"

# 빌드 디렉토리 생성
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

echo "소스 디렉토리: $SOURCE_DIR"
echo "빌드 디렉토리: $BUILD_DIR"
echo ""

# 컴파일러 확인
if command -v clang++ &> /dev/null; then
    CXX=clang++
elif command -v g++ &> /dev/null; then
    CXX=g++
else
    echo "오류: C++ 컴파일러를 찾을 수 없습니다"
    exit 1
fi

echo "사용 컴파일러: $CXX"
$CXX --version | head -1
echo ""

# 컴파일 옵션
CXXFLAGS="-std=c++17 -Wall -Wextra -O2"
INCLUDES="-I$SOURCE_DIR -I$SOURCE_DIR/FM -I$SOURCE_DIR/Cockpit"

# 소스 파일 목록
SOURCES=(
    "$SOURCE_DIR/T50.cpp"
)

echo "컴파일 시작..."
echo ""

# 컴파일 (실제 DLL은 만들지 않고 오류만 체크)
$CXX $CXXFLAGS $INCLUDES -c "${SOURCES[0]}" -o T50.o 2>&1 | tee compile.log

if [ ${PIPESTATUS[0]} -eq 0 ]; then
    echo ""
    echo "✅ 컴파일 성공!"
    echo ""
    echo "참고: 이것은 macOS에서의 컴파일 테스트입니다."
    echo "실제 DCS용 Windows DLL을 만들려면 Windows 환경과 DCS SDK가 필요합니다."
    echo ""
    echo "다음 단계:"
    echo "1. Windows PC에서 Visual Studio 설치"
    echo "2. DCS SDK 다운로드"
    echo "3. CMakeLists.txt를 사용하여 빌드"
else
    echo ""
    echo "❌ 컴파일 오류 발생"
    echo "compile.log 파일을 확인하세요"
    exit 1
fi

