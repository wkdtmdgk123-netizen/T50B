# T-50B EFM 디버깅 가이드

## ✅ 디버깅 가능 여부

**네, 전체 코드 디버깅이 가능합니다!**

Visual Studio를 사용하여 다음을 디버깅할 수 있습니다:
- ✅ 브레이크포인트 설정
- ✅ 변수 값 확인
- ✅ 호출 스택 추적
- ✅ 단계별 실행 (Step Over/Into/Out)
- ✅ 메모리/레지스터 확인
- ✅ 조건부 브레이크포인트

---

## 🔧 디버깅 설정 방법

### 방법 1: Visual Studio에서 DCS에 연결 (권장)

#### Step 1: Debug 빌드 생성

```cmd
cd EFM
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64 -DDCS_SDK_PATH="[DCS SDK 경로]"
cmake --build . --config Debug
```

#### Step 2: DLL을 DCS 모드 폴더에 복사

```
build\bin\Debug\T50_EFM.dll
→
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll
```

**참고**: DCS는 Release 폴더를 찾지만, Debug DLL도 작동합니다.

#### Step 3: Visual Studio에서 프로젝트 열기

1. Visual Studio 실행
2. `File` → `Open` → `CMake...`
3. `EFM/CMakeLists.txt` 선택
4. `CMake` → `Change CMake Settings` → `Debug` 선택

#### Step 4: 디버깅 시작

**옵션 A: DCS 실행 후 연결 (Attach)**

1. DCS World 실행
2. T-50B 항공기로 미션 시작
3. Visual Studio에서:
   - `Debug` → `Attach to Process...`
   - `dcs.exe` 프로세스 선택
   - `Attach` 클릭
4. 브레이크포인트 설정 후 테스트

**옵션 B: Visual Studio에서 DCS 실행**

1. Visual Studio에서 프로젝트 속성 열기
2. `Debugging` 설정:
   - Command: `C:\Program Files\Eagle Dynamics\DCS World\bin\DCS.exe`
   - Working Directory: `C:\Program Files\Eagle Dynamics\DCS World`
3. `F5`로 디버깅 시작

---

### 방법 2: 로그 파일 사용 (간단)

코드에 로그 출력 추가:

```cpp
#include <fstream>

void debug_log(const char* message) {
    std::ofstream log("C:/Users/[사용자명]/Saved Games/DCS/Logs/T50_EFM_debug.log", 
                      std::ios::app);
    log << message << std::endl;
    log.close();
}
```

사용 예:
```cpp
void ed_fm_simulate(double dt) {
    debug_log("ed_fm_simulate called");
    // ...
}
```

---

## 🎯 주요 디버깅 포인트

### 1. EFM 초기화
```cpp
// T50.cpp - ed_fm_configure 함수
void ed_fm_configure(const char* cfg_path) {
    // 여기에 브레이크포인트 설정
    if (!T50::sim_initialised) {
        // 초기화 로직 확인
    }
}
```

### 2. 물리 시뮬레이션
```cpp
// T50.cpp - ed_fm_simulate 함수
void ed_fm_simulate(double dt) {
    // 매 프레임 호출됨
    // dt 값, 변수 상태 확인
}
```

### 3. 입력 처리
```cpp
// T50.cpp - ed_fm_set_command 함수
void ed_fm_set_command(int command, float value) {
    // 조종 입력 확인
    switch (command) {
        case JoystickPitch:
            // 브레이크포인트 설정
            break;
    }
}
```

### 4. 추력 계산
```cpp
// T50.cpp - 엔진 추력 계산 부분
if (T50::throttle_output <= 1.025) {
    // MIL 추력 계산
} else {
    // AB 추력 계산
}
```

---

## 🔍 디버깅 팁

### 1. 조건부 브레이크포인트

특정 조건에서만 멈추기:
```cpp
// 예: 속도가 Mach 1.0 이상일 때만
if (T50::mach > 1.0) {
    // 브레이크포인트 설정
}
```

Visual Studio에서:
- 브레이크포인트 우클릭 → `Conditions...`
- 조건 입력: `T50::mach > 1.0`

### 2. 데이터 브레이크포인트

변수 값이 변경될 때 멈추기:
- 변수에 브레이크포인트 설정
- `When changed` 옵션 선택

### 3. 호출 스택 확인

함수 호출 경로 추적:
- `Debug` → `Windows` → `Call Stack`

### 4. 조사식 창 사용

중요 변수 모니터링:
- `Debug` → `Windows` → `Watch`
- 변수 추가: `T50::mach`, `T50::throttle_output` 등

---

## 📝 디버그 빌드 vs 릴리즈 빌드

### Debug 빌드
- ✅ 디버깅 정보 포함 (PDB 파일)
- ✅ 최적화 없음 (코드 읽기 쉬움)
- ✅ 어설션 활성화
- ❌ 느린 실행 속도
- ❌ 큰 파일 크기

### Release 빌드
- ✅ 빠른 실행 속도
- ✅ 작은 파일 크기
- ❌ 디버깅 어려움
- ❌ 최적화로 인한 코드 변경

**권장**: 개발 중에는 Debug, 최종 테스트는 Release

---

## 🛠️ Visual Studio 디버깅 설정

### 프로젝트 속성 설정

1. **솔루션 탐색기**에서 프로젝트 우클릭
2. **Properties** 선택
3. **Configuration Properties** → **Debugging**:
   - Command: DCS 실행 파일 경로
   - Command Arguments: (필요시)
   - Working Directory: DCS 설치 폴더
   - Attach: `Yes` (Attach 방식 사용 시)

### 디버그 심볼 설정

1. **Properties** → **C/C++** → **General**
   - Debug Information Format: `Program Database (/Zi)`
2. **Properties** → **Linker** → **Debugging**
   - Generate Debug Info: `Yes (/DEBUG)`
   - Generate Program Database File: `$(OutDir)$(TargetName).pdb`

---

## 🐛 일반적인 디버깅 시나리오

### 시나리오 1: 추력이 작동하지 않음

```cpp
// T50.cpp - 추력 계산 부분에 브레이크포인트
void ed_fm_simulate(double dt) {
    // ...
    if (T50::throttle_output <= 1.025) {
        // 여기서 throttle_output, thrust_force 값 확인
        double norm_throttle = (T50::throttle_output - 0.67) / 0.355;
        T50::thrust_force = (idle_thrust + dry_range * thrust_factor) * ...;
    }
}
```

### 시나리오 2: 제어면이 반응하지 않음

```cpp
// T50.cpp - 제어면 계산 부분
void ed_fm_simulate(double dt) {
    // ...
    double elevator_cmd = (pitch_cmd_source * ...);
    // elevator_cmd 값 확인
    T50::elevator_command = limit(elevator_cmd, -1.0, 1.0);
}
```

### 시나리오 3: 엔진이 시작되지 않음

```cpp
// T50.cpp - 엔진 시작 부분
case EnginesOn:
    if (T50::internal_fuel > 25) {
        // 브레이크포인트 설정
        if (T50::engine_state == T50::OFF) {
            T50::engine_state = T50::STARTING;
        }
    }
    break;
```

---

## 📊 디버깅 체크리스트

- [ ] Debug 빌드 생성
- [ ] PDB 파일 생성 확인
- [ ] DLL을 DCS 모드 폴더에 복사
- [ ] Visual Studio에서 DCS 프로세스 연결
- [ ] 브레이크포인트 설정
- [ ] 조사식 창에 변수 추가
- [ ] 호출 스택 확인 가능

---

## ⚠️ 주의사항

1. **DCS 실행 중 디버깅**
   - DCS가 DLL을 로드한 후 연결해야 함
   - DLL이 이미 로드되면 재시작 필요

2. **성능 영향**
   - Debug 빌드는 느릴 수 있음
   - 브레이크포인트에서 멈추면 DCS도 멈춤

3. **PDB 파일**
   - DLL과 같은 폴더에 PDB 파일 필요
   - 심볼 로드 확인: `Debug` → `Windows` → `Modules`

---

## 💡 고급 디버깅

### 원격 디버깅
- 다른 PC에서 실행 중인 DCS에 연결 가능
- Visual Studio Remote Debugger 사용

### 메모리 디버깅
- `Debug` → `Windows` → `Memory`
- 메모리 누수 확인

### 성능 프로파일링
- Visual Studio Profiler 사용
- 병목 지점 찾기

---

## 📞 문제 해결

### "No symbols loaded"
- PDB 파일 경로 확인
- `Debug` → `Windows` → `Modules`에서 심볼 로드 확인

### "Breakpoint will not be hit"
- Debug 빌드인지 확인
- 코드가 실제로 실행되는지 확인
- 최적화로 인한 코드 재배치 확인

### "Cannot attach to process"
- 관리자 권한으로 Visual Studio 실행
- DCS가 실행 중인지 확인

---

## ✅ 요약

**디버깅 가능**: ✅ **네, 전체 코드 디버깅 가능합니다!**

**필요한 것**:
1. Visual Studio (Debug 빌드)
2. Debug DLL 생성
3. DCS에 연결

**방법**:
- Attach to Process (권장)
- 또는 Visual Studio에서 DCS 실행

**팁**: 로그 파일도 함께 사용하면 더 효과적입니다!


