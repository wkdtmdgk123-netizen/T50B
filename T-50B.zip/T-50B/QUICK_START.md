# T-50B DCS 테스트 - 빠른 시작 가이드

## ❓ 지금 바로 테스트할 수 있나요?

### 답변: **아니요, 아직 불가능합니다**

**이유**: Windows DLL이 필요하지만 아직 빌드되지 않았습니다.

---

## ✅ 준비된 것들

1. ✅ **코드 파일들** - 모두 준비됨
   - `T-50B.lua` - 항공기 정의
   - `T50.cpp`, `T50.h` - EFM 소스 코드
   - `entry.lua` - 진입점 파일
   - 모든 헤더 파일

2. ✅ **컴파일 테스트** - 성공
   - macOS에서 문법 오류 없음 확인

---

## ❌ 아직 필요한 것

### 1. Windows DLL 빌드 (필수!)

현재 macOS 환경에서는 Windows DLL을 만들 수 없습니다.

**필요한 것**:
- Windows PC
- Visual Studio 2019+
- DCS SDK

**빌드 방법**: `BUILD_INSTRUCTIONS.md` 참조

---

## 🚀 테스트를 위한 단계

### Step 1: Windows PC에서 DLL 빌드
```cmd
cd T-50B\EFM
mkdir build
cd build
cmake .. -DDCS_SDK_PATH="[DCS SDK 경로]"
cmake --build . --config Release
```

### Step 2: DCS 모드 폴더에 설치
```
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\
├── entry.lua
├── T-50B.lua
└── EFM\bin\Release\T50_EFM.dll
```

### Step 3: DCS 실행 및 테스트
1. DCS World 실행
2. 미션 에디터 → 항공기 추가 → T-50B
3. 플레이

---

## 📋 체크리스트

- [x] 코드 파일 준비
- [x] 컴파일 테스트 통과
- [x] entry.lua 생성
- [x] T-50B.lua에 EFM 설정 추가
- [ ] **Windows DLL 빌드** ← 여기서 막힘
- [ ] DCS 모드 폴더 설치
- [ ] 실제 테스트

---

## 💡 요약

**현재 상태**: 코드는 완성되었지만, **Windows 환경에서 DLL을 빌드해야** DCS에서 테스트할 수 있습니다.

**다음 작업**: Windows PC에서 Visual Studio로 DLL 빌드

**예상 소요 시간**: DLL 빌드 후 약 10분 내외

---

## 📞 도움이 필요하신가요?

- 빌드 방법: `BUILD_INSTRUCTIONS.md`
- 테스트 가이드: `DCS_TEST_GUIDE.md`
- 데이터 요구사항: `T50_DATA_REQUIREMENTS.md`


