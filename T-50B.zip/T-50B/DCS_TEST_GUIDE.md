# T-50B DCS 테스트 가이드

## ⚠️ 현재 상태

### ✅ 준비된 것들
- ✅ T-50B 항공기 정의 파일 (`T-50B.lua`)
- ✅ EFM 소스 코드 (`T50.cpp`, `T50.h`)
- ✅ 유틸리티 파일들 (`Utility.h`, `Inputs.h`)
- ✅ DCS SDK 스텁 헤더
- ✅ 빌드 설정 (`CMakeLists.txt`)
- ✅ Entry 파일 (`entry.lua`)
- ✅ 컴파일 테스트 통과 (macOS)

### ❌ 아직 필요한 것들
- ❌ **Windows DLL 빌드** (가장 중요!)
- ❌ DCS 모드 폴더 설치
- ❌ T-50B 3D 모델 (현재는 F-22A 모델 사용)

---

## 🚀 DCS에서 테스트하기

### 1단계: Windows DLL 빌드 (필수)

현재 macOS 환경에서는 Windows DLL을 직접 만들 수 없습니다. 다음 중 하나를 선택하세요:

#### 옵션 A: Windows PC 사용 (권장)
1. **Visual Studio 2019 이상** 설치 (C++ 개발 도구 포함)
2. **DCS SDK** 다운로드
   - DCS World 공식 포럼에서 SDK 다운로드
   - 경로 예: `C:\Program Files\Eagle Dynamics\DCS World SDK`
3. **빌드 실행**:
   ```cmd
   cd T-50B\EFM
   mkdir build
   cd build
   cmake .. -DDCS_SDK_PATH="C:\Program Files\Eagle Dynamics\DCS World SDK"
   cmake --build . --config Release
   ```
4. 생성된 파일: `build\bin\Release\T50_EFM.dll`

#### 옵션 B: 크로스 컴파일 (고급)
- macOS에서 mingw-w64 사용 가능하지만 복잡함
- DCS SDK 헤더 파일 필요

---

### 2단계: DCS 모드 폴더 구조 생성

Windows에서 다음 폴더 구조를 만드세요:

```
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\
├── entry.lua                    # (이미 생성됨)
├── T-50B.lua                    # (이미 있음)
├── EFM\
│   └── bin\
│       └── Release\
│           └── T50_EFM.dll      # ← 여기에 빌드된 DLL 복사
└── (기타 리소스 파일들)
```

---

### 3단계: T-50B.lua에 EFM 설정 추가

`T-50B.lua` 파일 끝에 다음을 추가하세요:

```lua
-- EFM Configuration
EFM = {
    file = "T50_EFM.dll",
    path = current_mod_path.."/EFM/bin/Release/",
}
```

---

### 4단계: 파일 복사

1. **entry.lua** → `Saved Games\DCS\Mods\aircraft\T-50B\entry.lua`
2. **T-50B.lua** → `Saved Games\DCS\Mods\aircraft\T-50B\T-50B.lua`
3. **T50_EFM.dll** → `Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll`

---

### 5단계: DCS에서 테스트

1. **DCS World 실행**
2. **미션 에디터** 열기
3. **항공기 추가** → **T-50B** 선택
4. **플레이** 클릭
5. 비행 테스트 진행

---

## ⚠️ 알려진 제한사항

### 1. 3D 모델
- 현재는 **F-22A 모델**을 사용합니다
- T-50B 전용 모델이 필요합니다
- `T-50B.lua`의 `Shape = "F-22A"` 부분 참조

### 2. 공기역학 데이터
- 현재는 **추정값**을 사용합니다
- 실제 T-50B 데이터로 교체 권장
- `T50_DATA_REQUIREMENTS.md` 참조

### 3. DLL 없이는 테스트 불가
- **EFM DLL이 없으면 DCS에서 항공기가 작동하지 않습니다**
- 최소한 기본 DLL이라도 빌드해야 합니다

---

## 🔍 문제 해결

### "T50_EFM.dll not found" 오류
- DLL 경로 확인: `T-50B.lua`의 EFM 경로가 올바른지 확인
- DLL 파일이 올바른 위치에 있는지 확인

### "Aircraft not found" 오류
- `entry.lua`가 올바른 위치에 있는지 확인
- DCS 로그 확인: `Saved Games\DCS\Logs\dcs.log`

### DLL 로드 오류
- DCS SDK 버전 확인
- Visual C++ 재배포 가능 패키지 설치 확인

---

## 📝 요약

**현재 상태**: 코드는 준비되었지만, **Windows DLL 빌드가 필요**합니다.

**다음 단계**:
1. ✅ 코드 파일 준비 완료
2. ⏳ Windows PC에서 DLL 빌드 필요
3. ⏳ DCS 모드 폴더에 설치
4. ⏳ 테스트 진행

**즉시 테스트 가능 여부**: ❌ **아니요** - Windows DLL 빌드가 필요합니다.

---

## 💡 대안

DLL 없이도 기본적인 Lua 파일 테스트는 가능하지만, EFM(비행 물리)이 작동하지 않습니다:
- 항공기 목록에는 나타날 수 있음
- 하지만 비행 시뮬레이션이 작동하지 않음
- DLL이 필수입니다


