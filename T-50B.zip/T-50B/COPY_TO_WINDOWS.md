# Windows로 복사하기 - 파일 구조 가이드

## 📦 전체 파일 구조

Windows PC로 복사할 때 다음 구조를 유지하세요:

```
T-50B/
├── entry.lua                          ✅ DCS 진입점
├── T-50B.lua                          ✅ 항공기 정의 (EFM 설정 포함)
├── entry_T-50B.lua                    (참고용)
│
├── EFM/
│   ├── CMakeLists.txt                 ✅ 빌드 설정
│   ├── build_windows.bat              ✅ 자동 빌드 스크립트 (상세)
│   ├── build_windows_simple.bat       ✅ 자동 빌드 스크립트 (간단)
│   │
│   └── source/
│       ├── T50.cpp                    ✅ EFM 메인 소스
│       ├── T50.h                      ✅ EFM 헤더
│       ├── Utility.h                  ✅ 유틸리티 함수
│       ├── Inputs.h                   ✅ 입력 정의
│       │
│       ├── FM/
│       │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h  ✅ DCS SDK 스텁
│       │
│       └── Cockpit/
│           └── CockpitAPI_Declare.h   ✅ 조종석 API 스텁
│
└── (문서 파일들 - 선택사항)
    ├── WINDOWS_BUILD_GUIDE.md
    ├── BUILD_INSTRUCTIONS.md
    ├── DCS_TEST_GUIDE.md
    └── README.md
```

---

## 🚀 빠른 시작 (3단계)

### 1단계: 파일 복사
위 구조대로 Windows PC에 복사

### 2단계: 빌드 실행
`EFM\build_windows_simple.bat` 더블클릭
(또는 파일 열어서 DCS SDK 경로 수정 후 실행)

### 3단계: DLL 확인
`EFM\build\bin\Release\T50_EFM.dll` 생성 확인

---

## ✅ 필수 파일 체크리스트

빌드에 필요한 최소 파일:

- [x] `EFM/CMakeLists.txt`
- [x] `EFM/source/T50.cpp`
- [x] `EFM/source/T50.h`
- [x] `EFM/source/Utility.h`
- [x] `EFM/source/Inputs.h`
- [x] `EFM/source/FM/wHumanCustomPhysicsAPI_ImplementationDeclare.h`
- [x] `EFM/source/Cockpit/CockpitAPI_Declare.h`

빌드 스크립트 (선택, 편의용):

- [x] `EFM/build_windows.bat`
- [x] `EFM/build_windows_simple.bat`

---

## 📝 빌드 전 확인사항

1. **Visual Studio 설치 확인**
   - Visual Studio 2019 이상
   - "C++를 사용한 데스크톱 개발" 워크로드 포함

2. **CMake 설치 확인**
   - 명령 프롬프트에서 `cmake --version` 실행

3. **DCS SDK 경로 확인**
   - `build_windows_simple.bat` 파일에서 경로 수정:
   ```bat
   set "DCS_SDK_PATH=C:\Program Files\Eagle Dynamics\DCS World SDK"
   ```

---

## 🔧 빌드 방법

### 방법 1: 간단한 스크립트 (권장)
1. `EFM\build_windows_simple.bat` 열기
2. DCS SDK 경로 수정
3. 저장 후 더블클릭

### 방법 2: 상세 스크립트
1. `EFM\build_windows.bat` 더블클릭
2. 안내에 따라 진행

### 방법 3: 수동 빌드
```cmd
cd EFM
mkdir build
cd build
cmake .. -G "Visual Studio 17 2022" -A x64 -DDCS_SDK_PATH="C:\Program Files\Eagle Dynamics\DCS World SDK"
cmake --build . --config Release
```

---

## 📍 빌드 결과 위치

빌드 성공 시:
- `EFM\build\bin\Release\T50_EFM.dll`

이 파일을 DCS 모드 폴더로 복사:
- `C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll`

---

## ⚠️ 주의사항

1. **폴더 구조 유지**: `source/FM/` 및 `source/Cockpit/` 폴더 구조 중요
2. **경로 구분자**: Windows에서는 `\` 사용, CMakeLists.txt는 `/` 사용 가능
3. **DCS SDK**: 없어도 스텁 헤더로 컴파일 가능하지만, 실제 DCS SDK 권장

---

## 💡 팁

- 첫 빌드는 1-2분 소요
- 오류 발생 시 `WINDOWS_BUILD_GUIDE.md` 참조
- 빌드 로그는 `EFM\build\` 폴더에 생성됨


