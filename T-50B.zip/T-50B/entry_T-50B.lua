--[[
    T-50B Golden Eagle Entry Point
    Based on F-22A Raptor by Grinnelli Designs
    Converted to T-50B specifications
    
    This file shows how to integrate T-50B into entry.lua
--]]

-- Add T-50B to entry.lua:
dofile(current_mod_path .. "/T-50B.lua")  -- T-50B Golden Eagle
make_view_settings('T-50B', ViewSettings, SnapViews)
