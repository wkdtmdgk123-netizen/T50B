# T-50B DCS 모드 빌드 및 설치 가이드

## 📋 현재 상태

### ✅ 완료된 작업
- T-50B 항공기 정의 파일 (`T-50B.lua`)
- EFM 소스 코드 (`T50.cpp`, `T50.h`)
- 유틸리티 헤더 파일 (`Utility.h`, `Inputs.h`)
- 빌드 설정 파일 (`CMakeLists.txt`)

### ⚠️ 필요한 작업
1. **DCS SDK 설치 및 경로 설정**
2. **EFM DLL 빌드**
3. **모드 폴더 구조 생성**
4. **entry.lua에 코드 추가**

---

## 🔧 빌드 방법

### 1. 사전 요구사항

#### Windows
- **Visual Studio 2019 이상** (C++ 개발 도구 포함)
- **CMake 3.10 이상**
- **DCS World SDK** (Eagle Dynamics에서 제공)

#### DCS SDK 다운로드
1. DCS World 공식 포럼에서 SDK 다운로드
2. SDK를 설치하거나 압축 해제
3. SDK 경로를 기록해두세요 (예: `C:/Program Files/Eagle Dynamics/DCS World SDK`)

### 2. 빌드 단계

#### 방법 1: CMake GUI 사용

1. **CMake GUI 실행**
2. **소스 디렉토리**: `T-50B/EFM` 폴더 선택
3. **빌드 디렉토리**: `T-50B/EFM/build` 생성
4. **Configure 클릭**
   - Visual Studio 버전 선택
   - **DCS_SDK_PATH** 변수 설정:
     - 변수 추가: `DCS_SDK_PATH` (경로 타입)
     - 값: DCS SDK 설치 경로
5. **Generate 클릭**
6. **Open Project 클릭** (Visual Studio 열림)
7. Visual Studio에서 **빌드 > 솔루션 빌드** (F7)

#### 방법 2: 명령줄 사용

```bash
cd T-50B/EFM
mkdir build
cd build

# DCS SDK 경로 설정 (예시)
set DCS_SDK_PATH=C:\Program Files\Eagle Dynamics\DCS World SDK

# CMake 구성
cmake .. -DDCS_SDK_PATH="%DCS_SDK_PATH%"

# 빌드
cmake --build . --config Release
```

### 3. 빌드 결과

빌드 성공 시 다음 파일이 생성됩니다:
- `EFM/build/bin/Release/T50_EFM.dll` (또는 `EFM/build/Release/T50_EFM.dll`)

---

## 📁 DCS 모드 설치

### 1. 모드 폴더 구조 생성

DCS World 모드 폴더 위치:
- **Windows**: `C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B`

다음 구조로 폴더 생성:

```
T-50B/
├── entry.lua                    # 모드 진입점
├── T-50B.lua                    # 항공기 정의
├── EFM/
│   └── bin/
│       └── Release/
│           └── T50_EFM.dll      # 빌드된 DLL (여기로 복사)
└── (기타 리소스 파일들)
```

### 2. entry.lua 생성

`T-50B/entry.lua` 파일 생성:

```lua
local T50B_path = lfs.writedir()..[[Mods\aircraft\T-50B\]]

dofile(T50B_path..[[T-50B.lua]])
make_view_settings('T-50B', ViewSettings, SnapViews)
```

### 3. DLL 복사

빌드된 DLL을 모드 폴더로 복사:
```
EFM/build/bin/Release/T50_EFM.dll 
→ 
C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll
```

### 4. T-50B.lua 수정

`T-50B.lua` 파일에서 EFM 경로 확인:

```lua
-- T-50B.lua 파일 끝부분에 추가 필요할 수 있음
EFM = {
    file = "T50_EFM.dll",
    path = current_mod_path.."/EFM/bin/Release/",
}
```

---

## ⚠️ 주의사항

### 1. 모델 파일
- 현재는 **F-22A 모델을 사용** 중입니다
- T-50B 전용 3D 모델이 필요합니다
- `T-50B.lua`의 `Shape = "F-22A"` 부분을 T-50B 모델로 변경 필요

### 2. 데이터 검증
- 공기역학 및 엔진 데이터는 **추정값**입니다
- 실제 T-50B 데이터로 교체 권장 (`T50_DATA_REQUIREMENTS.md` 참조)

### 3. DCS SDK 헤더 파일
빌드 시 다음 헤더 파일이 필요합니다:
- `<FM/wHumanCustomPhysicsAPI_ImplementationDeclare.h>`
- `<Cockpit/CockpitAPI_Declare.h>`

이 파일들은 DCS SDK에 포함되어 있어야 합니다.

---

## 🧪 테스트 방법

1. **DCS World 실행**
2. **미션 에디터** 열기
3. **항공기 추가** → **T-50B** 선택
4. **플레이** 클릭
5. 비행 테스트 진행

---

## 🐛 문제 해결

### 빌드 오류

#### "DCS_SDK_PATH not found"
- CMake 구성 시 `DCS_SDK_PATH` 변수를 올바르게 설정했는지 확인
- SDK 경로가 올바른지 확인

#### "Cannot open include file"
- DCS SDK가 올바르게 설치되었는지 확인
- SDK Include 폴더에 필요한 헤더 파일이 있는지 확인

#### "LNK2019: unresolved external symbol"
- DCS SDK의 라이브러리 파일 경로 확인
- 필요한 라이브러리 링크 확인

### 런타임 오류

#### "T50_EFM.dll not found"
- DLL이 올바른 위치에 있는지 확인
- 경로가 `T-50B.lua`의 설정과 일치하는지 확인

#### "Aircraft not found"
- `entry.lua`가 올바르게 작성되었는지 확인
- DCS 로그 파일 확인 (`Saved Games/DCS/Logs/`)

---

## 📝 추가 정보

- **원본 모드**: F-22A Raptor by Grinnelli Designs
- **변환**: F-22A → T-50B Golden Eagle
- **라이선스**: GNU General Public License v3.0

---

## 💡 다음 단계

1. ✅ EFM 빌드 완료
2. ⏳ T-50B 3D 모델 제작/적용
3. ⏳ 실제 공기역학 데이터 입력
4. ⏳ 조종석(코크핏) 모델 제작
5. ⏳ 사운드 파일 추가

