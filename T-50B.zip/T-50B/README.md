# T-50B Golden Eagle - DCS World Mod

T-50B Golden Eagle 훈련기 모드 파일 모음

## 📁 파일 구조

```
T-50B/
├── README.md                    # 이 파일
├── T-50B.lua                    # T-50B 항공기 정의 파일
├── T50_DATA_REQUIREMENTS.md     # 공기역학 및 엔진 데이터 요구사항 문서
├── entry_T-50B.lua              # entry.lua에 추가할 코드 예시
└── EFM/
    └── source/
        ├── T50.h                # T-50B External Flight Model 헤더 파일
        └── T50.cpp              # T-50B External Flight Model 구현 파일
```

## 📄 파일 설명

### T-50B.lua
- T-50B 항공기의 DCS World 정의 파일
- 물리 파라미터, 무장 시스템(제거됨), 스모크 시스템 등 포함
- `entry.lua`에서 로드되어야 함

### T50.h
- External Flight Model (EFM) 헤더 파일
- 공기역학 데이터, 엔진 추력 곡선, 변수 선언 등 포함
- T-50B 사양에 맞게 조정됨 (단발 엔진, Thrust Vectoring 제거)

### T50.cpp
- External Flight Model 구현 파일
- 비행 물리 시뮬레이션 로직 포함
- F-22A RAPTOR.cpp에서 변환됨

### T50_DATA_REQUIREMENTS.md
- T-50B에 필요한 공기역학 및 엔진 데이터 상세 요구사항
- 각 데이터의 의미, 단위, 수집 방법 등 포함

### entry_T-50B.lua
- `entry.lua`에 추가해야 할 코드 예시
- T-50B를 DCS World에 등록하는 방법

## 🔧 주요 변경사항

### F-22A에서 T-50B로 변환된 내용:

1. **엔진 시스템**
   - 쌍발 엔진 → 단발 엔진 (F-404-GE-102)
   - 추력: ~78kN MIL, ~130kN AB

2. **제어면 시스템**
   - Elevon → Elevator (전통적인 수평꼬리날개)
   - Thrust Vectoring 제거

3. **무장 시스템**
   - 모든 무장 제거 (훈련기)
   - 스모크 시스템만 유지 (색상 선택 가능)

4. **물리 파라미터**
   - 중량: 6,470kg (빈 중량)
   - 날개 면적: 25.3 m²
   - 최대 속도: Mach 1.5

## 📊 필요한 데이터

상세한 데이터 요구사항은 `T50_DATA_REQUIREMENTS.md`를 참조하세요.

주요 데이터:
- 마하수별 공기역학 계수 (13개 포인트)
- 마하수별 엔진 추력 곡선 (13개 포인트)
- 제어면 반응 속도 및 편향각
- 감쇠 계수 등

## 🚀 사용 방법

1. 이 파일들을 DCS World 모드 폴더에 복사
2. `entry.lua`에 `entry_T-50B.lua`의 내용 추가
3. EFM 빌드 (CMakeLists.txt 수정 필요)
4. DCS World에서 T-50B 선택

## ⚠️ 주의사항

- 현재는 F-22A 모델을 사용 (T-50B 전용 모델 필요)
- 공기역학 및 엔진 데이터는 추정값 사용 (실제 데이터 필요)
- EFM 빌드 설정 필요 (CMakeLists.txt 수정)

## 📝 라이선스

원본 F-22A Raptor 모드의 라이선스를 따릅니다.
GNU General Public License v3.0

## 👤 개발 정보

- 원본: F-22A Raptor by Grinnelli Designs
- 변환: F-22A → T-50B Golden Eagle
- 날짜: 2025
