# T-50B EFM Windows 빌드 가이드

## 📋 사전 요구사항

### 필수 프로그램
1. **Visual Studio 2019 이상** (Community 버전 무료)
   - 설치 시 "C++를 사용한 데스크톱 개발" 워크로드 선택
   - 다운로드: https://visualstudio.microsoft.com/

2. **CMake 3.10 이상**
   - 다운로드: https://cmake.org/download/
   - 설치 시 "Add CMake to system PATH" 체크

3. **DCS World SDK**
   - DCS World 공식 포럼에서 다운로드
   - 경로 예: `C:\Program Files\Eagle Dynamics\DCS World SDK`

---

## 🚀 빠른 빌드 (자동 스크립트)

### 방법 1: 자동 빌드 스크립트 사용

1. **`build_windows_simple.bat` 파일 열기**
2. **DCS SDK 경로 수정**:
   ```bat
   set "DCS_SDK_PATH=C:\Program Files\Eagle Dynamics\DCS World SDK"
   ```
3. **더블클릭으로 실행**
4. 빌드 완료 후 `build\bin\Release\T50_EFM.dll` 확인

### 방법 2: 상세 빌드 스크립트 사용

1. **`build_windows.bat` 실행**
2. 스크립트가 자동으로 경로 확인 및 빌드 진행
3. 오류 발생 시 안내 메시지 확인

---

## 🔧 수동 빌드 (명령줄)

### Step 1: Developer Command Prompt 열기

Visual Studio 설치 시 함께 설치되는 "Developer Command Prompt for VS" 실행

또는 일반 명령 프롬프트에서:
```cmd
cd "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build"
vcvars64.bat
```

### Step 2: 프로젝트 디렉토리로 이동

```cmd
cd C:\Path\To\T-50B\EFM
```

### Step 3: 빌드 디렉토리 생성 및 CMake 구성

```cmd
mkdir build
cd build

REM DCS SDK 경로 설정
set DCS_SDK_PATH=C:\Program Files\Eagle Dynamics\DCS World SDK

REM CMake 구성
cmake .. -G "Visual Studio 17 2022" -A x64 -DDCS_SDK_PATH="%DCS_SDK_PATH%"
```

**참고**: Visual Studio 버전에 따라 `-G` 옵션 변경:
- VS 2019: `"Visual Studio 16 2019"`
- VS 2022: `"Visual Studio 17 2022"`

### Step 4: 빌드 실행

```cmd
cmake --build . --config Release
```

### Step 5: DLL 확인

빌드 성공 시 다음 위치에 DLL 생성:
- `build\bin\Release\T50_EFM.dll`
- 또는 `build\Release\T50_EFM.dll`

---

## 📁 파일 구조 확인

빌드 전에 다음 파일들이 있는지 확인:

```
T-50B/
├── EFM/
│   ├── CMakeLists.txt          ✅
│   ├── build_windows.bat       ✅
│   ├── build_windows_simple.bat ✅
│   └── source/
│       ├── T50.cpp              ✅
│       ├── T50.h                ✅
│       ├── Utility.h             ✅
│       ├── Inputs.h              ✅
│       ├── FM/
│       │   └── wHumanCustomPhysicsAPI_ImplementationDeclare.h ✅
│       └── Cockpit/
│           └── CockpitAPI_Declare.h ✅
```

---

## ⚠️ 문제 해결

### 오류 1: "CMake is not installed"
**해결**: CMake 설치 및 PATH에 추가

### 오류 2: "Visual Studio compiler not found"
**해결**: 
- Developer Command Prompt for VS 사용
- 또는 Visual Studio Installer에서 C++ 도구 설치 확인

### 오류 3: "Cannot find DCS SDK"
**해결**: 
- DCS SDK 경로 확인
- `build_windows_simple.bat`에서 경로 수정
- 또는 환경 변수 `DCS_SDK_PATH` 설정

### 오류 4: "Cannot open include file"
**해결**: 
- DCS SDK가 올바르게 설치되었는지 확인
- SDK Include 폴더에 헤더 파일이 있는지 확인
- 스텁 헤더 사용 중이면 문제없음 (컴파일은 됨)

### 오류 5: "LNK2019: unresolved external symbol"
**해결**: 
- DCS SDK 라이브러리 경로 확인
- 필요한 경우 CMakeLists.txt에 라이브러리 링크 추가

---

## ✅ 빌드 성공 확인

빌드가 성공하면:
1. `T50_EFM.dll` 파일이 생성됨
2. 파일 크기: 약 500KB ~ 2MB (최적화 설정에 따라 다름)
3. 오류 메시지 없음

---

## 📦 다음 단계

빌드 완료 후:

1. **DLL 복사**:
   ```
   build\bin\Release\T50_EFM.dll
   →
   C:\Users\[사용자명]\Saved Games\DCS\Mods\aircraft\T-50B\EFM\bin\Release\T50_EFM.dll
   ```

2. **모드 파일 복사**:
   - `entry.lua` → 모드 폴더
   - `T-50B.lua` → 모드 폴더

3. **DCS 실행 및 테스트**

---

## 💡 팁

- **첫 빌드**: 약 1-2분 소요
- **재빌드**: 변경된 파일만 컴파일 (더 빠름)
- **디버그 빌드**: `--config Debug` 사용 (디버깅 정보 포함)
- **릴리즈 빌드**: `--config Release` 사용 (최적화됨, 권장)

---

## 📞 추가 도움

빌드 중 문제가 발생하면:
1. 오류 메시지 전체 복사
2. `build\CMakeCache.txt` 확인
3. `build\CMakeFiles\CMakeError.log` 확인


